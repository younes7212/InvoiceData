# config.py - تصحیح شده
import os

# تنظیمات اصلی ربات
TOKEN = "8256490628:AAFovwt2IdV6v7GLUikJ_Wgrqzr7bk_NRx4"

# اطلاعات ادمین اصلی
MAIN_ADMIN_ID = 83859402
MAIN_ADMIN_USERNAME = "@younes7212"

# اطلاعات فروشگاه
SHOP_NAME = "فست فود ویژه امیر"
SHOP_PHONE = "09123456789"
SHOP_ADDRESS = "تهران، خیابان ولیعصر"

# مسیرهای فایل‌ها
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
PRODUCTS_FILE = os.path.join(DATA_DIR, 'products.json')
CATEGORIES_FILE = os.path.join(DATA_DIR, 'categories.json')
ORDERS_FILE = os.path.join(DATA_DIR, 'orders.json')
MESSAGES_FILE = os.path.join(DATA_DIR, 'messages.json')
LOCATE_FILE = os.path.join(DATA_DIR, 'locate.json')
POINTS_FILE = os.path.join(DATA_DIR, 'points.json')
# وضعیت‌های سفارش
class OrderStatus:
    PENDING = "در انتظار تایید"
    CONFIRMED = "تایید شده"
    PREPARING = "در حال آماده‌سازی"
    READY = "آماده"
    SENT = "ارسال شده"
    CANCELLED = "لغو شده"

# نقش‌های کاربر
class UserRole:
    GUEST = "guest"
    CUSTOMER = "customer"
    ADMIN = "admin"
