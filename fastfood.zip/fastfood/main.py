# main.py - تصحیح شده
import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from config import TOKEN
from utils.data_manager import DataManager
from utils.user_manager import UserManager
from handlers.guest_handlers import register_guest_handlers
from handlers.customer_handlers import register_customer_handlers
from handlers.admin_handlers import register_admin_handlers

# تنظیم لاگ
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TelegramBot:
    """کلاس اصلی ربات تلگرام"""
    
    def __init__(self):
        self.bot = Bot(token=TOKEN)
        self.dp = Dispatcher(storage=MemoryStorage())
        self.data_manager = DataManager()
        self.user_manager = UserManager()
        
        # ثبت هندلرها
        self.register_handlers()
    
    def register_handlers(self):
        """ثبت تمام هندلرها"""
        register_guest_handlers(self.dp, self.user_manager, self.data_manager)
        register_customer_handlers(self.dp, self.user_manager, self.data_manager)
        register_admin_handlers(self.dp, self.bot, self.user_manager, self.data_manager)

    
    async def start_polling(self):
        """شروع polling"""
        try:
            logger.info("🚀 ربات شروع شد...")
            await self.dp.start_polling(self.bot)
        except Exception as e:
            logger.error(f"خطا در اجرای ربات: {e}")
        finally:
            await self.bot.session.close()

async def main():
    """تابع اصلی"""
    bot = TelegramBot()
    await bot.start_polling()
    dp.message.register(
    lambda msg: print("<< GOT TEXT >>", repr(msg.text)),
    F.text
    )

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("ربات متوقف شد.")
    except Exception as e:
        logger.error(f"خطای غیرمنتظره: {e}")
        sys.exit(1)
