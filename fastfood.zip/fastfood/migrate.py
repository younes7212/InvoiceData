from utils.data_manager import DataManager

dm = DataManager()
dm.migrate_message_file()
