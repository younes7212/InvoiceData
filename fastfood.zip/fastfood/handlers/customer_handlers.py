# handlers/customer_handlers.py - بروزرسانی شده
from functools import partial
from aiogram import Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from menus.customer.products_view import ProductsView
from menus.customer.cart_manager import CartManager, CartStates
from menus.customer.orders_view import OrdersView
from menus.customer.profile_manager import ProfileManager, ProfileStates
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

class CustomerHandlers:
    """کلاس هندلرهای مشتری"""
    
    def __init__(self, user_manager: UserManager, data_manager: DataManager):
        self.user_manager = user_manager
        self.data_manager = data_manager
        
        # ایجاد نمونه‌های منوها
        self.products_view = ProductsView(data_manager, user_manager)
        self.cart_manager = CartManager(data_manager, user_manager)
        self.orders_view = OrdersView(data_manager)
        self.profile_manager = ProfileManager(data_manager)

    async def handle_cart_request(self, message: Message, state: FSMContext):
        await self.cart_manager.show_cart(message, state)

def register_customer_handlers(dp: Dispatcher, user_manager: UserManager, data_manager: DataManager):
    """ثبت هندلرهای مشتری"""
    products_view = ProductsView(data_manager, user_manager)
    products_view.register_product_view(dp)

    orders_view = OrdersView(data_manager)
    dp.message.register(orders_view.show_orders, F.text == "📦 سفارشات من")

    cart_manager = CartManager(data_manager, user_manager)
    cart_manager.register_cart_handlers(dp)
    

    profile_manager = ProfileManager(data_manager)
    dp.message.register(profile_manager.start_profile_edit, F.text == "👤 پروفایل من")

    handlers = CustomerHandlers(user_manager, data_manager)
    dp.message.register(handlers.handle_cart_request, F.text == "🧺 سبد خرید")
