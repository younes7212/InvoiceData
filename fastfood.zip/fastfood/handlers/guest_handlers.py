# handlers/guest_handlers.py - تصحیح شده
from aiogram import Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from typing import Any
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from utils.keyboards import Keyboards
from config import SHOP_NAME, SHOP_PHONE, SHOP_ADDRESS
from menus.customer.customer_main import CustomerMenu
from functools import partial

class RegistrationStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_phone = State()
    waiting_for_address = State()
    waiting_for_city = State()

async def start_command(message: Message, user_manager: UserManager, data_manager: DataManager):
    
    user_id = message.from_user.id
    user_role = user_manager.get_user_role(user_id)
    
    if user_role == "admin":
        from menus.admin.admin_main import show_admin_menu
        await show_admin_menu(message, user_manager, data_manager)
    elif user_role == "customer":
        from menus.customer.customer_main import CustomerMenu
        customer_menu=CustomerMenu(data_manager, user_manager)
        await customer_menu.show_menu(message)
    else:
        from menus.guest.guest_main import show_guest_menu
        await show_guest_menu(message, user_manager, data_manager)

async def help_command(message: Message, user_manager: UserManager, data_manager: DataManager):
    """دستور راهنما"""
    help_text = f"""
📖 راهنمای استفاده از ربات {SHOP_NAME}

🔹 /start - شروع کار با ربات
🔹 /help - نمایش این راهنما

👥 برای مهمانان:
🔸 ثبت‌نام در سیستم
🔸 مشاهده منو
🔸 اطلاعات تماس

👤 برای مشتریان:
🔸 سفارش غذا
🔸 مدیریت سبد خرید
🔸 پیگیری سفارشات

📞 پشتیبانی: {SHOP_PHONE}
    """
    await message.answer(help_text)
import re

def is_persian(text):
    return bool(re.fullmatch(r'[\u0600-\u06FF\s]+', text))

def is_valid_phone(text):
    return text.isdigit()

def is_valid_address(text):
    return len(text.strip()) >= 10

async def start_registration(message: Message, state: FSMContext, user_manager: UserManager):
    """شروع فرآیند ثبت‌نام"""
    if user_manager.is_registered(message.from_user.id):
        await message.answer("شما قبلاً ثبت‌نام کرده‌اید!")
        return

    await state.set_state(RegistrationStates.waiting_for_name)
    await message.answer("📝 لطفاً نام و نام خانوادگی خود را وارد کنید (فقط فارسی):")

async def process_name(message: Message, state: FSMContext):
    """دریافت نام"""
    if not is_persian(message.text):
        await message.answer("❌ نام باید فقط با حروف فارسی باشد.")
        return

    await state.update_data(name=message.text)
    await state.set_state(RegistrationStates.waiting_for_phone)
    await message.answer("📱 لطفاً شماره تلفن خود را وارد کنید (فقط عدد انگلیسی):")

async def process_phone(message: Message, state: FSMContext):
    """دریافت شماره تلفن"""
    if not is_valid_phone(message.text):
        await message.answer("❌ شماره تلفن باید فقط شامل عدد انگلیسی باشد.")
        return

    await state.update_data(phone=message.text)
    await state.set_state(RegistrationStates.waiting_for_address)
    await message.answer("📍 لطفاً آدرس کامل خود را وارد کنید (حداقل ۱۰ کاراکتر):")

async def process_address(message: Message, state: FSMContext, user_manager: UserManager, data_manager: DataManager):
    """دریافت آدرس و شهر و تکمیل ثبت‌نام"""
    if not is_valid_address(message.text):
        await message.answer("❌ آدرس باید حداقل ۱۰ کاراکتر باشد.")
        return

    await state.update_data(address=message.text)
    await state.set_state(RegistrationStates.waiting_for_city)
    await message.answer("🏙️ لطفاً نام شهر خود را وارد کنید (فقط فارسی):")

async def process_city(message: Message, state: FSMContext, user_manager: UserManager, data_manager: DataManager):
    """دریافت شهر و ثبت نهایی"""
    if not is_persian(message.text):
        await message.answer("❌ نام شهر باید فقط با حروف فارسی باشد.")
        return

    data = await state.get_data()

    user_data = {
        'user_id': message.from_user.id,
        'username': message.from_user.username,
        'name': data['name'],
        'phone': data['phone'],
        'address': data['address'],
        'city': message.text,
        'cart': []
    }

    from menus.customer.customer_main import CustomerMenu
    customer_menu = CustomerMenu(data_manager, user_manager)

    if user_manager.register_user(user_data):
        await state.clear()
        await message.answer(
            f"✅ ثبت‌نام شما با موفقیت انجام شد!\n"
            f"خوش آمدید {data['name']} عزیز از شهر {message.text}!"
        )
        await customer_menu.show_menu(message)
    else:
        await message.answer("❌ خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.")


async def show_menu_guest(message: Message, data_manager: DataManager):
    """نمایش منو برای مهمان"""
    categories = data_manager.get_active_categories()
    products = data_manager.get_active_products()
    
    menu_text = f"📋 منوی {SHOP_NAME}\n\n"
    
    for category in categories:
        menu_text += f"🔹 {category['name']}\n"
        category_products = [p for p in products if p.get('category_id') == category['id']]
        
        for product in category_products:
            menu_text += f"   • {product['name']} - {product['price']:,} تومان\n"
        menu_text += "\n"
    
    menu_text += "💡 برای سفارش، لطفاً ابتدا ثبت‌نام کنید."
    await message.answer(menu_text)

async def show_contact_info(message: Message):
    """نمایش اطلاعات تماس"""
    contact_text = f"""
📞 اطلاعات تماس {SHOP_NAME}

📱 تلفن: {SHOP_PHONE}
📍 آدرس: {SHOP_ADDRESS}
🕐 ساعات کار: ۱۰:۰۰ تا ۲۳:۰۰

🌐 پیج اینستاگرام: @vizhe_amir_fastfood
📧 ایمیل: info@vizheamir.com
    """
    await message.answer(contact_text)


def register_guest_handlers(dp: Dispatcher, user_manager: UserManager, data_manager: DataManager):
    dp.message.register(
        partial(start_command, user_manager=user_manager, data_manager=data_manager),
        CommandStart()
    )
    dp.message.register(
        partial(help_command, user_manager=user_manager, data_manager=data_manager),
        Command(commands=["help"])
    )
    dp.message.register(
        partial(start_registration, user_manager=user_manager),
        F.text == "📝 ثبت‌نام"
    )
    dp.message.register(start_registration, Command("start_registration"))
    dp.message.register(process_name, RegistrationStates.waiting_for_name)
    dp.message.register(process_phone, RegistrationStates.waiting_for_phone)

    dp.message.register(
        partial(process_address, user_manager=user_manager, data_manager=data_manager),
        RegistrationStates.waiting_for_address
    )

    dp.message.register(
        partial(process_city, user_manager=user_manager, data_manager=data_manager),
        RegistrationStates.waiting_for_city
    )
    dp.message.register(
        partial(show_menu_guest, data_manager=data_manager),
        F.text == "📋 مشاهده منو"
    )
    dp.message.register(show_contact_info, F.text == "📞 تماس با ما")

