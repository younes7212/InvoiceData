# handlers/admin_handlers.py - تکمیل شده
from aiogram import Dispatcher, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from menus.admin.category_manager import CategoryManager, CategoryStates
from menus.admin.product_manager import ProductManager, ProductStates
from menus.admin.order_manager import OrderManager
from menus.admin.user_manager import UserManagerAdmin
from menus.admin.message_manager import MessageManager, BroadcastStates
from config import MAIN_ADMIN_ID
from menus.admin.settings import SettingsManager

class AdminHandlers:
    """کلاس هندلرهای ادمین"""
    
    def __init__(self, bot: Bot, user_manager: UserManager, data_manager: DataManager):
        self.user_manager = user_manager
        self.data_manager = data_manager

        # ایجاد نمونه‌های منوها
        self.category_manager = CategoryManager(bot, data_manager)
        self.product_manager = ProductManager(bot, data_manager) # فرض بر این است که ProductManager هم به bot نیاز دارد
        self.order_manager = OrderManager(
        user_manager=user_manager,
        data_manager=data_manager,
        bot=bot
        )
        self.user_manager_admin = UserManagerAdmin(bot, data_manager, user_manager)
        self.message_manager = MessageManager(bot, data_manager, user_manager) # فرض بر این است که MessageManager هم به bot نیاز دارد
        self.settings_manager = SettingsManager(data_manager)

def is_admin(user_id: int, data_manager: DataManager) -> bool:
    """بررسی اینکه آیا کاربر مدیر است یا نه"""
    if user_id == MAIN_ADMIN_ID:
        return True

    user = data_manager.get_user_by_id(user_id)
    return user is not None and user.get("role") == "admin"

async def handle_product_management(message: Message, admin_handlers: AdminHandlers):
    """مدیریت محصولات"""
    if not is_admin(message.from_user.id, admin_handlers.data_manager):
        return
    await admin_handlers.product_manager.show_products(message)

async def handle_order_management(message: Message, admin_handlers: AdminHandlers):
    """مدیریت سفارشات"""
    if not is_admin(message.from_user.id, admin_handlers.data_manager):
        return
    await admin_handlers.order_manager.send_main_menu(message)

async def handle_user_management(message: Message, admin_handlers: AdminHandlers):
    """مدیریت کاربران"""
    if not is_admin(message.from_user.id, admin_handlers.data_manager):
        return
    await admin_handlers.user_manager_admin.show_users(message)

async def handle_statistics(message: Message, admin_handlers: AdminHandlers):
    """نمایش آمار"""
    if not is_admin(message.from_user.id, admin_handlers.data_manager):
        return
    
    # محاسبه آمار
    users_count = len(admin_handlers.data_manager.get_users())
    orders = admin_handlers.data_manager.get_orders()
    orders_count = len(orders)
    products_count = len(admin_handlers.data_manager.get_active_products())
    
    # محاسبه درآمد
    total_revenue = sum(order.get('total', 0) for order in orders)
    
    # آمار سفارشات امروز
    from datetime import datetime
    today = datetime.now().strftime('%Y-%m-%d')
    today_orders = [o for o in orders if o.get('created_at', '').startswith(today)]
    today_revenue = sum(order.get('total', 0) for order in today_orders)
    
    stats_text = f"""
📊 آمار و گزارشات

📈 آمار کلی:
👥 تعداد کاربران: {users_count}
🛍 تعداد سفارشات: {orders_count}
📦 تعداد محصولات: {products_count}
💰 درآمد کل: {total_revenue:,} تومان

📅 آمار امروز:
🛒 سفارشات امروز: {len(today_orders)}
💵 درآمد امروز: {today_revenue:,} تومان

💡 میانگین سفارش: {total_revenue // orders_count if orders_count > 0 else 0:,} تومان
    """
    
    await message.answer(stats_text)

async def handle_send_message(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """شروع ارسال پیام همگانی"""
    if not is_admin(message.from_user.id, admin_handlers.data_manager):
        return
    await admin_handlers.message_manager.start_broadcast(message, state)

async def handle_settings(message: Message, admin_handlers: AdminHandlers):
    """تنظیمات"""
    await settings_manager.show_settings(message)

async def handle_back_to_customer(message: Message, user_manager: UserManager, data_manager: DataManager):
    """بازگشت به منوی عادی"""
    if not is_admin(message.from_user.id, data_manager):
        return
    
    from menus.customer.customer_main import CustomerMenu
    customer_menu=CustomerMenu(data_manager, user_manager)
    await customer_menu.show_menu(message)

# Product management states
async def handle_add_product_name(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """دریافت نام محصول"""
    await admin_handlers.product_manager.process_product_name(message, state)

async def handle_add_product_price(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """دریافت قیمت محصول"""
    await admin_handlers.product_manager.process_product_price(message, state)

async def handle_add_product_description(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """دریافت توضیحات محصول"""
    await admin_handlers.product_manager.process_product_description(message, state)

async def handle_add_product_category(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """دریافت دسته‌بندی محصول"""
    await admin_handlers.product_manager.process_product_category(message, state)

# Message broadcast states
async def handle_broadcast_message(message: Message, state: FSMContext, admin_handlers: AdminHandlers):
    """دریافت پیام برای ارسال همگانی"""
    await admin_handlers.message_manager.process_broadcast_message(message, state)

from functools import partial

def register_admin_handlers(
    dp: Dispatcher,
    bot: Bot,
    user_manager: UserManager,
    data_manager: DataManager
):
    """ثبت هندلرهای ادمین"""

    admin_handlers = AdminHandlers(bot, user_manager, data_manager)

    # منوهای اصلی ادمین
    dp.message.register(
        partial(handle_product_management, admin_handlers=admin_handlers),
        F.text == "📦 مدیریت محصولات"
    )

    dp.message.register(
        partial(handle_order_management, admin_handlers=admin_handlers),
        F.text == "🛍 مدیریت سفارشات"
    )

    dp.message.register(
        partial(handle_user_management, admin_handlers=admin_handlers),
        F.text == "👥 مدیریت کاربران"
    )
    dp.message.register(
        partial(handle_statistics, admin_handlers=admin_handlers),
        F.text == "📊 آمار و گزارشات"
    )
    dp.message.register(
        partial(handle_send_message, admin_handlers=admin_handlers),
        F.text == "💬 ارسال پیام"
    )
    settings_manager = SettingsManager(data_manager)
    dp.message.register(
        partial(settings_manager.show_settings),
        F.text == "⚙️ تنظیمات"
    )
    dp.message.register(
        partial(handle_back_to_customer, user_manager=user_manager, data_manager=data_manager),
        F.text == "🔙 بازگشت به منوی عادی"
    )


    # حالت FSM برای پخش پیام
    dp.message.register(
        partial(handle_broadcast_message, admin_handlers=admin_handlers),
        BroadcastStates.waiting_for_message
    )


    
    product_manager = ProductManager(bot, data_manager)
    product_manager.register_handlers(dp)
    

    # هندلر مدیریت سفارشات

    order_manager = OrderManager(bot, data_manager, user_manager)
    order_manager.register_order_handlers(dp)

    settings_manager = SettingsManager(data_manager)
    settings_manager.register_settings_handler(dp)
    
    user_manager_admin = UserManagerAdmin(bot, user_manager, data_manager)
    user_manager_admin.register_handlers_users(dp)

    from menus.admin.admin_main import register_main_handlers
    data_manager=DataManager()
    register_main_handlers(dp, data_manager)
