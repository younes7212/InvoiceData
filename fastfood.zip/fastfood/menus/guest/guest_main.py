# menus/guest/guest_main.py - تصحیح شده
from aiogram.types import Message
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from utils.keyboards import Keyboards
from config import SHOP_NAME

async def show_guest_menu(message: Message, user_manager: UserManager, data_manager: DataManager):
    """نمایش منوی مهمان"""
    welcome_text = f"""
🍔 سلام! خوش آمدید به {SHOP_NAME}

برای استفاده از امکانات ربات، لطفاً ابتدا ثبت‌نام کنید.

🔹 ثبت‌نام: برای عضویت در سیستم
🔹 مشاهده منو: دیدن غذاهای موجود
🔹 تماس با ما: اطلاعات تماس رستوران
    """
    
    await message.answer(welcome_text, reply_markup=Keyboards.guest_menu())
