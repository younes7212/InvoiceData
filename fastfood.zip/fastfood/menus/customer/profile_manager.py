# menus/customer/profile_manager.py
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from utils.data_manager import DataManager

class ProfileStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_phone = State()
    waiting_for_address = State()

class ProfileManager:
    """کلاس مدیریت پروفایل"""
    
    def __init__(self, data_manager: DataManager):
        self.data_manager = data_manager
    
    async def start_profile_edit(self, message: Message):
        """نمایش پروفایل کاربر"""
        user = self.data_manager.get_user_by_id(message.from_user.id)
        
        if not user:
            await message.answer("❌ اطلاعات کاربری یافت نشد!")
            return
        
        profile_text = f"""
👤 پروفایل شما:

📝 نام: {user.get('name', 'نامشخص')}
📱 شماره تلفن: {user.get('phone', 'نامشخص')}
📍 آدرس: {user.get('address', 'نامشخص')}
📅 تاریخ عضویت: {user.get('created_at', 'نامشخص')[:10]}

💡 برای ویرایش اطلاعات با ادمین تماس بگیرید.
        """
        
        await message.answer(profile_text)
    
    async def edit_profile(self, message: Message, state: FSMContext):
        """شروع ویرایش پروفایل"""
        await state.set_state(ProfileStates.waiting_for_name)
        await message.answer("📝 نام جدید خود را وارد کنید:")
    
    async def update_name(self, message: Message, state: FSMContext):
        """بروزرسانی نام"""
        await state.update_data(name=message.text)
        await state.set_state(ProfileStates.waiting_for_phone)
        await message.answer("📱 شماره تلفن جدید را وارد کنید:")
    
    async def update_phone(self, message: Message, state: FSMContext):
        """بروزرسانی تلفن"""
        await state.update_data(phone=message.text)
        await state.set_state(ProfileStates.waiting_for_address)
        await message.answer("📍 آدرس جدید را وارد کنید:")
    
    async def update_address(self, message: Message, state: FSMContext):
        """بروزرسانی آدرس و اتمام فرآیند"""
        data = await state.get_data()
        
        update_data = {
            'name': data['name'],
            'phone': data['phone'],
            'address': message.text
        }
        
        if self.data_manager.update_user(message.from_user.id, update_data):
            await state.clear()
            await message.answer("✅ پروفایل شما با موفقیت بروزرسانی شد!")
        else:
            await message.answer("❌ خطا در بروزرسانی پروفایل!")
