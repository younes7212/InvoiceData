# menus/customer/cart_manager.py
import asyncio
from datetime import datetime, timedelta
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.data_manager import DataManager
from utils.user_manager import UserManager
from utils.keyboards import Keyboards
from config import OrderStatus
from utils.keyboards import cart_inline
from aiogram import F, Bot, Dispatcher
from aiogram.exceptions import TelegramBadRequest
from typing import Optional, Dict, Any
from config import MAIN_ADMIN_ID
from menus.admin.admin_main import dispatch_receipt_to_admins
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
import jdatetime

class CartStates(StatesGroup):
    viewing_cart = State()
    editing_item = State()
    confirming_cart = State()
    awaiting_receipt = State()

class CartManager:
    """کلاس مدیریت سبد خرید"""
    
    def __init__(self, data_manager: DataManager, user_manager: UserManager):
        self.data_manager = data_manager
        self.user_manager = user_manager

    def render_cart_item_text(self, product: dict, quantity: int) -> str:
        item_total = product['price'] * quantity
        return (
            f"🔹 {product['name']}\n"
            f"   تعداد: {quantity} | قیمت: {item_total:,} تومان"
        )
    def render_cart_item_buttons(self, product_id: int) -> InlineKeyboardMarkup:
        builder = InlineKeyboardBuilder()
        builder.button(text="➖ حذف", callback_data=f"remove_item:{product_id}")
        builder.button(text="➕ افزایش", callback_data=f"increase_item:{product_id}")
        builder.adjust(2)
        return builder.as_markup()

    def cart_action_buttons(self) -> InlineKeyboardMarkup:
        builder = InlineKeyboardBuilder()
        builder.button(text="✅ تأیید سفارش", callback_data="confirm_order")
        builder.button(text="🧹 خالی کردن سبد", callback_data="clear_cart")
        builder.button(text="❌ بستن سبد", callback_data="go_back")
        builder.adjust(1)  # هر دکمه در یک ردیف جدا
        return builder.as_markup()

    async def update_total_price(self, bot: Bot, user_id: int):
        user = self.data_manager.get_user_by_id(user_id)
        products = self.data_manager.load_data('products')

        if not user or not user.get('cart'):
            return

        cart = user['cart']
        total_price = 0

        for item in cart.get("products", []):
            product = next((p for p in products if int(p.get('id')) == int(item['id'])), None)
            if product:
                total_price += product['price'] * item['quantity']

        total_text = f"💰 مجموع کل: {total_price:,} تومان"
        message_id = self.user_manager.get_user_total_message_id(user_id)
        print("message_id مجموع مبلغ:", message_id)

        try:
            await bot.edit_message_text(
                chat_id=user_id,
                message_id=message_id,
                text=total_text,
                reply_markup=self.cart_action_buttons()
            )
        except TelegramBadRequest as e:
            print("خطا در ویرایش مجموع مبلغ:", e)

    async def show_cart(self, event, state: FSMContext):
        if isinstance(event, CallbackQuery):
            message = event.message
            user_id = event.from_user.id
            await event.answer()
        elif isinstance(event, Message):
            message = event
            user_id = message.from_user.id
        else:
            print("❌ نوع event نامعتبر است:", type(event))
            return

        cart = self.user_manager.get_user_cart(user_id)

        if not cart or not cart.get("products"):
            await message.answer("🛍 هنوز هیچ محصولی به سبد خرید اضافه نکردی!")
            await state.clear()
            return

        # فعال‌سازی وضعیت مشاهده سبد خرید
        await state.set_state(CartStates.viewing_cart)
        await state.update_data(cart=cart)

        products = self.data_manager.load_data('products')
        total_price = 0
        message_ids = []

        # پیام ابتدایی
        msg = await message.answer("🛍 سبد خرید شما:")
        message_ids.append(msg.message_id)
        print("✅ نوع msg:", type(msg))
        # نمایش آیتم‌ها با دکمه‌های مدیریت
        for item in cart.get("products", []):
            product = next((p for p in products if int(p.get('id')) == int(item['id'])), None)
            if not product or item['quantity'] <= 0:
                continue  # فیلتر آیتم‌های نامعتبر یا صفر

            quantity = item['quantity']
            item_total = product['price'] * quantity
            total_price += item_total

            cart_text = (
                f"🔹 {product['name']}\n"
                f"   تعداد: {quantity} | قیمت: {item_total:,} تومان"
            )

            builder = InlineKeyboardBuilder()
            builder.button(text="➖ حذف", callback_data=f"remove_item:{product['id']}")
            builder.button(text="➕ افزایش", callback_data=f"increase_item:{product['id']}")
            builder.adjust(2)

            msg = await message.answer(cart_text, reply_markup=builder.as_markup())
            message_ids.append(msg.message_id)

        # پیام مجموع مبلغ + دکمه تأیید
        try:
            confirm_keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ تأیید سبد خرید", callback_data="confirm_order")],
                [InlineKeyboardButton(text="🧹 پاک‌سازی سبد", callback_data="clear_cart")],
                [InlineKeyboardButton(text="❌ بستن سبد", callback_data="go_back")]
            ])

            msg = await message.answer(
                f"💰 مجموع کل: {total_price:,} تومان",
                reply_markup=confirm_keyboard
            )
            self.user_manager.set_user_total_message_id(user_id, msg.message_id)
            message_ids.append(msg.message_id)
            print("✅ پیام مجموع مبلغ ارسال شد:", msg.message_id)
        except Exception as e:
            print("❌ خطا در ارسال پیام مجموع مبلغ:", e)

        # ذخیره پیام‌ها برای حذف یا بروزرسانی بعدی
        self.user_manager.set_user_cart_message_ids(user_id, message_ids)



    async def handle_go_back(self, callback: CallbackQuery):
        user_id = callback.from_user.id
        message_ids = self.user_manager.get_user_cart_message_ids(user_id)
        message_id = self.user_manager.get_user_total_message_id(user_id)

        if isinstance(message_id, int):
            try:
                await callback.bot.delete_message(chat_id=user_id, message_id=message_id)
                print("✅ پیام منو حذف شد")
            except TelegramBadRequest as e:
                print("❌ خطا در حذف پیام منو:", e)

        for msg_id in message_ids:
            try:
                await callback.bot.delete_message(chat_id=user_id, message_id=msg_id)
            except TelegramBadRequest as e:
                print(f"❌ خطا در حذف پیام {msg_id}:", e)

        # پاک‌سازی لیست پیام‌ها
        self.user_manager.set_user_cart_message_ids(user_id, [])

        try:
            await callback.answer("❌ سبد بسته شد", show_alert=False)
        except TelegramBadRequest as e:
            print("❌ query منقضی شده:", e)


    async def handle_increase_item(self, callback: CallbackQuery):
        product_id = int(callback.data.split(":")[1])
        user_id = callback.from_user.id

        # افزایش تعداد محصول در سبد
        self.data_manager.add_to_cart(user_id, product_id)

        # بارگذاری داده‌ها
        products = self.data_manager.load_data('products')
        product = next((p for p in products if int(p.get('id')) == product_id), None)

        # گرفتن سبد جدید کاربر
        cart = self.user_manager.get_user_cart(user_id)
        quantity = 0
        for item in cart.get("products", []):
            if int(item['id']) == product_id:
                quantity = item['quantity']
                break

        if product:
            text = self.render_cart_item_text(product, quantity)
            markup = self.render_cart_item_buttons(product_id)

            try:
                await callback.message.edit_text(text, reply_markup=markup)
            except TelegramBadRequest as e:
                print("خطا در ویرایش پیام محصول:", e)

        # آپدیت مجموع مبلغ
        await self.update_total_price(callback.bot, user_id)

        try:
            await callback.answer("✅ افزایش تعداد", show_alert=False)
        except TelegramBadRequest as e:
            print("❌ query منقضی شده:", e)

    async def handle_decrease_item(self, callback: CallbackQuery):
        product_id = int(callback.data.split(":")[1])
        user_id = callback.from_user.id

        # کاهش تعداد محصول در سبد
        self.data_manager.remove_from_cart(user_id, product_id)

        # گرفتن محصول از لیست محصولات
        products = self.data_manager.load_data('products')
        product = next((p for p in products if int(p.get('id')) == product_id), None)

        # گرفتن سبد جدید کاربر
        cart = self.user_manager.get_user_cart(user_id)
        quantity = 0
        for item in cart.get("products", []):
            if int(item['id']) == product_id:
                quantity = item['quantity']
                break

        if product:
            if quantity > 0:
                # ویرایش پیام محصول با تعداد جدید
                text = self.render_cart_item_text(product, quantity)
                markup = self.render_cart_item_buttons(product_id)
                try:
                    await callback.message.edit_text(text, reply_markup=markup)
                except TelegramBadRequest as e:
                    print("خطا در ویرایش پیام محصول:", e)
            else:
                # حذف پیام محصول اگر تعداد صفر شد
                try:
                    await callback.message.delete()
                except TelegramBadRequest as e:
                    print("خطا در حذف پیام محصول:", e)

        # ویرایش پیام مجموع مبلغ
        await self.update_total_price(callback.bot, user_id)

        # پاسخ به کلیک کاربر
        try:
            await callback.answer("❌ کاهش تعداد", show_alert=False)
        except TelegramBadRequest as e:
            print("❌ query منقضی شده:", e)

    async def confirm_order(self, callback: CallbackQuery):
        user_id = callback.from_user.id
        cart = self.user_manager.get_user_cart(user_id)

        if not cart:
            await callback.answer("❌ سبد خرید خالی است!")
            return

        products = self.data_manager.load_data('products')
        total_price = 0

        for item in cart.get("products", []):
            product = next((p for p in products if int(p.get('id')) == int(item['id'])), None)
            if product:
                total_price += product['price'] * item['quantity']

        min_order = self.data_manager.get_min_order_amount()
        if total_price < min_order:
            await callback.answer(f"❌ مبلغ سفارش کمتر از حداقل مجاز ({min_order:,} تومان) است!", show_alert=True)
            return

        is_valid, location_message = self.data_manager.check_delivery_access(user_id)
        if not is_valid:
            await callback.message.answer(location_message)
            return

        # ساخت سفارش جدید با شناسه یکتا
        orders = self.data_manager.load_data("orders")
        max_id = max([o.get("id") for o in orders if o.get("id") is not None], default=0)
        new_id = max_id + 1

        order_data = {
            "id": new_id,
            "user_id": user_id,
            "cart": cart,
            "total": total_price,
            "created_at": jdatetime.datetime.now().isoformat(),
            "status": OrderStatus.PENDING,
            "payment_message_id": None
        }

        success = self.data_manager.add_order(order_data)
        if not success:
            await callback.answer("❌ خطا در ثبت سفارش!")
            return

        # حذف پیام‌های سبد
        cart_message_ids = self.user_manager.get_user_cart_message_ids(user_id)
        total_message_id = self.user_manager.get_user_total_message_id(user_id)

        for msg_id in cart_message_ids + [total_message_id]:
            try:
                await callback.bot.delete_message(chat_id=user_id, message_id=msg_id)
            except TelegramBadRequest:
                pass

        # پاک‌سازی حافظه
        self.data_manager.update_user(user_id, {
            'cart_message_ids': [],
            'total_message_id': None,
            'cart': []
        })

        # دریافت کارت‌ها
        cards = self.data_manager.load_data("messages")
        if not cards or not isinstance(cards, list):
            await callback.message.answer("❌ هیچ شماره کارتی ثبت نشده است.")
            return

        items = self.data_manager.load_data("messages")
        if not isinstance(items, list):
            items = []

        cards = [item for item in items if item.get("type") == "card"]

        card_text = "\n".join([f"`{card['number']}` - {card['owner']}" for card in cards])

        # ارسال پیام پرداخت
        msg = await callback.message.answer(
            f"✅ سفارش شما ثبت شد.\n\n💳 شماره کارت جهت پرداخت:\n{card_text}\n\n💰 مبلغ قابل پرداخت: {total_price:,} تومان\n\n⏳ زمان باقی‌مانده برای پرداخت: 10:00",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="📤 ارسال فیش پرداخت", callback_data="send_receipt")]
                ]
            ),
            parse_mode="Markdown"
        )

        # آپدیت شناسه پیام پرداخت در سفارش
        self.data_manager.update_orders(new_id, {
            "payment_message_id": msg.message_id
        })

        # شروع تایمر لغو سفارش
        asyncio.create_task(
            self.countdown_and_cancel_order(
                bot=callback.bot,
                user_id=user_id,
                message_id1=msg.message_id,
                order_id=new_id,
                card_text=card_text,
                total_price=total_price
            )
        )

        await callback.answer()


    async def countdown_and_cancel_order(self, bot, user_id, message_id1, order_id, card_text, total_price):
        total_seconds = 600

        for remaining in range(total_seconds, 0, -1):
            minutes = remaining // 60
            seconds = remaining % 60
            time_text = f"{minutes:02}:{seconds:02}"

            order = self.data_manager.get_order_by_id(order_id)
            if not order or order.get("status").strip() not in ["در انتظار تایید", OrderStatus.PENDING]:
                try:
                    await bot.edit_message_text(
                        chat_id=user_id,
                        message_id=message_id1,
                        text=(
                            f"✅ سفارش شما ثبت شد.\n\n"
                            f"💳 شماره کارت جهت پرداخت:\n{card_text}\n\n"
                            f"💰 مبلغ قابل پرداخت: {total_price:,} تومان\n\n"
                            f"⏳ زمان پرداخت به پایان رسید یا سفارش لغو شد."
                        ),
                        reply_markup=InlineKeyboardMarkup(inline_keyboard=[]),  # حذف دکمه‌ها
                        parse_mode="Markdown"
                    )
                except TelegramBadRequest:
                    pass
                return  # توقف تایمر



            try:
                await bot.edit_message_text(
                    chat_id=user_id,
                    message_id=message_id1,  # ✅ اصلاح نام پارامتر
                    text=(
                        f"✅ سفارش شما ثبت شد.\n\n"
                        f"💳 شماره کارت جهت پرداخت:\n{card_text}\n\n"
                        f"💰 مبلغ قابل پرداخت: {total_price:,} تومان\n\n"
                        f"⏳ زمان باقی‌مانده برای پرداخت: {time_text}"
                    ),
                        reply_markup=InlineKeyboardMarkup(
                            inline_keyboard=[
                                [InlineKeyboardButton(text="📤 ارسال فیش پرداخت", callback_data="send_receipt")]
                            ]
                        ),
                    parse_mode="Markdown"
                )
            except TelegramBadRequest:
                pass

            await asyncio.sleep(1)

        # بعد از پایان زمان
        order = self.data_manager.get_order_by_id(order_id)
        if order and order.get("status").strip() in ["در انتظار تایید", OrderStatus.PENDING]:
            try:
                await bot.delete_message(chat_id=user_id, message_id=message_id1)
            except TelegramBadRequest:
                pass

            self.data_manager.update_order_status(order_id, OrderStatus.CANCELLED)
            await bot.send_message(user_id, "❌ مهلت پرداخت به پایان رسید. سفارش شما لغو شد.")


    async def handle_receipt_request(self, callback: CallbackQuery, state: FSMContext):
        await state.set_state(CartStates.awaiting_receipt)
        await callback.message.answer("📤 لطفاً فیش پرداخت خود را ارسال کنید (عکس یا متن).")
        await callback.answer()
        
    
    async def handle_receipt_submission(self, message: Message, state: FSMContext):
        user_id = int(message.from_user.id)
        order = self.data_manager.get_latest_order_for_user(user_id)
        if not order:
            await message.answer("❌ سفارش فعال پیدا نشد.")
            return
        shamsi_now = jdatetime.datetime.now().strftime("%Y/%m/%d - %H:%M")
        receipt_data = {
            "user_id": user_id,
            "order_id": order["id"],
            "timestamp": shamsi_now,
            "type": "photo" if message.photo else "text",
            "file_id": message.photo[-1].file_id if message.photo else None,
            "text": message.text.strip() if message.text and message.text.strip() else "---"
        }

        # ذخیره اطلاعات فیش داخل سفارش
        order["receipt"] = receipt_data
        self.data_manager.update_orders(order["id"], order)

        # ارسال به تابع ادمین
        await dispatch_receipt_to_admins(
            bot=message.bot,
            data_manager=self.data_manager,
            user_manager=self.user_manager,
            receipt_data=receipt_data
        )

        await message.answer("✅ فیش شما برای مدیران ارسال شد. منتظر تأیید باشید.")
        await state.clear()

    def get_latest_order_for_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        orders = self.data_manager.load_data("orders")
        user_orders = [o for o in orders if o.get("user_id") == user_id and o.get("status", "").lower() == "pending"]
        return user_orders[-1] if user_orders else None

    async def clear_cart(self, callback: CallbackQuery):
        user_id = callback.from_user.id
        self.user_manager.clear_user_cart(user_id)
        await callback.message.edit_text("🧹 سبد خرید شما پاک شد.")
        await callback.answer("✅ سبد خرید پاک شد.")


    def register_cart_handlers(self, dp: Dispatcher):
        dp.callback_query.register(self.handle_increase_item, F.data.startswith("increase_item:"))
        dp.callback_query.register(self.handle_decrease_item, F.data.startswith("remove_item:"))
        dp.callback_query.register(self.confirm_order, F.data == "confirm_order")
        dp.callback_query.register(self.clear_cart, F.data == "clear_cart")
        dp.callback_query.register(self.handle_go_back, F.data == "go_back")
        dp.callback_query.register(self.handle_receipt_request, F.data == "send_receipt")
        dp.message.register(self.handle_receipt_submission, StateFilter(CartStates.awaiting_receipt))
