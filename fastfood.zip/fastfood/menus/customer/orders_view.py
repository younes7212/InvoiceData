# menus/customer/orders_view.py
from aiogram.types import Message
from utils.data_manager import DataManager
from config import OrderStatus

class OrdersView:
    """کلاس نمایش سفارشات"""
    
    def __init__(self, data_manager: DataManager):
        self.data_manager = data_manager
    
    async def show_orders(self, message: Message):
        """نمایش سفارشات کاربر"""
        user_orders = self.data_manager.get_user_orders(message.from_user.id)
        
        if not user_orders:
            await message.answer("📋 شما تا کنون سفارشی نداده‌اید.")
            return
        
        orders_text = "📋 سفارشات شما:\n\n"
        
        # نمایش آخرین 5 سفارش
        recent_orders = sorted(user_orders, key=lambda x: x.get('id', 0), reverse=True)[:5]
        
        for order in recent_orders:
            orders_text += f"🔸 سفارش #{order['id']}\n"
            orders_text += f"📅 تاریخ: {order.get('created_at', 'نامشخص')[:10]}\n"
            orders_text += f"💰 مبلغ: {order.get('total', 0):,} تومان\n"
            orders_text += f"📊 وضعیت: {order.get('status', OrderStatus.PENDING)}\n\n"
        
        await message.answer(orders_text)
    
    async def show_order_detail(self, message: Message, order_id: int):
        """نمایش جزئیات سفارش"""
        orders = self.data_manager.get_user_orders(message.from_user.id)
        order = next((o for o in orders if o.get('id') == order_id), None)
        
        if not order:
            await message.answer("❌ سفارش یافت نشد!")
            return
        
        detail_text = f"📋 جزئیات سفارش #{order['id']}\n\n"
        detail_text += f"📅 تاریخ: {order.get('created_at', 'نامشخص')}\n"
        detail_text += f"📊 وضعیت: {order.get('status', OrderStatus.PENDING)}\n\n"
        detail_text += "🛒 اقلام سفارش:\n"
        
        for item in order.get('items', []):
            detail_text += f"🔹 {item.get('product_name', 'محصول')}\n"
            detail_text += f"   تعداد: {item.get('quantity', 0)} | قیمت واحد: {item.get('price', 0):,} تومان\n"
            detail_text += f"   مجموع: {item.get('total', 0):,} تومان\n\n"
        
        detail_text += f"💰 مجموع کل: {order.get('total', 0):,} تومان"
        
        await message.answer(detail_text)
