from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from config import SHOP_NAME
from .products_view import ProductsView
from .cart_manager import CartManager
from .orders_view import OrdersView
from .profile_manager import ProfileManager

class CustomerMenu:
    """کلاس اصلی منوی مشتری"""

    def __init__(self, data_manager: DataManager, user_manager: UserManager):
        self.data_manager = data_manager
        self.user_manager = user_manager

        self.products_view = ProductsView(data_manager, user_manager)
        self.cart_manager = CartManager(data_manager, user_manager)
        self.orders_view = OrdersView(data_manager)
        self.profile_manager = ProfileManager(data_manager)

    def get_main_keyboard(self):
        """ساخت منوی پایین مشتری با دو دکمه در هر ردیف"""
        return ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="🛒 مشاهده محصولات"), KeyboardButton(text="📦 سفارشات من")],
                [KeyboardButton(text="🧺 سبد خرید"), KeyboardButton(text="👤 پروفایل من")]
            ],
            resize_keyboard=True
        )

    async def show_menu(self, message: Message):
        """نمایش منوی اصلی مشتری"""
        user = self.data_manager.get_user_by_id(message.from_user.id)
        user_name = user.get('name', 'کاربر عزیز') if user else 'کاربر عزیز'

        welcome_text = f"""
🍔 سلام {user_name}!
خوش آمدید به {SHOP_NAME}

از منوی پایین یکی از گزینه‌ها را انتخاب کنید 👇
        """

        await message.answer(welcome_text.strip(), reply_markup=self.get_main_keyboard())
