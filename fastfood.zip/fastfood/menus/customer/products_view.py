from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram import F
from utils.data_manager import DataManager
from utils.user_manager import UserManager
from aiogram.exceptions import TelegramBadRequest
from config import OrderStatus
from menus.customer.cart_manager import CartManager
from aiogram.fsm.context import FSMContext
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.state import State, StatesGroup

class ProductState(StatesGroup):
    waiting_for_location = State()
class ProductsView:
    def __init__(self, data_manager: DataManager, user_manager: UserManager):
        self.data_manager = data_manager
        self.user_manager = user_manager
        self.cart_manager = CartManager(data_manager, user_manager)

    def render_categories(self):
        categories = self.data_manager.get_active_categories()
        if not categories:
             return "❌ هیچ دسته‌بندی‌ای یافت نشد.", InlineKeyboardMarkup(inline_keyboard=[])

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=cat['name'], callback_data=f"category:{cat['id']}")]
                for cat in categories
            ] + [
                [InlineKeyboardButton(text="❌ بستن منو", callback_data="close_menu")]
            ]
        )
        return "📂 دسته‌بندی محصولات:", keyboard
    def render_products(self, category_id: int):
        products = self.data_manager.get_active_products()
        filtered = [p for p in products if p.get('category_id') == category_id and p.get('active', True)]

        if not filtered:
            return "❌ محصولی در این دسته‌بندی نیست.", InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_categories")]
            ])

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=product['name'], callback_data=f"product:{product['id']}")]
                for product in filtered
            ] + [
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_categories")]
            ]
        )

        return "🛍️ محصولات این دسته:", keyboard
    def render_product_detail(self, product_id: int, user_id: int):
        products = self.data_manager.load_data('products')
        product = next((p for p in products if p.get('id') == product_id), None)

        if not product:
            return "❌ محصول یافت نشد.", InlineKeyboardMarkup(inline_keyboard=[])

        cart = self.user_manager.get_user_cart(user_id)
        quantity = 0

        for item in cart.get("products", []):
            if item.get("id") == product_id:
                quantity = item.get("quantity", 0)
                break

        text = (
            f"🍽️ {product['name']}\n"
            f"💰 قیمت: {product['price']} تومان\n"
            f"📦 توضیحات: {product.get('description', 'ندارد')}\n"
            f"🧺 تعداد در سبد خرید: {quantity}"
        )

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text=f"➕ افزودن ({quantity})", callback_data=f"add:{product_id}"),
                    InlineKeyboardButton(text="➖ حذف", callback_data=f"remove:{product_id}")
                ],
                [
                    InlineKeyboardButton(text="🔄 انتخاب محصول دیگر", callback_data="choose_other_product")
                ],
                [
                    InlineKeyboardButton(text="🛒 انتقال به سبد خرید", callback_data="go_to_cart")
                ]
            ]
        )
        return text, keyboard

    async def handle_products_menu(self, event, state: FSMContext):
        user_id = event.from_user.id
        users = self.data_manager.load_data("users")
        print("نوع داده:", type(users))
        print("مقدار:", users)

        if not isinstance(users, list):
            await event.answer("❌ فایل کاربران نامعتبر است.")
            return

        user = next(
            (u for u in users if isinstance(u, dict) and str(u.get("user_id")) == str(user_id)),
            None
        )

        if not user:
            await event.answer("❌ اطلاعات کاربر یافت نشد.")
            return

        cart_items = user.get("cart", [])
        if not isinstance(cart_items, list):
            await event.answer("❌ ساختار سبد خرید نامعتبر است.")
            return

        has_location = any(
            isinstance(item, dict) and item.get("type") == "location"
            for item in cart_items
        )

        if not has_location:
            await state.set_state(ProductState.waiting_for_location)
            await event.answer(
                "📍 برای دریافت راحت‌تر سفارش، لطفاً موقعیت مکانی خود را ارسال کنید:",
                reply_markup=self.location_request()
            )
            return

        text, markup = self.render_categories()

        if isinstance(event, Message):
            await event.answer(text, reply_markup=markup)
        elif isinstance(event, CallbackQuery):
            await event.message.edit_text(text, reply_markup=markup)
            await event.answer()

    async def handle_products_menu1(self, event, state: FSMContext):
        text, markup = self.render_categories()

        if isinstance(event, Message):
            await event.answer(text, reply_markup=markup)
        elif isinstance(event, CallbackQuery):
            await event.message.edit_text(text, reply_markup=markup)
            await event.answer()


    def location_request(self):
        return ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="📍 ارسال موقعیت", request_location=True)]
            ],
            resize_keyboard=True,
            one_time_keyboard=True
        )

    async def process_location(self, message: Message, state: FSMContext):
        lat = message.location.latitude
        lon = message.location.longitude

        user_id = message.from_user.id
        user = self.data_manager.get_user_by_id(user_id)
        if user:
            # ساخت آیتم موقعیت مکانی برای ذخیره در cart
            location_item = {
                "type": "location",
                "lat": lat,
                "lon": lon
            }

            # اضافه کردن به سبد خرید
            cart = user.get("cart", [])
            cart = [item for item in cart if item.get("type") != "location"]
            cart.append(location_item)
            self.user_manager.update_user_cart(user_id, cart)
            await state.clear()
            # نمایش دسته‌بندی + منوی پایین مشتری
            from menus.customer.customer_main import CustomerMenu
            customer_menu = CustomerMenu(self.data_manager, self.user_manager)

            text, markup = self.render_categories()
            await message.answer(text, reply_markup=markup)

            await message.answer("👇 منوی اصلی مشتری", reply_markup=customer_menu.get_main_keyboard())
        else:
            await message.answer("❌ خطا در ثبت موقعیت. لطفاً دوباره تلاش کنید.")

    async def handle_show_products(self, callback: CallbackQuery):
        category_id = int(callback.data.split(":")[1])
        text, markup = self.render_products(category_id)
        await callback.message.edit_text(text, reply_markup=markup)
        await callback.answer()

    async def handle_product_detail(self, callback: CallbackQuery):
        product_id = int(callback.data.split(":")[1])
        text, markup = self.render_product_detail(product_id, callback.from_user.id)
        await callback.message.edit_text(text, reply_markup=markup)
        await callback.answer()

    async def handle_add_to_cart(self, callback: CallbackQuery):
        user_id = callback.from_user.id
        product_id = int(callback.data.split(":")[1])

        self.data_manager.add_to_cart(user_id, product_id)

        # ساخت پاپ‌آپ خلاصه سبد خرید
        cart = self.user_manager.get_user_cart(user_id)
        products = cart.get("products", [])
        all_products = self.data_manager.load_data("products")

        summary_lines = ["🧺 سبد خرید فعلی:"]
        for item in products:
            product = next((p for p in all_products if p.get("id") == item.get("id")), None)
            if product:
                name = product.get("name", "نامشخص")
                quantity = item.get("quantity", 0)
                summary_lines.append(f"{name} * {quantity}")

        popup_text = "\n".join(summary_lines)

        try:
            await callback.answer(popup_text, show_alert=False)
        except TelegramBadRequest as e:
            print("⚠️ خطا در ارسال پاسخ:", e)

        text, markup = self.render_product_detail(product_id, user_id)

        current_text = callback.message.text.strip() if callback.message.text else ""
        new_text = text.strip()

        try:
            if current_text != new_text:
                await callback.message.edit_text(new_text, reply_markup=markup)
            else:
                await callback.message.edit_reply_markup(reply_markup=markup)
        except TelegramBadRequest as e:
            print("⚠️ خطا در ویرایش پیام:", e)

    async def handle_remove_from_cart(self, callback: CallbackQuery):
        user_id = callback.from_user.id
        product_id = int(callback.data.split(":")[1])

        self.data_manager.remove_from_cart(user_id, product_id)

        # ساخت پاپ‌آپ خلاصه سبد خرید بعد از حذف
        cart = self.user_manager.get_user_cart(user_id)
        products = cart.get("products", [])
        all_products = self.data_manager.load_data("products")

        summary_lines = ["🧺 سبد خرید فعلی:"]
        for item in products:
            product = next((p for p in all_products if p.get("id") == item.get("id")), None)
            if product:
                name = product.get("name", "نامشخص")
                quantity = item.get("quantity", 0)
                summary_lines.append(f"{name} * {quantity}")

        if len(summary_lines) == 1:
            summary_lines.append("سبد خرید خالی است.")

        popup_text = "\n".join(summary_lines)

        try:
            await callback.answer(popup_text, show_alert=False)
        except TelegramBadRequest as e:
            print("⚠️ خطا در ارسال پاسخ:", e)

        text, markup = self.render_product_detail(product_id, user_id)

        current_text = callback.message.text.strip() if callback.message.text else ""
        new_text = text.strip()

        try:
            if current_text != new_text:
                await callback.message.edit_text(new_text, reply_markup=markup)
            else:
                await callback.message.edit_reply_markup(reply_markup=markup)
        except TelegramBadRequest as e:
            print("⚠️ خطا در ویرایش پیام:", e)

    async def handle_close_menu(self, callback: CallbackQuery):
        try:
            await callback.message.delete()
        except TelegramBadRequest as e:
            print("خطا در حذف پیام:", e)

    async def handle_back_to_categories(self, callback: CallbackQuery):
        text, markup = self.render_categories()
        try:
            await callback.message.edit_text(text, reply_markup=markup)
        except TelegramBadRequest as e:
            print("خطا در بازگشت به دسته‌بندی‌ها:", e)

    async def handle_go_to_cart(self, callback: CallbackQuery, state: FSMContext):
        try:
            await callback.message.delete()
        except TelegramBadRequest as e:
            print("⚠️ خطا در حذف پیام:", e)

        await self.cart_manager.show_cart(callback, state)
        await callback.answer()

    def register_product_view(self, dp):
        dp.message.register(self.handle_products_menu, F.text == "🛒 مشاهده محصولات")
        dp.callback_query.register(self.handle_products_menu1, F.data == "choose_other_product")
        dp.callback_query.register(self.handle_show_products, F.data.startswith("category:"))
        dp.callback_query.register(self.handle_product_detail, F.data.startswith("product:"))
        dp.callback_query.register(self.handle_add_to_cart, F.data.startswith("add:"))
        dp.callback_query.register(self.handle_remove_from_cart, F.data.startswith("remove:"))
        dp.callback_query.register(self.handle_close_menu, F.data == "close_menu")
        dp.callback_query.register(self.handle_back_to_categories, F.data == "back_to_categories")
        dp.callback_query.register(self.handle_go_to_cart, F.data == "go_to_cart")
        dp.message.register(self.process_location, ProductState.waiting_for_location)

