from aiogram import Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from utils.data_manager import DataManager
from utils.keyboards import Keyboards
from config import *

class CategoryStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_description = State()

class CategoryManager:
    """مدیریت دسته‌بندی‌ها برای ادمین"""
    
    def __init__(self, bot: Bot, data_manager: DataManager):
        self.bot = bot
        self.data_manager = data_manager
        self.keyboards = Keyboards()
    
    async def show_categories(self, message: Message):
        """نمایش لیست دسته‌بندی‌ها"""
        categories = self.data_manager.get_categories()
        
        text = "📂 مدیریت دسته‌بندی‌ها:\n\n"
        
        if not categories:
            text += "هیچ دسته‌بندی موجود نیست.\n\n"
        else:
            for category in categories:
                status = "✅" if category.get('active', True) else "❌"
                products_count = len(self.data_manager.get_products_by_category(category['id']))
                text += f"{status} {category['name']}\n"
                text += f"   📝 {category.get('description', 'بدون توضیحات')}\n"
                text += f"   📦 {products_count} محصول\n\n"
        
        text += "💡 دستورات:\n"
        text += "• برای افزودن: افزودن دسته: نام | توضیحات\n"
        text += "• برای حذف: حذف دسته: شماره\n"
        text += "• برای ویرایش: ویرایش دسته: شماره | نام جدید | توضیحات جدید"
        
        await message.answer(text)
    
    async def add_category(self, message: Message, category_data: str):
        """افزودن دسته‌بندی جدید"""
        try:
            parts = category_data.split('|')
            if len(parts) != 2:
                await message.answer("❌ فرمت نادرست! استفاده کنید: افزودن دسته: نام | توضیحات")
                return
            
            name = parts[0].strip()
            description = parts[1].strip()
            
            if len(name) < 2:
                await message.answer("❌ نام دسته‌بندی باید حداقل 2 کاراکتر باشد.")
                return
            
            # بررسی تکراری نبودن نام
            categories = self.data_manager.get_categories()
            if any(cat['name'].lower() == name.lower() for cat in categories):
                await message.answer("❌ این نام دسته‌بندی قبلاً وجود دارد.")
                return
            
            # ایجاد ID جدید
            max_id = max([cat.get('id', 0) for cat in categories], default=0)
            
            new_category = {
                'id': max_id + 1,
                'name': name,
                'description': description,
                'active': True
            }
            
            categories.append(new_category)
            
            if self.data_manager.save_data('categories', categories):
                await message.answer(f"✅ دسته‌بندی '{name}' با موفقیت اضافه شد!")
                await self.show_categories(message)
            else:
                await message.answer("❌ خطا در ذخیره دسته‌بندی!")
                
        except Exception as e:
            await message.answer(f"❌ خطا در افزودن دسته‌بندی: {str(e)}")
    
    async def edit_category(self, message: Message, edit_data: str):
        """ویرایش دسته‌بندی"""
        try:
            parts = edit_data.split('|')
            if len(parts) != 3:
                await message.answer("❌ فرمت نادرست! استفاده کنید: ویرایش دسته: شماره | نام جدید | توضیحات جدید")
                return
            
            category_id = int(parts[0].strip())
            new_name = parts[1].strip()
            new_description = parts[2].strip()
            
            categories = self.data_manager.get_categories()
            category_found = False
            
            for i, category in enumerate(categories):
                if category['id'] == category_id:
                    categories[i]['name'] = new_name
                    categories[i]['description'] = new_description
                    category_found = True
                    break
            
            if not category_found:
                await message.answer("❌ دسته‌بندی با این شماره پیدا نشد!")
                return
            
            if self.data_manager.save_data('categories', categories):
                await message.answer(f"✅ دسته‌بندی شماره {category_id} با موفقیت ویرایش شد!")
                await self.show_categories(message)
            else:
                await message.answer("❌ خطا در ذخیره تغییرات!")
                
        except ValueError:
            await message.answer("❌ شماره دسته‌بندی نامعتبر است!")
        except Exception as e:
            await message.answer(f"❌ خطا در ویرایش: {str(e)}")
    
    async def delete_category(self, message: Message, category_id_str: str):
        """حذف دسته‌بندی"""
        try:
            category_id = int(category_id_str.strip())
            
            categories = self.data_manager.get_categories()
            category_to_delete = None
            
            for category in categories:
                if category['id'] == category_id:
                    category_to_delete = category
                    break
            
            if not category_to_delete:
                await message.answer("❌ دسته‌بندی با این شماره پیدا نشد!")
                return
            
            # بررسی وجود محصول در این دسته
            products_in_category = self.data_manager.get_products_by_category(category_id)
            if products_in_category:
                await message.answer(
                    f"❌ نمی‌توان این دسته‌بندی را حذف کرد!\n"
                    f"ابتدا {len(products_in_category)} محصول موجود در این دسته را حذف کنید."
                )
                return
            
            # حذف دسته‌بندی
            categories = [cat for cat in categories if cat['id'] != category_id]
            
            if self.data_manager.save_data('categories', categories):
                await message.answer(f"✅ دسته‌بندی '{category_to_delete['name']}' با موفقیت حذف شد!")
                await self.show_categories(message)
            else:
                await message.answer("❌ خطا در حذف دسته‌بندی!")
                
        except ValueError:
            await message.answer("❌ شماره دسته‌بندی نامعتبر است!")
        except Exception as e:
            await message.answer(f"❌ خطا در حذف: {str(e)}")
    
    async def toggle_category_status(self, message: Message, category_id_str: str):
        """تغییر وضعیت فعال/غیرفعال دسته‌بندی"""
        try:
            category_id = int(category_id_str.strip())
            
            categories = self.data_manager.get_categories()
            category_found = False
            
            for i, category in enumerate(categories):
                if category['id'] == category_id:
                    categories[i]['active'] = not categories[i].get('active', True)
                    new_status = "فعال" if categories[i]['active'] else "غیرفعال"
                    category_found = True
                    break
            
            if not category_found:
                await message.answer("❌ دسته‌بندی با این شماره پیدا نشد!")
                return
            
            if self.data_manager.save_data('categories', categories):
                await message.answer(f"✅ وضعیت دسته‌بندی به '{new_status}' تغییر یافت!")
                await self.show_categories(message)
            else:
                await message.answer("❌ خطا در تغییر وضعیت!")
                
        except ValueError:
            await message.answer("❌ شماره دسته‌بندی نامعتبر است!")
        except Exception as e:
            await message.answer(f"❌ خطا: {str(e)}")
    
    async def get_category_stats(self, message: Message):
        """نمایش آمار دسته‌بندی‌ها"""
        categories = self.data_manager.get_categories()
        products = self.data_manager.get_products()
        
        if not categories:
            await message.answer("📊 هیچ دسته‌بندی موجود نیست.")
            return
        
        text = "📊 آمار دسته‌بندی‌ها:\n\n"
        
        total_categories = len(categories)
        active_categories = len([cat for cat in categories if cat.get('active', True)])
        
        text += f"📂 کل دسته‌بندی‌ها: {total_categories}\n"
        text += f"✅ فعال: {active_categories}\n"
        text += f"❌ غیرفعال: {total_categories - active_categories}\n\n"
        
        text += "📋 جزئیات هر دسته:\n"
        text += "─" * 30 + "\n"
        
        for category in categories:
            category_products = [p for p in products if p.get('category_id') == category['id']]
            active_products = [p for p in category_products if p.get('active', True)]
            
            status_emoji = "✅" if category.get('active', True) else "❌"
            text += f"{status_emoji} {category['name']}\n"
            text += f"   📦 محصولات: {len(category_products)} (فعال: {len(active_products)})\n"
            
            if category_products:
                # محبوب‌ترین محصول در این دسته
                orders = self.data_manager.get_orders()
                product_sales = {}
                
                for order in orders:
                    if order.get('status') == OrderStatus.DELIVERED:
                        for item in order.get('items', []):
                            product_id = item.get('product_id')
                            if any(p['id'] == product_id and p.get('category_id') == category['id'] for p in products):
                                product_sales[product_id] = product_sales.get(product_id, 0) + item.get('quantity', 0)
                
                if product_sales:
                    top_product_id = max(product_sales.keys(), key=lambda x: product_sales[x])
                    top_product = next((p for p in products if p['id'] == top_product_id), None)
                    if top_product:
                        text += f"   🏆 پرفروش: {top_product['name']} ({product_sales[top_product_id]} فروش)\n"
            
            text += "\n"
        
        await message.answer(text)
