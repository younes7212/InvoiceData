# menus/admin/admin_main.py - تصحیح شده
from aiogram.types import Message
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from utils.keyboards import Keyboards
from config import SHOP_NAME
from aiogram import F, Dispatcher, Bot
from config import MAIN_ADMIN_ID, OrderStatus
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
import jdatetime

shamsi_now = jdatetime.datetime.now().strftime("%Y/%m/%d - %H:%M")

class OrderStates(StatesGroup):
    awaiting_custom_time = State()


async def show_admin_menu(message: Message, user_manager: UserManager, data_manager: DataManager):
    """نمایش منوی ادمین"""
    # آمار کلی
    users_count = len(data_manager.get_users())
    orders_count = len(data_manager.get_orders())
    products_count = len(data_manager.get_active_products())
    
    # محاسبه درآمد کل
    orders = data_manager.get_orders()
    total_revenue = sum(order.get('total', 0) for order in orders)
    
    admin_text = f"""
👨‍💼 پنل مدیریت {SHOP_NAME}

📊 آمار کلی:
👥 تعداد کاربران: {users_count}
🛍 تعداد سفارشات: {orders_count}
📦 تعداد محصولات: {products_count}
💰 درآمد کل: {total_revenue:,} تومان

🔧 امکانات مدیریت:
📦 مدیریت محصولات
🛍 مدیریت سفارشات
👥 مدیریت کاربران
📊 آمار و گزارشات
💬 ارسال پیام همگانی
    """
    
    await message.answer(admin_text, reply_markup=Keyboards.admin_menu())

from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from datetime import datetime


async def dispatch_receipt_to_admins(bot: Bot, data_manager: DataManager, user_manager: UserManager, receipt_data: dict):
    user_id = receipt_data["user_id"]
    order = data_manager.get_latest_order_for_user(user_id)
    cart = order.get("cart", [])
    products = data_manager.load_data("products")
    user_obj = data_manager.get_user_by_id(user_id)

    user_name = user_obj.get("name", f"کاربر {user_id}") if user_obj else f"کاربر {user_id}"
    user_phone = user_obj.get("phone", "نامشخص") if user_obj else "نامشخص"
    user_address = user_obj.get("address", "نامشخص") if user_obj else "نامشخص"

    product_lines = ""
    for item in order["cart"].get("products", []):
        product = next((p for p in products if int(p.get("id")) == int(item["id"])), None)
        if product:
            name = product["name"]
            price = product["price"]
            quantity = item["quantity"]
            total = price * quantity
            product_lines += f"• {name} × {quantity} ({total:,} تومان)\n"

    caption = (
        f"🧾 فیش پرداخت جدید\n"
        f"👤 کاربر: {user_id}\n"
        f"🆔 سفارش: {order['id']}\n\n"
        f"📦 محصولات:\n{product_lines}\n\n"
        f"💰 مبلغ کل: {order.get('total', 0):,} تومان\n"
        f"👤 نام کاربر: {user_name}\n"
        f"📞 شماره تماس: {user_phone}\n"
        f"📍 آدرس: {user_address}\n"
        f"⏱ زمان ارسال: {receipt_data['timestamp']}"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ تأیید پرداخت", callback_data=f"confirm_receipt_{user_id}"),
            InlineKeyboardButton(text="❌ رد فیش", callback_data=f"reject_receipt_{user_id}")
        ]
    ])

    admin_ids = [
        user["user_id"]
        for user in data_manager.get_users()
        if user.get("role") == "admin" or user["user_id"] == MAIN_ADMIN_ID
    ]

    admin_message_ids = {}

    for admin_id in admin_ids:
        try:
            if receipt_data["type"] == "photo":
                msg = await bot.send_photo(
                    chat_id=admin_id,
                    photo=receipt_data["file_id"],
                    caption=caption,
                    reply_markup=keyboard
                )
            else:
                msg = await bot.send_message(
                    chat_id=admin_id,
                    text=f"{caption}\n\n📝 توضیح:\n{receipt_data.get('text', '---')}",
                    reply_markup=keyboard
                )

            admin_message_ids[admin_id] = msg.message_id

        except Exception as e:
            print(f"❌ ارسال فیش به مدیر {admin_id} ناموفق بود: {e}")

    order["admin_message_ids"] = admin_message_ids
    data_manager.update_orders(order["id"], order)


async def confirm_receipt(callback: CallbackQuery, data_manager: DataManager):
    user_id = int(callback.data.split("_")[-1])
    order = data_manager.get_latest_order_for_user(user_id)

    if not order:
        await callback.answer("❌ سفارش پیدا نشد.", show_alert=True)
        return

    success = data_manager.update_order_status(order["id"], OrderStatus.CONFIRMED)
    if not success:
        await callback.answer("❌ خطا در تأیید پرداخت.", show_alert=True)
        return

    await callback.message.edit_reply_markup()
    await callback.answer("✅ پرداخت تأیید شد.")

    # اطلاع‌رسانی به مشتری
    try:
        await callback.bot.send_message(
            chat_id=user_id,
            text=(
                f"✅ پرداخت شما با موفقیت تأیید شد.\n"
                f"🆔 شناسه سفارش: {order['id']}\n"
                f"📦 سفارش شما در حال آماده‌سازی است."
            )
        )
    except Exception as e:
        print(f"❌ ارسال پیام به کاربر ناموفق بود: {e}")

    # ساخت دکمه‌های زمان آماده‌سازی
    time_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⏱ 30 دقیقه", callback_data=f"prep_time_30_{order['id']}"),
            InlineKeyboardButton(text="⏱ 1 ساعت", callback_data=f"prep_time_60_{order['id']}")
        ],
        [
            InlineKeyboardButton(text="📅 1 روز", callback_data=f"prep_time_1440_{order['id']}"),
            InlineKeyboardButton(text="📝 تعیین دستی", callback_data=f"prep_time_custom_{order['id']}")
        ]
    ])

    # آپدیت پیام همه مدیرها
    admin_message_ids = order.get("admin_message_ids", {})
    receipt_type = order.get("receipt", {}).get("type", "text")

    for admin_id, msg_id in admin_message_ids.items():
        try:
            message_text = (
                f"📌 سفارش {order['id']} برای کاربر {user_id} تأیید شد.\n"
                f"✅ وضعیت: پرداخت انجام شده\n\n"
                f"⏱ لطفاً زمان آماده‌سازی سفارش را انتخاب کنید:"
            )

            if receipt_type == "photo":
                await callback.bot.edit_message_caption(
                    chat_id=admin_id,
                    message_id=msg_id,
                    caption=message_text,
                    reply_markup=time_keyboard
                )
            else:
                await callback.bot.edit_message_text(
                    chat_id=admin_id,
                    message_id=msg_id,
                    text=message_text,
                    reply_markup=time_keyboard
                )

        except Exception as e:
            print(f"❌ ویرایش پیام مدیر {admin_id} ناموفق بود: {e}")


from datetime import datetime, timedelta
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

async def set_preparation_time(callback: CallbackQuery, state: FSMContext, data_manager: DataManager):
    parts = callback.data.split("_")
    if parts[2] == "custom":
        order_id = int(parts[3])
        await state.set_state(OrderStates.awaiting_custom_time)
        await state.update_data(order_id=order_id)
        await callback.message.answer(
        "📝 لطفاً زمان آماده‌سازی را وارد کنید:\n"
        "مثلاً: 45 دقیقه، 2 ساعت، 3 روز یا تاریخ دقیق مثل 1404/06/18 - 15:30")
        await callback.answer()
        return
    minutes = int(parts[2])  # 30, 60, 1440
    order_id = int(parts[3])

    order = data_manager.get_order_by_id(order_id)
    if not order:
        await callback.answer("❌ سفارش پیدا نشد.", show_alert=True)
        return

    # محاسبه زمان آماده‌سازی
    ready_time = datetime.now() + timedelta(minutes=minutes)
    shamsi_ready = jdatetime.datetime.fromgregorian(datetime=ready_time)
    formatted_time = shamsi_ready.strftime("%Y/%m/%d - %H:%M")

    # بروزرسانی سفارش
    order["status"] = OrderStatus.PREPARING
    order["ready_at"] = formatted_time
    data_manager.update_orders(order_id, order)

    await callback.answer("⏱ زمان آماده‌سازی ثبت شد.")

    # دکمه ارسال شد
    send_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 ارسال شد", callback_data=f"mark_sent_{order_id}")]
    ])

    # پیام برای مدیرها
    admin_message_ids = order.get("admin_message_ids", {})
    receipt_type = order.get("receipt", {}).get("type", "text")
    user_id = order["user_id"]

    for admin_id, msg_id in admin_message_ids.items():
        try:
            message_text = (
                f"📦 سفارش {order_id} برای کاربر {user_id} در حال آماده‌سازی است.\n"
                f"⏱ زمان آماده‌سازی: {formatted_time}"
            )

            if receipt_type == "photo":
                await callback.bot.edit_message_caption(
                    chat_id=admin_id,
                    message_id=msg_id,
                    caption=message_text,
                    reply_markup=send_keyboard
                )
            else:
                await callback.bot.edit_message_text(
                    chat_id=admin_id,
                    message_id=msg_id,
                    text=message_text,
                    reply_markup=send_keyboard
                )
        except Exception as e:
            print(f"❌ ویرایش پیام مدیر {admin_id} ناموفق بود: {e}")

    # پیام برای مشتری
    try:
        await callback.bot.send_message(
            chat_id=user_id,
            text=(
                f"📦 سفارش شما در حال آماده‌سازی است.\n"
                f"⏱ زمان آماده‌سازی: {formatted_time}"
            )
        )
    except Exception as e:
        print(f"❌ ارسال پیام به مشتری ناموفق بود: {e}")
    
async def receive_custom_time(message: Message, state: FSMContext, data_manager: DataManager):
    user_input = message.text.strip()
    data = await state.get_data()
    order_id = data.get("order_id")

    try:
        if "روز" in user_input:
            days = int(user_input.split()[0])
            ready_time = datetime.now() + timedelta(days=days)
        elif "ساعت" in user_input:
            hours = int(user_input.split()[0])
            ready_time = datetime.now() + timedelta(hours=hours)
        elif "دقیقه" in user_input:
            minutes = int(user_input.split()[0])
            ready_time = datetime.now() + timedelta(minutes=minutes)
        else:
            ready_time = datetime.strptime(user_input, "%Y/%m/%d - %H:%M")

        shamsi_ready = jdatetime.datetime.fromgregorian(datetime=ready_time)
        formatted_time = shamsi_ready.strftime("%Y/%m/%d - %H:%M")


    except Exception:
        await message.answer(
            "❌ فرمت زمان نامعتبر است.\n"
            "فاصله بین عدد و کلمه اجباری است\n"
            "مثال‌های معتبر:\n"
            "🔹 2 ساعت\n🔹 45 دقیقه\n🔹 1 روز\n🔹 2025/09/08 - 14:00"
        )
        return

    order = data_manager.get_order_by_id(order_id)
    if not order:
        await message.answer("❌ سفارش پیدا نشد.")
        return

    order["status"] = OrderStatus.PREPARING
    order["ready_at"] = formatted_time
    data_manager.update_orders(order_id, order)

    await message.answer(f"✅ زمان آماده‌سازی ثبت شد: {formatted_time}")
    await state.clear()

    # ساخت دکمه ارسال
    send_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 ارسال شد", callback_data=f"mark_sent_{order_id}")]
    ])

    # پیام برای مدیرها
    admin_message_ids = order.get("admin_message_ids", {})
    receipt_type = order.get("receipt", {}).get("type", "text")
    user_id = order["user_id"]

    for admin_id, msg_id in admin_message_ids.items():
        try:
            message_text = (
                f"📦 سفارش {order_id} برای کاربر {user_id} در حال آماده‌سازی است.\n"
                f"⏱ زمان آماده‌سازی: {formatted_time}"
            )

            if receipt_type == "photo":
                await message.bot.edit_message_caption(
                    chat_id=admin_id,
                    message_id=msg_id,
                    caption=message_text,
                    reply_markup=send_keyboard
                )
            else:
                await message.bot.edit_message_text(
                    chat_id=admin_id,
                    message_id=msg_id,
                    text=message_text,
                    reply_markup=send_keyboard
                )
        except Exception as e:
            print(f"❌ ویرایش پیام مدیر {admin_id} ناموفق بود: {e}")

    # پیام برای مشتری
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                f"📦 سفارش شما در حال آماده‌سازی است.\n"
                f"⏱ زمان آماده‌سازی: {formatted_time}"
            )
        )
    except Exception as e:
        print(f"❌ ارسال پیام به مشتری ناموفق بود: {e}")
async def mark_order_sent(callback: CallbackQuery, data_manager: DataManager):
    try:
        order_id = int(callback.data.split("_")[-1])
        order = data_manager.get_order_by_id(order_id)

        if not order:
            await callback.answer("❌ سفارش پیدا نشد.", show_alert=True)
            return

        order["status"] = OrderStatus.SENT
        data_manager.update_orders(order_id, order)

        receipt_type = order.get("receipt", {}).get("type", "text")
        user_id = order["user_id"]
        message_text = (
            f"📦 سفارش {order_id} برای کاربر {user_id} ارسال شد.\n"
            f"✅ وضعیت: ارسال شده"
        )

        # آپدیت پیام همه مدیرها
        admin_message_ids = order.get("admin_message_ids", {})
        for admin_id, msg_id in admin_message_ids.items():
            try:
                if receipt_type == "photo":
                    await callback.bot.edit_message_caption(
                        chat_id=admin_id,
                        message_id=msg_id,
                        caption=message_text,
                        reply_markup=None
                    )
                else:
                    await callback.bot.edit_message_text(
                        chat_id=admin_id,
                        message_id=msg_id,
                        text=message_text,
                        reply_markup=None
                    )
            except Exception as e:
                print(f"❌ ویرایش پیام مدیر {admin_id} ناموفق بود: {e}")

        await callback.answer("✅ سفارش به عنوان ارسال‌شده ثبت شد.")

        # پیام برای مشتری
        await callback.bot.send_message(
            chat_id=user_id,
            text=(
                f"📦 سفارش شما ارسال شد!\n"
                f"🆔 شناسه سفارش: {order_id}\n"
                f"✅ وضعیت: ارسال شده"
            )
        )

    except Exception as e:
        print(f"❌ خطا در ثبت ارسال سفارش: {e}")
        await callback.answer("❌ خطا در پردازش درخواست.", show_alert=True)

async def reject_receipt(callback: CallbackQuery, data_manager: DataManager):
    try:
        user_id = int(callback.data.split("_")[-1])
        order = data_manager.get_latest_order_for_user(user_id)

        if not order:
            await callback.answer("❌ سفارش پیدا نشد.", show_alert=True)
            return

        order["status"] = OrderStatus.CANCELLED
        data_manager.update_order_status(order["id"], "لغو شده")

        # پیام برای مدیرها
        receipt_type = order.get("receipt", {}).get("type", "text")
        admin_message_ids = order.get("admin_message_ids", {})
        message_text = (
            f"❌ سفارش {order['id']} برای کاربر {user_id} لغو شد.\n"
            f"🛑 وضعیت: لغو شده"
        )

        for admin_id, msg_id in admin_message_ids.items():
            try:
                if receipt_type == "photo":
                    await callback.bot.edit_message_caption(
                        chat_id=admin_id,
                        message_id=msg_id,
                        caption=message_text,
                        reply_markup=None
                    )
                else:
                    await callback.bot.edit_message_text(
                        chat_id=admin_id,
                        message_id=msg_id,
                        text=message_text,
                        reply_markup=None
                    )
            except Exception as e:
                print(f"❌ ویرایش پیام مدیر {admin_id} ناموفق بود: {e}")

        await callback.answer("❌ سفارش لغو شد.")

        # پیام برای مشتری
        await callback.bot.send_message(
            chat_id=user_id,
            text=(
                f"❌ سفارش شما لغو شد.\n"
                f"🆔 شناسه سفارش: {order['id']}\n"
                f"🛑 وضعیت: لغو شده"
            )
        )

    except Exception as e:
        print(f"❌ خطا در لغو سفارش: {e}")
        await callback.answer("❌ خطا در پردازش درخواست.", show_alert=True)

def register_main_handlers(dp: Dispatcher, data_manager: DataManager):
    from functools import partial

    dp.callback_query.register(
        partial(confirm_receipt, data_manager=data_manager),
        F.data.startswith("confirm_receipt_")
    )

    dp.callback_query.register(
        partial(set_preparation_time, data_manager=data_manager),
        F.data.startswith("prep_time_")
    )

    dp.message.register(
        partial(receive_custom_time, data_manager=data_manager),
        StateFilter(OrderStates.awaiting_custom_time)
    )
    dp.callback_query.register(
        partial(mark_order_sent, data_manager=data_manager),
        F.data.startswith("mark_sent_")
    )
    dp.callback_query.register(
        partial(reject_receipt, data_manager=data_manager),
        F.data.startswith("reject_receipt_")
    )
