import jwt, time, requests, base64, json

APP_ID = '1946795'
INSTALLATION_ID = '85725722'  # بعداً می‌گیریمش
REPO = 'younes7212/InvoiceData'
FILE_PATH = 'Invoice.json'

with open('private-key.pem', 'r') as f:
    PRIVATE_KEY = f.read()

now = int(time.time())
payload = {
    'iat': now,
    'exp': now + 600,
    'iss': APP_ID
}
jwt_token = jwt.encode(payload, PRIVATE_KEY, algorithm='RS256')

# گرفتن installation token
# گرفتن installation token
headers = {
    'Authorization': f'Bearer {jwt_token}',
    'Accept': 'application/vnd.github+json'
}
url = f'https://api.github.com/app/installations/{INSTALLATION_ID}/access_tokens'
res = requests.post(url, headers=headers)

print("توکن گرفتن - وضعیت:", res.status_code)
print("پاسخ GitHub:", res.text)

token = res.json().get('token')
if not token:
    print("❌ GitHub توکن نداد. احتمالاً مشکل دسترسی یا تنظیمات App هست.")
    exit()
# ساخت داده فاکتور
invoice_data = {
    "id": 3,
    "user": {
        "id": 83859402,
        "name": "امیر سلطانی",
        "phone": "09123456789",
        "address": "تهران، خیابان آزادی، پلاک ۱۲، واحد ۴"
    },
    "status": "تکمیل شده",
    "ready_at": "1404/06/19 - 12:16",
    "products": [
        {
            "id": 2,
            "name": "چیزبرگر",
            "unit_price": 65000,
            "quantity": 2,
            "total_price": 130000
        }
    ],
    "total": 130000,
    "tax": 11700,
    "final": 141700,
    "receipt": {
        "type": "text",
        "text": "پرداخت با موفقیت انجام شد",
        "file_id": None
    }
}

# بررسی وجود فایل
api_url = f'https://api.github.com/repos/{REPO}/contents/{FILE_PATH}'
headers = {
    'Authorization': f'Bearer {token}',
    'Accept': 'application/vnd.github+json'
}
res = requests.get(api_url, headers=headers)
sha = res.json().get('sha') if res.status_code == 200 else None

# ارسال فایل
json_str = json.dumps(invoice_data, ensure_ascii=False, indent=2)
encoded = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
payload = {
    "message": "آپدیت فاکتور",
    "content": encoded,
    "branch": "main"
}
if sha:
    payload["sha"] = sha

res = requests.put(api_url, headers=headers, json=payload)
print("وضعیت:", res.status_code)
