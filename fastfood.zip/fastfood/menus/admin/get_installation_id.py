import jwt, time, requests

APP_ID = '1946795'
with open('private-key.pem', 'r') as f:
    PRIVATE_KEY = f.read()

now = int(time.time())
payload = {
    'iat': now,
    'exp': now + 600,
    'iss': APP_ID
}
jwt_token = jwt.encode(payload, PRIVATE_KEY, algorithm='RS256')

headers = {
    'Authorization': f'Bearer {jwt_token}',
    'Accept': 'application/vnd.github+json'
}

res = requests.get('https://api.github.com/app/installations', headers=headers)
print("Status:", res.status_code)
print("Body:", res.text)
