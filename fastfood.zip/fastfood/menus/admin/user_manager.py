from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from aiogram.types import Message
from aiogram import Dispatcher, F
from aiogram.types import CallbackQuery

class UserManagerAdmin:
    def __init__(self, bot, user_manager: UserManager, data_manager: DataManager):
        self.user_manager = user_manager
        self.data_manager = data_manager

    async def show_users(self, message: Message):
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 لیست کاربران", callback_data="admin_list_users")],
            [InlineKeyboardButton(text="👨‍💼 لیست مدیران", callback_data="admin_list_admins")],
            [InlineKeyboardButton(text="✅ انتخاب مدیر", callback_data="admin_promote_user")],
            [InlineKeyboardButton(text="❌ حذف کاربر", callback_data="admin_delete_user")]
        ])
        await message.answer("🔧 مدیریت کاربران:", reply_markup=keyboard)



    async def list_users(self, callback: CallbackQuery, page: int = 0):
        users = self.data_manager.get_users()
        if not users:
            await callback.message.edit_text("❌ هیچ کاربری ثبت نشده است.")
            return

        page_size = 8
        start = page * page_size
        end = start + page_size
        total_pages = (len(users) - 1) // page_size + 1

        current_users = users[start:end]

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text=user.get('username', f"کاربر {user.get('user_id')}"),
                callback_data=f"user_info_{user.get('user_id')}"
            )] for user in current_users
        ])

        # دکمه‌های ناوبری (صفحه بعد / قبلی)
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"user_page_{page - 1}"))
        if end < len(users):
            nav_buttons.append(InlineKeyboardButton(text="➡️ بعدی", callback_data=f"user_page_{page + 1}"))
        if nav_buttons:
            keyboard.inline_keyboard.append(nav_buttons)

        # دکمه بازگشت به منوی مدیریت کاربران
        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin_back_to_user_menu")
        ])

        await callback.message.edit_text(f"📋 لیست کاربران (صفحه {page + 1} از {total_pages}):", reply_markup=keyboard)

        await callback.message.edit_text(text)

    async def handle_user_callbacks(self, callback: CallbackQuery):
        data = callback.data

        # صفحه‌بندی لیست کاربران
        if data.startswith("user_page_"):
            page = int(data.split("_")[-1])
            await self.list_users(callback, page)

        # نمایش اطلاعات کامل کاربر
        elif data.startswith("user_info_"):
            user_id = int(data.split("_")[-1])
            user = self.data_manager.get_user_by_id(user_id)

            if not user:
                await callback.message.edit_text("❌ کاربر مورد نظر یافت نشد.")
                return

            text = (
                f"🧾 اطلاعات کامل کاربر:\n\n"
                f"🆔 شناسه: {user.get('user_id')}\n"
                f"👤 نام کاربری: {user.get('username', 'نامشخص')}\n"
                f"📛 نام: {user.get('name', 'نامشخص')}\n"
                f"📞 شماره تلفن: {user.get('phone', 'نامشخص')}\n"
                f"📍 آدرس: {user.get('address', 'نامشخص')}\n"
                f"📅 تاریخ ثبت‌نام: {user.get('created_at', '---')}\n"
            )

            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin_list_users")]
            ])

            await callback.message.edit_text(text, reply_markup=keyboard)

        # بازگشت به منوی مدیریت کاربران
        elif data == "admin_back_to_user_menu":
            await self.back_to_user_menu(callback)

        elif data.startswith("admin_info_"):
            user_id = int(data.split("_")[-1])
            admin = self.data_manager.get_user_by_id(user_id)

            if not admin or admin.get("role") != "admin":
                await callback.message.edit_text("❌ مدیر مورد نظر یافت نشد.")
                return

            text = (
                f"👨‍💼 اطلاعات مدیر:\n\n"
                f"🆔 شناسه: {admin.get('user_id')}\n"
                f"👤 نام کاربری: {admin.get('username', 'نامشخص')}\n"
                f"📛 نام: {admin.get('name', 'نامشخص')}\n"
                f"📞 شماره تلفن: {admin.get('phone', 'نامشخص')}\n"
                f"📍 آدرس: {admin.get('address', 'نامشخص')}\n"
                f"📅 تاریخ ثبت‌نام: {admin.get('created_at', '---')}\n"
            )

            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin_list_admins")]
            ])

            await callback.message.edit_text(text, reply_markup=keyboard)


    async def list_admins(self, callback: CallbackQuery, page: int = 0):
        admins = [user for user in self.data_manager.get_users() if user.get("role") == "admin"]
        if not admins:
            await callback.message.edit_text("❌ هیچ مدیری ثبت نشده است.")
            return

        page_size = 8
        start = page * page_size
        end = start + page_size
        total_pages = (len(admins) - 1) // page_size + 1
        current_admins = admins[start:end]

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text=admin.get('username', f"مدیر {admin.get('user_id')}"),
                callback_data=f"admin_info_{admin.get('user_id')}"
            )] for admin in current_admins
        ])

        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"admin_page_{page - 1}"))
        if end < len(admins):
            nav_buttons.append(InlineKeyboardButton(text="➡️ بعدی", callback_data=f"admin_page_{page + 1}"))
        if nav_buttons:
            keyboard.inline_keyboard.append(nav_buttons)

        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin_back_to_user_menu")
        ])

        await callback.message.edit_text(f"👨‍💼 لیست مدیران (صفحه {page + 1} از {total_pages}):", reply_markup=keyboard)

    async def show_user_selection_for_admin(self, callback: CallbackQuery, page: int = 0):
        users = self.data_manager.get_users()
        if not users:
            await callback.message.edit_text("❌ هیچ کاربری ثبت نشده است.")
            return

        page_size = 8
        start = page * page_size
        end = start + page_size
        total_pages = (len(users) - 1) // page_size + 1
        current_users = users[start:end]

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text=user.get('username', f"کاربر {user.get('user_id')}"),
                callback_data=f"promote_to_admin_{user.get('user_id')}"
            )] for user in current_users
        ])

        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"select_admin_page_{page - 1}"))
        if end < len(users):
            nav_buttons.append(InlineKeyboardButton(text="➡️ بعدی", callback_data=f"select_admin_page_{page + 1}"))
        if nav_buttons:
            keyboard.inline_keyboard.append(nav_buttons)

        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text="🔙 بازگشت", callback_data="admin_back_to_user_menu")
        ])

        await callback.message.edit_text(f"👥 انتخاب مدیر (صفحه {page + 1} از {total_pages}):", reply_markup=keyboard)

    async def promote_user_to_admin(self, callback: CallbackQuery):
        user_id = int(callback.data.split("_")[-1])
        user = self.data_manager.get_user_by_id(user_id)

        if not user:
            await callback.message.edit_text("❌ کاربر مورد نظر یافت نشد.")
            return

        user["role"] = "admin"
        self.data_manager.update_user(user["user_id"], {"role": "admin"})

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="select_admin_page")]
        ])

        await callback.message.edit_text(
            f"✅ کاربر {user.get('username', 'بدون نام')} با موفقیت به مدیر ارتقاء یافت.",
            reply_markup=keyboard
        )

    async def back_to_user_list(self, callback: CallbackQuery):
        await self.list_users(callback, page=0)

    async def back_to_user_menu(self, callback: CallbackQuery):
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 لیست کاربران", callback_data="admin_list_users")],
            [InlineKeyboardButton(text="👨‍💼 لیست مدیران", callback_data="admin_list_admins")],
            [InlineKeyboardButton(text="✅ انتخاب مدیر", callback_data="admin_promote_user")],
            [InlineKeyboardButton(text="❌ حذف کاربر", callback_data="admin_delete_user")]
        ])
        await callback.message.edit_text("🔧 مدیریت کاربران:", reply_markup=keyboard)

    def register_handlers_users(self, dp: Dispatcher):
        dp.message.register(self.show_users, F.text == "👥 مدیریت کاربران")
        dp.callback_query.register(self.list_users, F.data == "admin_list_users")
        dp.callback_query.register(self.handle_user_callbacks, F.data.startswith("user_page_"))
        dp.callback_query.register(self.handle_user_callbacks, F.data.startswith("user_info_"))
        dp.callback_query.register(self.back_to_user_list, F.data == "admin_list_users")
        dp.callback_query.register(self.back_to_user_menu, F.data == "admin_back_to_user_menu")
        dp.callback_query.register(self.list_admins, F.data == "admin_list_admins")
        dp.callback_query.register(self.handle_user_callbacks, F.data.startswith("admin_page_"))
        dp.callback_query.register(self.handle_user_callbacks, F.data.startswith("admin_info_"))
        dp.callback_query.register(self.show_user_selection_for_admin, F.data == "admin_promote_user")
        dp.callback_query.register(self.show_user_selection_for_admin, F.data.startswith("select_admin_page_"))
        dp.callback_query.register(self.promote_user_to_admin, F.data.startswith("promote_to_admin_"))
