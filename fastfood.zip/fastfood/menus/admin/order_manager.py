from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram import F, Bot, Dispatcher
from typing import Optional
from utils.user_manager import UserManager
from utils.data_manager import DataManager
from datetime import date
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from config import OrderStatus
import jdatetime
import re

def remove_emojis(text):
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"  # شکلک‌های احساسی
        u"\U0001F300-\U0001F5FF"  # نمادها و اشکال
        u"\U0001F680-\U0001F6FF"  # وسایل نقلیه
        u"\U0001F1E0-\U0001F1FF"  # پرچم‌ها
        "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', text)


class OrderStates(StatesGroup):
    setting_min_order = State()
    waiting_for_store_location = State()
    waiting_for_radius = State()
    waiting_for_city_action = State()
    waiting_for_city_name = State()
    waiting_for_city_edit = State()
    waiting_for_city_delete = State()

PAGE_SIZE = 5  # تعداد سفارش در هر صفحه

class OrderManager:
    def __init__(self, bot: Bot, data_manager: DataManager, user_manager: UserManager):
        self.bot = bot
        self.data_manager = data_manager
        self.user_manager = user_manager

    def get_points_toggle_menu(self):
        return InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ فعال‌سازی", callback_data="enable_points"),
                InlineKeyboardButton(text="❌ غیرفعال‌سازی", callback_data="disable_points")
            ],
            [
                InlineKeyboardButton(text="🔢 نرخ امتیاز", callback_data="edit_earning_rate"),
                InlineKeyboardButton(text="📏 سقف امتیاز سفارش", callback_data="edit_max_per_order")
            ],
            [
                InlineKeyboardButton(text="🎁 نرخ تبدیل تخفیف", callback_data="edit_redeem_rate"),
                InlineKeyboardButton(text="💰 مبلغ تخفیف هر امتیاز", callback_data="edit_redeem_value")
            ],
            [
                InlineKeyboardButton(text="🔄 فعال/غیرفعال تخفیف", callback_data="toggle_redeem")
            ],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_order_menu")]
        ])

    def get_order_menu(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="📦 نمایش سفارشات", callback_data="show_orders")],
                [InlineKeyboardButton(text="⚙️ حداقل مبلغ سفارش", callback_data="set_min_order")],
                [InlineKeyboardButton(text="📍 محدودیت موقعیت مکانی", callback_data="location_limit_menu")],
                [InlineKeyboardButton(text="⭐️ مدیریت امتیازات", callback_data="manage_points")],
                [InlineKeyboardButton(text="📊 آمار مالی", callback_data="order_stats")],
                [InlineKeyboardButton(text="🧍‍♂️ سفارشات یک کاربر", callback_data="user_orders")],
                [InlineKeyboardButton(text="🗑 حذف سفارش", callback_data="delete_order")],
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_main")],
            ]
        )

    async def send_main_menu(self, message: Message):
        markup = self.get_order_menu()
        await message.answer("💡 دستورات مدیریت سفارشات:", reply_markup=markup)

    async def back_to_order_menu(self, callback: CallbackQuery):
        markup = self.get_order_menu()
        await callback.message.edit_text("💡 دستورات مدیریت سفارشات:", reply_markup=markup)

    async def handle_manage_points(self, callback: CallbackQuery):
        data = self.data_manager.load_data("points")
        settings = data.get("settings", {})

        status = "✅ فعال" if settings.get("enabled") else "❌ غیرفعال"
        earning_rate = settings.get("earning_rate", 10000)
        max_per_order = settings.get("max_per_order", 100)
        redeem_enabled = settings.get("redeem_enabled", True)
        redeem_rate = settings.get("redeem_rate", 1)
        redeem_value = settings.get("redeem_value", 10000)

        text = (
            f"📊 مدیریت سیستم امتیازدهی\n\n"
            f"وضعیت: {status}\n"
            f"نرخ امتیاز: هر {earning_rate:,} تومان = ۱ امتیاز\n"
            f"سقف امتیاز هر سفارش: {max_per_order} امتیاز\n"
            f"تخفیف: {'✅ فعال' if redeem_enabled else '❌ غیرفعال'}\n"
            f"نرخ تبدیل: هر {redeem_rate} امتیاز = {redeem_value:,} تومان تخفیف"
        )

        await callback.message.edit_text(
            text,
            reply_markup=self.get_points_toggle_menu()
        )

    async def handle_enable_points(self, callback: CallbackQuery):
        result = self.data_manager.enable_points_system()
        await callback.answer("✅ سیستم امتیازدهی فعال شد", show_alert=True)
        data = self.data_manager.load_data("points")
        settings = data.get("settings", {})

        status = "✅ فعال" if settings.get("enabled") else "❌ غیرفعال"
        earning_rate = settings.get("earning_rate", 10000)
        max_per_order = settings.get("max_per_order", 100)
        redeem_enabled = settings.get("redeem_enabled", True)
        redeem_rate = settings.get("redeem_rate", 1)
        redeem_value = settings.get("redeem_value", 10000)

        text = (
            f"📊 مدیریت سیستم امتیازدهی\n\n"
            f"وضعیت: {status}\n"
            f"نرخ امتیاز: هر {earning_rate:,} تومان = ۱ امتیاز\n"
            f"سقف امتیاز هر سفارش: {max_per_order} امتیاز\n"
            f"تخفیف: {'✅ فعال' if redeem_enabled else '❌ غیرفعال'}\n"
            f"نرخ تبدیل: هر {redeem_rate} امتیاز = {redeem_value:,} تومان تخفیف"
        )

        await callback.message.edit_text(
            text,
            reply_markup=self.get_points_toggle_menu()
        )

    async def handle_disable_points(self, callback: CallbackQuery):
        result = self.data_manager.disable_points_system()
        await callback.answer("❌ سیستم امتیازدهی غیرفعال شد", show_alert=True)
        data = self.data_manager.load_data("points")
        settings = data.get("settings", {})

        status = "✅ فعال" if settings.get("enabled") else "❌ غیرفعال"
        earning_rate = settings.get("earning_rate", 10000)
        max_per_order = settings.get("max_per_order", 100)
        redeem_enabled = settings.get("redeem_enabled", True)
        redeem_rate = settings.get("redeem_rate", 1)
        redeem_value = settings.get("redeem_value", 10000)

        text = (
            f"📊 مدیریت سیستم امتیازدهی\n\n"
            f"وضعیت: {status}\n"
            f"نرخ امتیاز: هر {earning_rate:,} تومان = ۱ امتیاز\n"
            f"سقف امتیاز هر سفارش: {max_per_order} امتیاز\n"
            f"تخفیف: {'✅ فعال' if redeem_enabled else '❌ غیرفعال'}\n"
            f"نرخ تبدیل: هر {redeem_rate} امتیاز = {redeem_value:,} تومان تخفیف"
        )

        await callback.message.edit_text(
            text,
            reply_markup=self.get_points_toggle_menu()
        )

    async def handle_edit_earning_rate(self, callback: CallbackQuery):
        await callback.message.edit_text(
            "🔢 لطفاً نرخ امتیاز را وارد کنید:\nمثلاً: 200000 یعنی هر ۲۰۰ هزار تومان = ۱ امتیاز"
        )
        self.waiting_for_setting = "earning_rate"

    async def handle_setting_input(self, message: Message):
        if hasattr(self, "waiting_for_setting") and self.waiting_for_setting == "earning_rate":
            value = message.text.strip()
            if value.isdigit():
                data = self.data_manager.load_data("points")
                data["settings"]["earning_rate"] = int(value)
                self.data_manager.save_data("points", data)
                await message.answer(
                    f"✅ نرخ امتیاز جدید ذخیره شد: هر {value} تومان = ۱ امتیاز",
                    reply_markup=self.get_points_toggle_menu()
                )
            else:
                await message.answer("❌ لطفاً فقط عدد وارد کنید")
            del self.waiting_for_setting

    async def handle_edit_max_per_order(self, callback: CallbackQuery):
        await callback.message.edit_text(
            "📏 لطفاً سقف امتیاز قابل دریافت در هر سفارش را وارد کنید:\nمثلاً: 100"
        )
        self.waiting_for_setting = "max_per_order"

    async def handle_setting_input(self, message: Message):
        if hasattr(self, "waiting_for_setting"):
            value = message.text.strip()
            if value.isdigit():
                data = self.data_manager.load_data("points")
                data["settings"][self.waiting_for_setting] = int(value)
                self.data_manager.save_data("points", data)
                await message.answer(
                    f"✅ مقدار جدید برای سقف امتیاز برای هر سفارش  ذخیره شد: {value}",
                    reply_markup=self.get_points_toggle_menu()
                )
            else:
                await message.answer("❌ لطفاً فقط عدد وارد کنید")
            del self.waiting_for_setting

    def get_order_filter_keyboard(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📋 همه سفارش‌ها", callback_data="filter_orders:ALL")],
            [InlineKeyboardButton(text="در انتظار تایید", callback_data="filter_orders:PENDING"),
             InlineKeyboardButton(text="تایید شده", callback_data="filter_orders:CONFIRMED")],
            [InlineKeyboardButton(text="در حال آماده‌سازی", callback_data="filter_orders:PREPARING"),
             InlineKeyboardButton(text="ارسال شده", callback_data="filter_orders:SENT")],
            [InlineKeyboardButton(text="لغو شده", callback_data="filter_orders:CANCELLED"),
             InlineKeyboardButton(text="امروز", callback_data="filter_orders:TODAY")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_order_menu")]
        ]
    )

    async def show_orders(self, callback: CallbackQuery, page: int = 0):
        kb = self.get_order_filter_keyboard()
        await callback.message.edit_text("📊 لطفاً وضعیت سفارش‌ها را انتخاب کنید:", reply_markup=kb)


    async def handle_order_filter(self, callback: CallbackQuery):
        await callback.answer()

        # استخراج وضعیت و صفحه از callback_data
        parts = callback.data.split(":")
        status_key = parts[1] if len(parts) > 1 else "ALL"
        page = int(parts[2]) if len(parts) > 2 else 0

        status_map = {
            "PENDING": "در انتظار تایید",
            "CONFIRMED": "تایید شده",
            "PREPARING": "در حال آماده‌سازی",
            "READY": "آماده",
            "SENT": "ارسال شده",
            "CANCELLED": "لغو شده"
        }

        all_orders = self.data_manager.get_orders()
        today = jdatetime.date.today().strftime('%Y/%m/%d')

        # فیلتر سفارش‌ها
        if status_key == "TODAY":
            orders = [o for o in all_orders if o["date"] == today]
            title = "📅 سفارش‌های امروز"
        elif status_key == "ALL":
            orders = all_orders
            title = "📋 همه سفارش‌ها"
        else:
            label = status_map.get(status_key)
            orders = [o for o in all_orders if o["status"] == label]
            title = f"📍 سفارش‌های {label}"

        # صفحه‌بندی
        PAGE_SIZE = 10
        total_pages = (len(orders) - 1) // PAGE_SIZE + 1
        page = max(0, min(page, total_pages - 1))
        start, end = page * PAGE_SIZE, (page + 1) * PAGE_SIZE
        selected_orders = orders[start:end]

        # ساخت متن
        text = f"{title}\n\n"
        if not selected_orders:
            text += "❌ هیچ سفارشی یافت نشد."
        else:
            text += "برای مشاهده جزئیات روی سفارش مورد نظر کلیک کنید:\n"

        # ساخت دکمه‌های سفارش
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text=f"🔹 سفارش #{o['id']} | {o['user']} | {o['status']} | {o['date']}",
                callback_data=f"view_order:{o['id']}:{status_key}:{page}"
            )] for o in selected_orders
        ])

        # دکمه‌های ناوبری صفحه
        nav_row = []
        if page > 0:
            nav_row.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"filter_orders:{status_key}:{page-1}"))
        if page < total_pages - 1:
            nav_row.append(InlineKeyboardButton(text="➡️ بعدی", callback_data=f"filter_orders:{status_key}:{page+1}"))
        if nav_row:
            kb.inline_keyboard.append(nav_row)

        # دکمه بازگشت
        kb.inline_keyboard.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_order_filters")])

        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")

    async def handle_view_order(self, callback: CallbackQuery):
        await callback.answer()
        _, order_id, status_key, page = callback.data.split(":")
        order_id = int(order_id)

        # دریافت سفارش کامل از دیتای خام
        raw_orders = self.data_manager.load_data('orders')
        order = next((o for o in raw_orders if o["id"] == order_id), None)
        if not order:
            await callback.message.edit_text("❌ سفارش پیدا نشد.")
            return

        # دریافت اطلاعات کاربر
        user_id = order.get("user_id")
        user_obj = self.data_manager.get_user_by_id(user_id)
        user_name = user_obj.get("name", f"کاربر {user_id}") if user_obj else f"کاربر {user_id}"
        user_phone = user_obj.get("phone", "نامشخص") if user_obj else "نامشخص"
        user_address = user_obj.get("address", "نامشخص") if user_obj else "نامشخص"

        # دریافت اطلاعات رسید
        receipt_data = order.get("receipt", {})
        timestamp = receipt_data.get("timestamp", "نامشخص")
        receipt_text = receipt_data.get("text", "رسید موجود نیست")
        receipt_type = receipt_data.get("type")
        receipt_file_id = receipt_data.get("file_id")

        # ساخت جدول محصولات
        product_lines = ""
        for item in order.get("cart", {}).get("products", []):
            product = self.data_manager.get_product_by_id(item["id"])
            raw_name = product.get("name", f"محصول #{item['id']}")
            name = remove_emojis(raw_name)
            qty = item.get("quantity", 1)

            padding = 33 - len(name)
            space = " " * max(padding, 0)
            product_lines += f"{name}{space}{str(qty)}\n"

        # ساخت متن فاکتور
        caption = (
            f"<b>🧾 فاکتور سفارش #{order['id']}</b>\n"
            f"<pre>"
            f"{'نام کاربر'}:  {user_name}\n"
            f"{'شماره تماس'}:  {user_phone}\n"
            f"{'آدرس'}:  {user_address}\n"
            f"{'زمان ارسال'}:  {order.get('ready_at', 'نامشخص')}\n"
            f"{'وضعیت سفارش'}:  {order.get('status', 'نامشخص')}\n"
            f"{'='*45}\n"
            f"{'🛒 محصولات سفارش‌شده'}\n"
            f"{'محصول':<25} | {'تعداد':<5}\n"
            f"{'-'*45}\n"
            f"{product_lines}"
            f"{'='*45}\n"
            f"{'مبلغ کل':<12}: {order.get('total', 0):,} تومان\n"
            f"{'='*45}\n"
            f"{'رسید پرداخت'}\n"
            f"{receipt_text}\n"
            f"</pre>"
        )

        # ساخت دکمه‌ها
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔄 تغییر وضعیت", callback_data=f"change_status:{order['id']}")],
            [InlineKeyboardButton(text="🗑 حذف سفارش", callback_data=f"confirm_delete:{order_id}:{status_key}:{page}")],
            [InlineKeyboardButton(text="🔙 بازگشت به لیست", callback_data=f"filter_orders:{status_key}:{page}")]
        ])

        await callback.message.edit_text(caption, reply_markup=kb, parse_mode="HTML")

    async def handle_order_page(self, callback: CallbackQuery):
        _, status_key, page = callback.data.split(":")
        await self.handle_order_filter(callback)

    async def handle_set_min_order(self, callback: CallbackQuery, state: FSMContext):
        messages = self.data_manager.load_data("messages")
        min_order = next((item["amount"] for item in messages if item.get("type") == "min_order"), None)

        if min_order is not None:
            text = (
                f"📌 نرخ حداقل سفارش {min_order:,} تومان است.\n\n"
                "💰 لطفاً مبلغ حداقل سفارش را وارد کنید (به تومان):"
            )
        else:
            text = "💰 لطفاً مبلغ حداقل سفارش را وارد کنید (به تومان):"

        await callback.message.edit_text(text)
        await state.set_state(OrderStates.setting_min_order)

    async def handle_change_status(self, callback: CallbackQuery):
        await callback.answer()

        order_id = int(callback.data.split(":")[1])
        from config import OrderStatus

        # لیست وضعیت‌هایی که می‌خوای نمایش داده بشن
        allowed_statuses = [
            OrderStatus.PENDING,
            OrderStatus.CONFIRMED,
            OrderStatus.PREPARING,
            OrderStatus.SENT,
            OrderStatus.CANCELLED
        ]

        status_buttons = [
            [InlineKeyboardButton(text=label, callback_data=f"set_status:{order_id}:{label}")]
            for label in allowed_statuses
        ]

        # دکمه بازگشت به فاکتور
        status_buttons.append([
            InlineKeyboardButton(text="🔙 بازگشت به فاکتور", callback_data=f"view_order:{order_id}:ALL:0")
        ])

        await callback.message.edit_text(
            "🔄 لطفاً وضعیت جدید سفارش را انتخاب کنید:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=status_buttons)
        )

    async def handle_set_status(self, callback: CallbackQuery):
        _, order_id, new_status = callback.data.split(":")
        order_id = int(order_id)

        success = self.data_manager.update_order_status(order_id, new_status)

        if success:
            await callback.answer("✅ وضعیت سفارش با موفقیت تغییر کرد", show_alert=True)
        else:
            await callback.answer("❌ تغییر وضعیت ناموفق بود", show_alert=True)

    async def handle_confirm_delete(self, callback: CallbackQuery):
        await callback.answer()

        parts = callback.data.split(":")
        order_id = int(parts[1])
        status_key = parts[2]
        page = parts[3]

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ بله، حذف شود", callback_data=f"delete_order:{order_id}:{status_key}:{page}"),
                InlineKeyboardButton(text="❌ خیر، بازگشت", callback_data=f"view_order:{order_id}:{status_key}:{page}")
            ]
        ])

        await callback.message.edit_text(
            f"⚠️ آیا مطمئن هستید که می‌خواهید سفارش شماره {order_id} را حذف کنید؟",
            reply_markup=kb
        )

    async def handle_delete_order(self, callback: CallbackQuery):
        parts = callback.data.split(":")
        order_id = int(parts[1])
        status_key = parts[2]
        page = parts[3]

        success = self.data_manager.delete_order(order_id)

        await callback.answer(
            "✅ سفارش با موفقیت حذف شد" if success else "❌ سفارش پیدا نشد یا حذف نشد",
            show_alert=True
        )

        await callback.message.edit_text(
            "⛔️ عملیات حذف انجام شد." if success else "⚠️ عملیات حذف ناموفق بود.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🔙 بازگشت به لیست", callback_data=f"filter_orders:{status_key}:{page}")]
            ])
        )

    async def handle_min_order_input(self, message: Message, state: FSMContext):
        try:
            amount = int(message.text.strip())
            self.data_manager.set_min_order_amount(amount)  # ذخیره در منبع داده
            await message.answer(f"✅ حداقل مبلغ سفارش تنظیم شد: {amount:,} تومان")
            await state.clear()
            markup = self.get_order_menu()
            await message.answer("💡 دستورات مدیریت سفارشات:", reply_markup=markup)
        except ValueError:
            await message.answer("❌ لطفاً فقط عدد وارد کنید.")

    # هندلر ها

    async def handle_back_to_order_filters(self, callback: CallbackQuery):
        await callback.answer()
        kb = self.get_order_filter_keyboard()
        await callback.message.edit_text("📊 لطفاً وضعیت سفارش‌ها را انتخاب کنید:", reply_markup=kb)

    async def show_location_limit_menu(self, callback: CallbackQuery):
        raw = self.data_manager.load_data("locate")
        data = raw[0] if isinstance(raw, list) and raw else raw  # پشتیبانی از لیست و دیکشنری

        delivery = data.get("delivery_area", {})
        active = delivery.get("active", False)
        type_ = delivery.get("type", "radius")

        status = "✅ فعال" if active else "❌ غیرفعال"
        type_meaning = {
            "radius": "بر اساس شعاع (کیلومتر)",
            "city": "بر اساس شهر",
        }.get(type_, "❓ نوع محدودیت نامشخص است")

        detail = ""
        if type_ == "radius":
            radius = delivery.get("radius", 0)
            detail = f"📏 شعاع مجاز: {radius} کیلومتر"
        elif type_ == "city":
            cities = delivery.get("cities", [])
            if cities:
                city_list = "\n".join([f"• {c}" for c in cities])
                detail = f"🏙 شهرهای مجاز:\n{city_list}"

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ فعال‌سازی", callback_data="location_limit_on"),
                InlineKeyboardButton(text="❌ غیرفعال‌سازی", callback_data="location_limit_off")
            ],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_order_menu")]
        ])

        await callback.message.edit_text(
            f"📍 تنظیم محدودیت موقعیت مکانی:\n\n"
            f"وضعیت فعلی: {status}\n"
            f"نوع محدودیت: {type_meaning}\n"
            f"{detail}",
            reply_markup=kb
        )

    async def disable_location_limit(self, callback: CallbackQuery):
        self.data_manager.update_delivery_area({
            "active": False,
            "type": None,
            "store_location": None,
            "radius": None
        })
        await callback.answer("❌ محدودیت موقعیت غیرفعال شد", show_alert=True)
        raw = self.data_manager.load_data("locate")
        data = raw[0] if isinstance(raw, list) and raw else raw  # پشتیبانی از لیست و دیکشنری

        delivery = data.get("delivery_area", {})
        active = delivery.get("active", False)
        type_ = delivery.get("type", "radius")

        status = "✅ فعال" if active else "❌ غیرفعال"
        type_meaning = {
            "radius": "بر اساس شعاع (کیلومتر)",
            "city": "بر اساس شهر",
        }.get(type_, "❓ نوع محدودیت نامشخص است")

        detail = ""
        if type_ == "radius":
            radius = delivery.get("radius", 0)
            detail = f"📏 شعاع مجاز: {radius} کیلومتر"
        elif type_ == "city":
            cities = delivery.get("cities", [])
            if cities:
                city_list = "\n".join([f"• {c}" for c in cities])
                detail = f"🏙 شهرهای مجاز:\n{city_list}"

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ فعال‌سازی", callback_data="location_limit_on"),
                InlineKeyboardButton(text="❌ غیرفعال‌سازی", callback_data="location_limit_off")
            ],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_order_menu")]
        ])

        await callback.message.edit_text(
            f"📍 تنظیم محدودیت موقعیت مکانی:\n\n"
            f"وضعیت فعلی: {status}\n"
            f"نوع محدودیت: {type_meaning}\n"
            f"{detail}",
            reply_markup=kb
        )

    async def show_location_limit_types(self, callback: CallbackQuery):
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏪 موقعیت فروشگاه", callback_data="location_type_store")],
            [InlineKeyboardButton(text="🌆 بر اساس شهر", callback_data="location_type_city")],
            [InlineKeyboardButton(text="📏 بر اساس شعاع", callback_data="location_type_radius")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_limit_menu")]
        ])
        await callback.message.edit_text("لطفاً نوع محدودیت را انتخاب کنید:", reply_markup=kb)

    async def ask_store_location(self, callback: CallbackQuery, state: FSMContext):
        await callback.message.edit_text(
            "لطفاً موقعیت مکانی فروشگاه را ارسال کنید.\n"
            "(مسیر در تلگرام: 📎 سنجاق ← 📍 موقعیت مکانی ← 🗺️ انتخاب روی نقشه ← 📤 ارسال)\n"
            "(Telegram path: 📎 Attachment → 📍 Location → 🗺️ Choose on map → 📤 Send)"
        )
        await state.set_state(OrderStates.waiting_for_store_location)


    async def save_store_location(self, message: Message, state: FSMContext):
        lat = message.location.latitude
        lon = message.location.longitude

        self.data_manager.update_delivery_area({
            "active": True,
            "store_location": {"lat": lat, "lon": lon}
        })
        await state.clear()
        await message.answer("✅ موقعیت فروشگاه ذخیره شد.", show_alert=True)
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏪 موقعیت فروشگاه", callback_data="location_type_store")],
            [InlineKeyboardButton(text="🌆 بر اساس شهر", callback_data="location_type_city")],
            [InlineKeyboardButton(text="📏 بر اساس شعاع", callback_data="location_type_radius")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_limit_menu")]
        ])
        await message.answer("لطفاً نوع محدودیت را انتخاب کنید:", reply_markup=kb)

    async def ask_radius(self, callback: CallbackQuery, state: FSMContext):
        locate_data = self.data_manager.load_data("locate")
        delivery_area = locate_data.get("delivery_area") if isinstance(locate_data, dict) else None
        store_location = delivery_area.get("store_location") if delivery_area else None

        if not isinstance(store_location, dict) or "lat" not in store_location or "lon" not in store_location:
            await callback.answer("⚠️ قبل از انتخاب شعاع، باید موقعیت فروشگاه را ثبت کنید.", show_alert=True)
            return

        await callback.message.edit_text("📏 لطفاً شعاع مجاز ارسال را وارد کنید (بر حسب کیلومتر):")
        await state.set_state(OrderStates.waiting_for_radius)


    async def save_radius(self, message: Message, state: FSMContext):
        try:
            radius = float(message.text.strip())
            if radius <= 0:
                raise ValueError
        except ValueError:
            await message.answer("❌ لطفاً فقط عدد معتبر وارد کنید (مثلاً 2 یا 1.5 کیلومتر)")
            return

        self.data_manager.update_delivery_area({
            "active": True,
            "type": "radius",
            "radius": radius
        })

        await state.clear()  # پاک‌سازی وضعیت
        await message.answer(f"✅ شعاع {radius} کیلومتر ثبت شد.")
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏪 موقعیت فروشگاه", callback_data="location_type_store")],
            [InlineKeyboardButton(text="🌆 بر اساس شهر", callback_data="location_type_city")],
            [InlineKeyboardButton(text="📏 بر اساس شعاع", callback_data="location_type_radius")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_limit_menu")]
        ])
        await message.answer("لطفاً نوع محدودیت را انتخاب کنید:", reply_markup=kb)

    async def ask_city_name(self, callback: CallbackQuery, state: FSMContext):
        await callback.message.edit_text("➕ لطفاً نام شهر فارسی را وارد کنید:")
        await state.set_state(OrderStates.waiting_for_city_name)
    async def show_city_menu(self, callback: CallbackQuery, state: FSMContext):
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="➕ افزودن شهر", callback_data="city_add")],
            [InlineKeyboardButton(text="✏️ ویرایش شهر", callback_data="city_edit")],
            [InlineKeyboardButton(text="🗑️ حذف شهر", callback_data="city_delete")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_limit_on")]
        ])
        await callback.message.edit_text("🌆 مدیریت شهرها:", reply_markup=kb)
        await state.set_state(OrderStates.waiting_for_city_action)

    async def save_city_name(self, message: Message, state: FSMContext):
        city = message.text.strip()
        if not city or not all('\u0600' <= c <= '\u06FF' or c.isspace() for c in city):
            await message.answer("❌ فقط نام شهر فارسی مجاز است.")
            return

        cities = self.data_manager.get_delivery_area().get("cities", [])
        if city in cities:
            await message.answer("⚠️ این شهر قبلاً ثبت شده است.")
        else:
            cities.append(city)
            self.data_manager.update_delivery_area({
                "active": True,
                "type": "city",
                "cities": cities
            })
            await message.answer(f"✅ شهر «{city}» اضافه شد.")

        await state.clear()

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="➕ افزودن شهر", callback_data="city_add")],
            [InlineKeyboardButton(text="✏️ ویرایش شهر", callback_data="city_edit")],
            [InlineKeyboardButton(text="🗑️ حذف شهر", callback_data="city_delete")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_limit_on")]
        ])
        await message.answer("🌆 مدیریت شهرها:", reply_markup=kb)
        await state.set_state(OrderStates.waiting_for_city_action)


    def get_city_buttons(self, cities: list, page: int, action: str) -> InlineKeyboardMarkup:
        per_page = 7
        start = page * per_page
        end = start + per_page
        page_cities = cities[start:end]

        buttons = [[InlineKeyboardButton(text=city, callback_data=f"{action}:{city}")] for city in page_cities]

        nav_buttons = []
        if start > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"{action}_page:{page-1}"))
        if end < len(cities):
            nav_buttons.append(InlineKeyboardButton(text="➡️ بعدی", callback_data=f"{action}_page:{page+1}"))

        buttons.append(nav_buttons)
        buttons.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_type_city")])

        return InlineKeyboardMarkup(inline_keyboard=buttons)

    async def show_city_edit_list(self, callback: CallbackQuery, page: int = 0):
        cities = self.data_manager.get_delivery_area().get("cities", [])
        if not cities:
            await callback.answer("⚠️ هیچ شهری ثبت نشده", show_alert=True)
            return

        kb = self.get_city_buttons(cities, page, action="edit_city")
        await callback.message.edit_text("✏️ انتخاب شهر برای ویرایش:", reply_markup=kb)

    async def show_city_delete_list(self, callback: CallbackQuery, page: int = 0):
        cities = self.data_manager.get_delivery_area().get("cities", [])
        if not cities:
            await callback.answer("⚠️ هیچ شهری ثبت نشده", show_alert=True)
            return

        kb = self.get_city_buttons(cities, page, action="delete_city")
        await callback.message.edit_text("🗑️ انتخاب شهر برای حذف:", reply_markup=kb)

    async def edit_city_selected(self, callback: CallbackQuery, city: str, state: FSMContext):
        await state.update_data(city_to_edit=city)
        await callback.message.edit_text(f"✏️ شهر انتخاب‌شده: «{city}»\nلطفاً نام جدید را وارد کنید:")
        await state.set_state(OrderStates.waiting_for_city_edit)

    async def handle_edit_city_callback(self, callback: CallbackQuery, state: FSMContext):
        city = callback.data.split("edit_city:")[1]
        await self.edit_city_selected(callback, city, state)

    async def save_city_edit(self, message: Message, state: FSMContext):
        new_name = message.text.strip()
        if not new_name or not all('\u0600' <= c <= '\u06FF' or c.isspace() for c in new_name):
            await message.answer("❌ فقط نام فارسی مجاز است.")
            return

        data = await state.get_data()
        old_name = data.get("city_to_edit")

        cities = self.data_manager.get_delivery_area().get("cities", [])
        if old_name not in cities:
            await message.answer("⚠️ شهر قبلی یافت نشد.")
            return

        cities[cities.index(old_name)] = new_name
        self.data_manager.update_delivery_area({"cities": cities})

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_type_city")]
        ])
        await message.answer(f"✅ شهر «{old_name}» با «{new_name}» جایگزین شد.", reply_markup=kb)
        await state.clear()

    async def delete_city_selected(self, callback: CallbackQuery, city: str, state: FSMContext):
        await state.update_data(city_to_delete=city)
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله، حذف شود", callback_data="confirm_delete_city")],
            [InlineKeyboardButton(text="❌ خیر، بازگشت", callback_data="location_type_city")]
        ])
        await callback.message.edit_text(f"🗑️ آیا مطمئن هستید که شهر «{city}» حذف شود؟", reply_markup=kb)

    async def handle_delete_city_callback(self, callback: CallbackQuery, state: FSMContext):
        city = callback.data.split("delete_city:")[1]
        await self.delete_city_selected(callback, city, state)

    async def confirm_city_deletion(self, callback: CallbackQuery, state: FSMContext):
        data = await state.get_data()
        city = data.get("city_to_delete")

        delivery_area = self.data_manager.get_delivery_area()
        cities = delivery_area.get("cities", [])
        if city in cities:
            cities.remove(city)
            delivery_area["cities"] = cities
            delivery_area["type"] = "city"
            delivery_area["active"] = True
            delivery_area.pop("radius", None)
            self.data_manager.update_delivery_area(delivery_area)
            await callback.answer("✅ شهر حذف شد.", show_alert=True)
        else:
            await callback.answer("⚠️ شهر یافت نشد.", show_alert=True)

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="location_type_city")]
        ])
        await callback.message.edit_text(f"✅ شهر «{city}» حذف شد.", reply_markup=kb)
        await state.clear()

    def register_order_handlers(self, dp: Dispatcher):

        dp.callback_query.register(self.handle_set_min_order, F.data == "set_min_order")
        dp.message.register(self.handle_min_order_input, OrderStates.setting_min_order)
        dp.callback_query.register(self.show_orders, F.data == "show_orders")
        dp.callback_query.register(self.back_to_order_menu, F.data == "back_to_order_menu")
        dp.callback_query.register(self.handle_order_filter, F.data.startswith("filter_orders:"))
        dp.callback_query.register(self.send_main_menu, F.data == "back_to_order_menu")
        dp.callback_query.register(self.handle_back_to_order_filters, F.data == "back_to_order_filters")
        dp.callback_query.register(self.handle_order_page, F.data.startswith("order_page:"))
        dp.callback_query.register(self.handle_view_order, F.data.startswith("view_order:"))
        dp.callback_query.register(self.handle_change_status, F.data.startswith("change_status:"))
        dp.callback_query.register(self.handle_set_status, F.data.startswith("set_status:"))
        dp.callback_query.register(self.handle_confirm_delete, F.data.startswith("confirm_delete:"))
        dp.callback_query.register(self.handle_delete_order, F.data.startswith("delete_order:"))
        dp.callback_query.register(self.show_location_limit_menu, F.data == "location_limit_menu")
        dp.callback_query.register(self.disable_location_limit, F.data == "location_limit_off")
        dp.callback_query.register(self.show_location_limit_types, F.data == "location_limit_on")
        dp.callback_query.register(self.ask_store_location, F.data == "location_type_store")
        dp.message.register(self.save_store_location, OrderStates.waiting_for_store_location)
        dp.callback_query.register(self.ask_radius, F.data == "location_type_radius")
        dp.message.register(self.save_radius, OrderStates.waiting_for_radius)
        dp.callback_query.register(self.show_city_menu, F.data == "location_type_city")
        dp.callback_query.register(self.ask_city_name, F.data == "city_add")
        dp.message.register(self.save_city_name, OrderStates.waiting_for_city_name)
        dp.callback_query.register(self.show_city_edit_list, F.data == "city_edit")
        dp.callback_query.register(self.show_city_delete_list, F.data == "city_delete")
        dp.callback_query.register(self.handle_edit_city_callback, F.data.startswith("edit_city:"))
        dp.callback_query.register(self.handle_delete_city_callback, F.data.startswith("delete_city:"))
        dp.callback_query.register(self.confirm_city_deletion, F.data == "confirm_delete_city")
        dp.message.register(self.save_city_edit, OrderStates.waiting_for_city_edit)
        dp.callback_query.register(self.handle_manage_points, F.data == "manage_points")
        dp.callback_query.register(self.handle_enable_points, F.data == "enable_points")
        dp.callback_query.register(self.handle_disable_points, F.data == "disable_points")
        dp.callback_query.register(self.handle_edit_earning_rate, F.data == "edit_earning_rate")
        dp.message.register(self.handle_setting_input)
        dp.callback_query.register(self.handle_edit_max_per_order, F.data == "edit_max_per_order")
        dp.message.register(self.handle_setting_input)
