# menus/admin/settings.py
from aiogram import Dispatcher,F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from utils.data_manager import DataManager
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext

class CardStates(StatesGroup):
    waiting_for_number = State()
    waiting_for_owner = State()

class SettingsManager:
    def __init__(self, data_manager: DataManager):
        self.data_manager = data_manager

    async def show_settings(self, message: Message):

        text = """
⚙️ تنظیمات سیستم

🔧 امکانات موجود:
🔹 مدیریت محصولات
🔹 مدیریت دسته‌بندی‌ها
🔹 مدیریت سفارشات
🔹 مدیریت کاربران
🔹 ارسال پیام همگانی
🔹 💳 مدیریت پرداخت
        """

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="💳 مدیریت پرداخت", callback_data="manage_payment")]
            ]
        )

        await message.answer(text, reply_markup=keyboard)

    async def show_payment_menu(self, message: Message):
        text = "💳 مدیریت پرداخت\n\nیکی از گزینه‌های زیر رو انتخاب کن:"

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="✏️ ویرایش شماره کارت", callback_data="edit_card_manager")],
                [InlineKeyboardButton(text="📄 مشاهده تراکنش‌ها", callback_data="view_transactions")]
            ]
        )

        await message.answer(text, reply_markup=keyboard)

    async def handle_manage_payment(self, query: CallbackQuery):
        await self.show_payment_menu(query.message)
        await query.answer()
    async def handle_card_manager(self, query: CallbackQuery):
        await query.message.answer(
            "💳 مدیریت کارت‌ها\n\nیکی از گزینه‌های زیر رو انتخاب کن:",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="➕ افزودن کارت", callback_data="add_card")],
                    [InlineKeyboardButton(text="✏️ ویرایش کارت", callback_data="edit_card")],
                    [InlineKeyboardButton(text="🗑 حذف کارت", callback_data="delete_card")]
                ]
            )
        )
        await query.answer()

    async def handle_add_card_button(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.answer("🔢 لطفاً شماره کارت را وارد کنید:")
        await state.set_state(CardStates.waiting_for_number)

    async def handle_card_number(self, message: Message, state: FSMContext):
        number = message.text.strip()

        if not number.isdigit() or len(number) != 16:
            await message.answer("❌ شماره کارت نامعتبر است. لطفاً یک شماره ۱۶ رقمی وارد کنید.")
            return

        await state.update_data(card_number=number)
        await message.answer("👤 لطفاً نام صاحب کارت را وارد کنید:")
        await state.set_state(CardStates.waiting_for_owner)

    async def handle_card_owner(self, message: Message, state: FSMContext):
        owner = message.text.strip()
        data = await state.get_data()
        number = data.get("card_number")

        if not number:
            await message.answer("❌ شماره کارت یافت نشد. لطفاً دوباره تلاش کنید.")
            await state.clear()
            return

        success = self.data_manager.add_payment_card(number, owner)
        await state.clear()

        if success:
            await message.answer(f"✅ کارت با شماره {number} و صاحب {owner} با موفقیت ذخیره شد.")
        else:
            await message.answer("❌ خطا در ذخیره‌سازی کارت.")

    async def handle_edit_card(self, query: CallbackQuery):
        cards = self.data_manager.get("cards") or []

        if not cards:
            await query.message.answer("❌ هیچ شماره کارتی برای ویرایش وجود ندارد.")
            await query.answer()
            return

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=card, callback_data=f"edit_card_{i}")]
                for i, card in enumerate(cards)
            ]
        )

        await query.message.answer("✏️ کدام کارت را می‌خواهی ویرایش کنی؟", reply_markup=keyboard)
        await query.answer()

    async def handle_delete_card(self, query: CallbackQuery):
        cards = self.data_manager.get("cards") or []

        if not cards:
            await query.message.answer("❌ هیچ شماره کارتی برای حذف وجود ندارد.")
            await query.answer()
            return

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=card, callback_data=f"delete_card_{i}")]
                for i, card in enumerate(cards)
            ]
        )

        await query.message.answer("🗑 کدام کارت را می‌خواهی حذف کنی؟", reply_markup=keyboard)
        await query.answer()

    def register_settings_handler(self, dp: Dispatcher):
        dp.callback_query.register(self.handle_manage_payment, F.data == "manage_payment")
        dp.callback_query.register(self.handle_card_manager, F.data == "edit_card_manager")
        dp.callback_query.register(self.handle_add_card_button, F.data == "add_card")
        dp.message.register(self.handle_card_number, CardStates.waiting_for_number)
        dp.message.register(self.handle_card_owner, CardStates.waiting_for_owner)
        dp.callback_query.register(self.handle_edit_card, F.data == "edit_card")
        dp.callback_query.register(self.handle_delete_card, F.data == "delete_card")
