from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from utils.data_manager import DataManager
from utils.keyboards import Keyboards
from config import *
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters.state import StateFilter

# تعریف وضعیت‌ها
class ProductStates(StatesGroup):
    waiting_for_category = State()
    waiting_for_name = State()
    waiting_for_price = State()
    waiting_for_description = State()
    editing_name = State()
    editing_price = State()
    editing_description = State()
    deleting_category = State()
    deleting_product = State()
    editing_category_select = State()
    editing_category_name = State()
    adding_product_category = State()
    deleting_category_select = State()
    confirming_category_deletion = State()


class CategoryStates(StatesGroup):
    waiting_for_name = State()


class ProductManager:
    def __init__(self, bot: Bot, data_manager: DataManager):
        self.bot = bot
        self.data_manager = data_manager

    # منوی شیشه‌ای عملیات محصولات
    def _product_commands_keyboard(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="➕ افزودن محصول", callback_data="add_product")],
            [InlineKeyboardButton(text="✏️ ویرایش محصول", callback_data="edit_product")],
            [InlineKeyboardButton(text="🗑 حذف محصول", callback_data="delete_product")],
            [InlineKeyboardButton(text="📝 ویرایش دسته‌بندی", callback_data="edit_category")],
            [InlineKeyboardButton(text="❌ حذف دسته‌بندی", callback_data="delete_category")],
            [InlineKeyboardButton(text="⚙️ تنظیمات نمایش", callback_data="view_settings")],
        ])

    # نمایش لیست محصولات
    async def show_products(self, message: Message):
        products = self.data_manager.get_products()
        categories = self.data_manager.get_categories()

        if not products:
            await message.answer(
                "📦 هیچ محصولی موجود نیست.\n\n"
                "💡 برای افزودن محصول جدید از منوی زیر استفاده کنید:",
                reply_markup=self._product_commands_keyboard()
            )
            return

        await message.answer("💡 دستورات مدیریت محصولات:", reply_markup=self._product_commands_keyboard())

    # شروع فرآیند افزودن محصول
    async def cmd_add_product(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        categories = self.data_manager.get_categories()

        # ساخت دکمه‌های دسته‌بندی
        category_buttons = [
            [InlineKeyboardButton(text=cat["name"], callback_data=f"select_cat_{cat['id']}")]
            for cat in categories
        ]

        # افزودن دکمه "افزودن دسته‌بندی" در انتها
        category_buttons.append(
            [InlineKeyboardButton(text="➕ افزودن دسته‌بندی", callback_data="add_category")]
        )

        category_buttons.append(
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
        )

        kb = InlineKeyboardMarkup(inline_keyboard=category_buttons)

        await callback.message.edit_text("📂 لطفاً دسته‌بندی محصول را انتخاب کنید:", reply_markup=kb)
        await state.set_state(ProductStates.adding_product_category)


    # هندلر کلیک روی دکمه "➕ افزودن دسته‌بندی"
    async def handle_add_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.answer("📝 لطفاً نام دسته‌بندی جدید را وارد کنید:")
        await state.set_state(CategoryStates.waiting_for_name)

    async def handle_category_name(self, message: Message, state: FSMContext):
        name = message.text.strip()
        self.data_manager.add_category(name)
        await message.answer(f"✅ دسته‌بندی «{name}» با موفقیت افزوده شد.")

        # دریافت دسته‌های جدید
        categories = self.data_manager.get_categories()

        # ساخت دکمه‌های دسته‌بندی
        category_buttons = [
            [InlineKeyboardButton(text=cat["name"], callback_data=f"select_cat_{cat['id']}")]
            for cat in categories
        ]
        category_buttons.append(
            [InlineKeyboardButton(text="➕ افزودن دسته‌بندی", callback_data="add_category")]
        )

        kb = InlineKeyboardMarkup(inline_keyboard=category_buttons)

        await message.answer("📂 لطفاً دسته‌بندی محصول را انتخاب کنید:", reply_markup=kb)
        await state.set_state(ProductStates.adding_product_category)


    async def handle_category_selection(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        cat_id = int(callback.data.split("_")[-1])
        await state.update_data(category_id=cat_id)
        await callback.message.edit_text("📝 نام محصول را وارد کنید:")
        await state.set_state(ProductStates.waiting_for_name)

    async def process_name(self, message: Message, state: FSMContext):
        await state.update_data(name=message.text)
        await message.answer("💰 قیمت محصول را وارد کنید:")
        await state.set_state(ProductStates.waiting_for_price)

    async def process_price(self, message: Message, state: FSMContext):
        try:
            price = int(message.text.replace(",", ""))
        except ValueError:
            return await message.answer("⚠️ لطفاً قیمت را به صورت عددی وارد کنید.")
        await state.update_data(price=price)
        await message.answer("📝 توضیحات محصول را وارد کنید:")
        await state.set_state(ProductStates.waiting_for_description)

    async def process_description(self, message: Message, state: FSMContext):
        await state.update_data(description=message.text)
        data = await state.get_data()

        self.data_manager.add_product({
            "name": data["name"],
            "price": data["price"],
            "description": data["description"],
            "category_id": data["category_id"],
            "active": True
        })

        await message.answer("✅ محصول با موفقیت اضافه شد.")
        await state.clear()
        await message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )
    async def cmd_edit_product(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        categories = self.data_manager.get_categories()

        if not categories:
            await callback.message.answer("⚠️ هیچ دسته‌بندی‌ای وجود ندارد.")
            return

        kb = InlineKeyboardMarkup(inline_keyboard=[
            *[
                [InlineKeyboardButton(text=cat["name"], callback_data=f"edit_cat_{cat['id']}")]
                for cat in categories
            ],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
        ])

        await callback.message.edit_text("📂 دسته‌بندی مورد نظر را انتخاب کنید:", reply_markup=kb)

    async def handle_edit_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()

        # بررسی اینکه callback_data معتبره
        parts = callback.data.split("_")
        if len(parts) < 3 or not parts[-1].isdigit():
            await callback.message.answer("❌ شناسه دسته‌بندی نامعتبر است.")
            return

        cat_id = int(parts[-1])
        products = self.data_manager.get_products_by_category(cat_id)

        if not products:
            await callback.message.answer("⚠️ هیچ محصولی در این دسته‌بندی وجود ندارد.")
            return

        kb = InlineKeyboardMarkup(inline_keyboard=[
            *[
                [InlineKeyboardButton(text=p["name"], callback_data=f"edit_prod_{p['id']}")]
                for p in products
            ],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="edit_product")]
        ])

        await callback.message.edit_text("📦 محصول مورد نظر را انتخاب کنید:", reply_markup=kb)

    async def handle_edit_product_selection(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        prod_id = int(callback.data.split("_")[-1])
        await state.update_data(product_id=prod_id)

        product = self.data_manager.get_product_by_id(prod_id)
        if not product:
            await callback.message.answer("❌ محصول پیدا نشد.")
            return

        cat_id = product.get("category_id")
        if not cat_id:
            await callback.message.answer("❌ دسته‌بندی محصول نامشخص است.")
            return

        # ساخت متن با جزئیات محصول
        name = product.get("name", "نام‌نامشخص")
        price = product.get("price", "قیمت‌نامشخص")
        description = product.get("description", "بدون توضیحات")

        text = (
            f"📦 محصول انتخاب‌شده:\n"
            f"📝 نام: {name}\n"
            f"💰 قیمت: {price}\n"
            f"🗒 توضیحات: {description}\n\n"
            f"✏️ لطفاً نوع ویرایش را انتخاب کنید:"
        )

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📝 ویرایش نام", callback_data="edit_name")],
            [InlineKeyboardButton(text="💰 ویرایش قیمت", callback_data="edit_price")],
            [InlineKeyboardButton(text="📝 ویرایش توضیحات", callback_data="edit_description")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"edit_cat_{cat_id}")]
        ])

        await callback.message.edit_text(text, reply_markup=kb)


    async def handle_edit_name(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.edit_text("📝 نام جدید محصول را وارد کنید:")
        await state.set_state(ProductStates.editing_name)

    async def process_new_name(self, message: Message, state: FSMContext):
        await state.update_data(new_name=message.text)

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله", callback_data="confirm_edit")],
            [InlineKeyboardButton(text="❌ نه", callback_data="cancel_edit")]
        ])
        await message.answer(f"آیا مطمئن هستید که نام محصول به «{message.text}» تغییر کند؟", reply_markup=kb)

    async def handle_confirm_edit(self, callback: CallbackQuery, state: FSMContext):
        data = await state.get_data()
        self.data_manager.update_product_name(data["product_id"], data["new_name"])
        await callback.message.edit_text("✅ نام محصول با موفقیت تغییر یافت.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )

    async def handle_cancel_edit(self, callback: CallbackQuery, state: FSMContext):
        await callback.message.edit_text("❌ عملیات ویرایش متوقف شد.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )

    # ۱. شروع ویرایش قیمت
    async def handle_edit_price(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.edit_text("💰 قیمت جدید محصول را وارد کنید:")
        await state.set_state(ProductStates.editing_price)

    # ۲. دریافت قیمت جدید و نمایش تأیید
    async def process_new_price(self, message: Message, state: FSMContext):
        text = message.text.replace(",", "").strip()
        try:
            price = int(text)
        except ValueError:
            return await message.answer("⚠️ لطفاً عددی وارد کنید.")
        
        await state.update_data(new_price=price)
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله", callback_data="confirm_edit_price")],
            [InlineKeyboardButton(text="❌ نه", callback_data="cancel_edit")]
        ])
        await message.answer(f"آیا مطمئن هستید قیمت به «{price:,} تومان» تغییر کند؟", reply_markup=kb)

    # ۳. تأیید و ذخیره قیمت
    async def handle_confirm_edit_price(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        data = await state.get_data()
        self.data_manager.update_product_price(data["product_id"], data["new_price"])
        await callback.message.edit_text("✅ قیمت محصول با موفقیت تغییر یافت.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )

    # ۴. شروع ویرایش توضیحات
    async def handle_edit_description(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.edit_text("📝 توضیحات جدید محصول را وارد کنید:")
        await state.set_state(ProductStates.editing_description)

    # ۵. دریافت توضیحات جدید و نمایش تأیید
    async def process_new_description(self, message: Message, state: FSMContext):
        desc = message.text.strip()
        await state.update_data(new_description=desc)
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله", callback_data="confirm_edit_description")],
            [InlineKeyboardButton(text="❌ نه", callback_data="cancel_edit")]
        ])
        await message.answer("آیا مطمئن هستید توضیحات محصول تغییر کند؟", reply_markup=kb)

    # ۶. تأیید و ذخیره توضیحات
    async def handle_confirm_edit_description(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        data = await state.get_data()
        self.data_manager.update_product_description(data["product_id"], data["new_description"])
        await callback.message.edit_text("✅ توضیحات محصول با موفقیت تغییر یافت.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )


    # 1. شروع حذف: نمایش دسته‌بندی‌ها
    async def cmd_delete_product(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        categories = self.data_manager.get_categories()  # لیست دیکشنری‌ها

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                *[
                    [InlineKeyboardButton(
                        text=cat["name"],
                        callback_data=f"delete_cat_{cat['id']}"
                    )]
                    for cat in categories
                ],
                [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
            ]
        )

        await callback.message.edit_text(
            "🏷 دسته مورد نظر را برای حذف محصول انتخاب کنید:",
            reply_markup=kb
        )
        await state.set_state(ProductStates.deleting_category)

    # 2. دریافت دسته و نمایش محصولات آن
    async def handle_delete_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        cat_id = int(callback.data.split("_")[-1])
        await state.update_data(delete_cat_id=cat_id)

        products = self.data_manager.get_products_by_category(cat_id)

        # تعریف یکجا‌ی اکشن‌ها
        rows = [
            [InlineKeyboardButton(text=prod["name"], callback_data=f"delete_prod_{prod['id']}")]
            for prod in products
        ]
        # اضافه کردن دکمه انصراف به انتهای لیست
        rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data="delete_product")])

        kb = InlineKeyboardMarkup(inline_keyboard=rows)

        await callback.message.edit_text(
            "🗂 محصول مورد نظر را انتخاب کنید:",
            reply_markup=kb
        )
        await state.set_state(ProductStates.deleting_product)


    # 3. دریافت محصول و نمایش تأیید حذف
    async def handle_delete_product_selection(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        prod_id = int(callback.data.split("_")[-1])
        await state.update_data(delete_prod_id=prod_id)

        data = await state.get_data()
        cat_id = data.get("delete_cat_id")

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله", callback_data="confirm_delete")],
            [InlineKeyboardButton(text="❌ نه",  callback_data="cancel_delete")],
            [InlineKeyboardButton(text="🔙 بازگشت",  callback_data=f"delete_cat_{cat_id}")]
        ])
        await callback.message.edit_text(
            "⚠️ آیا مطمئن هستید که می‌خواهید این محصول را حذف کنید؟",
            reply_markup=kb
        )

    # 4. تأیید حذف و انجام عملیات
    async def handle_confirm_delete(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        data = await state.get_data()
        self.data_manager.delete_product(data["delete_prod_id"])
        await callback.message.edit_text("✅ محصول با موفقیت حذف شد.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )


    # 5. لغو حذف (مشترک)
    async def handle_cancel_delete(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.edit_text("❌ عملیات حذف لغو شد.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )


        # ۲.۱ نمایش لیست دسته‌ها
    async def cmd_edit_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        categories = self.data_manager.get_categories()

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=cat["name"], callback_data=f"select_cat_{cat['id']}")]
                for cat in categories
            ]
        )

        # اضافه کردن دکمه انصراف
        kb.inline_keyboard.append(
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
        )

        await callback.message.edit_text(
            "📂 یک دسته‌بندی را برای ویرایش نام انتخاب کنید:",
            reply_markup=kb
        )
        await state.set_state(ProductStates.editing_category_select)


    # ۲.۲ کاربر دسته را انتخاب کرد → درخواست نام جدید
    async def handle_category_selected(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        cat_id = int(callback.data.split("_")[-1])
        await state.update_data(category_id=cat_id)

        await callback.message.edit_text("✏️ نام جدید دسته‌بندی را وارد کنید:")
        await state.set_state(ProductStates.editing_category_name)


    # ۲.۳ دریافت نام جدید و ذخیره در JSON
    async def process_new_category_name(self, message: Message, state: FSMContext):
        new_name = message.text.strip()
        data = await state.get_data()
        ok = self.data_manager.update_category_name(data["category_id"], new_name)

        if ok:
            await message.answer(f"✅ نام دسته‌بندی با موفقیت به «{new_name}» تغییر کرد.")
        else:
            await message.answer("⚠️ خطا در ویرایش نام دسته‌بندی. لطفاً دوباره تلاش کنید.")

        await state.clear()
        await message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )


    # ۲.۴ انصراف از ویرایش
    async def handle_cancel_category_edit(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.answer("❌ عملیات ویرایش دسته‌بندی لغو شد.")
        await state.clear()



    async def cmd_delete_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        categories = self.data_manager.get_categories()

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=cat["name"], callback_data = f"delete_category_{cat['id']}")]
                for cat in categories
            ]
        )
        kb.inline_keyboard.append(
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
        )

        await callback.message.edit_text("📂 دسته‌ای را برای حذف انتخاب کنید:", reply_markup=kb)
        await state.set_state(ProductStates.deleting_category_select)

    async def handle_delete_category_selected(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        cat_id = int(callback.data.split("_")[-1])
        await state.update_data(category_id=cat_id)

        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ بله، حذف شود", callback_data="confirm_delete_category")],
            [InlineKeyboardButton(text="❌ خیر، لغو شود", callback_data="cancel_delete_category")],
            [InlineKeyboardButton(text="🔙 بازگشت",  callback_data=f"delete_category")]
        ])

        await callback.message.edit_text("⚠️ آیا مطمئن هستید که این دسته‌بندی و تمام محصولات آن حذف شوند؟", reply_markup=kb)
        await state.set_state(ProductStates.confirming_category_deletion)

    async def handle_confirm_delete_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        data = await state.get_data()
        cat_id = data.get("category_id")

        # حذف دسته
        self.data_manager.delete_category(cat_id)

        # حذف محصولات مرتبط با دسته
        products = self.data_manager.get_products()
        filtered = [p for p in products if p.get("category_id") != cat_id]
        self.data_manager.save_data("products", filtered)

        await callback.message.edit_text("✅ دسته‌بندی و محصولات مرتبط با موفقیت حذف شدند.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )


    async def handle_cancel_delete_category(self, callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await callback.message.edit_text("❌ عملیات حذف دسته‌بندی لغو شد.")
        await state.clear()
        await callback.message.answer(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )

    
    async def cmd_view_settings(self, callback_query: CallbackQuery):
        if callback_query.data != "view_settings":
            return

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📂 مدیریت دسته‌بندی‌ها", callback_data="manage_categories")],
            [InlineKeyboardButton(text="🛍️ مدیریت محصولات", callback_data="manage_products")],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="back_to_admin_menu")]
        ])

        await callback_query.message.edit_text("⚙️ تنظیمات نمایش:", reply_markup=keyboard)

    async def handle_manage_categories(self, callback_query: CallbackQuery):
        if callback_query.data != "manage_categories":
            return

        categories = self.data_manager.get_categories()
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text=f"{'✅' if cat['active'] else '❌'} {cat['name']}",
                    callback_data=f"category_status:{cat['id']}"
                )] for cat in categories
            ] + [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="view_settings")]]
        )

        await callback_query.message.edit_text("📂 دسته‌بندی‌ها:", reply_markup=keyboard)

    async def handle_category_status(self, callback_query: CallbackQuery):
        if not callback_query.data.startswith("category_status:"):
            return

        cat_id = int(callback_query.data.split(":")[1])
        categories = self.data_manager.get_categories()

        category = next((c for c in categories if c["id"] == cat_id), None)
        if not category:
            await callback_query.answer("❌ دسته‌بندی پیدا نشد.")
            return

        status_text = "✅ فعال" if category.get("active", True) else "❌ غیرفعال"
        toggle_text = "❌ غیرفعال‌سازی" if category.get("active", True) else "✅ فعال‌سازی"
        toggle_callback = f"toggle_category:{cat_id}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_callback)],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="manage_categories")]
        ])

        await callback_query.message.edit_text(
            f"📂 {category['name']}\nوضعیت فعلی: {status_text}",
            reply_markup=keyboard
        )

    async def handle_toggle_category(self, callback_query: CallbackQuery):
        if not callback_query.data.startswith("toggle_category:"):
            return

        cat_id = int(callback_query.data.split(":")[1])
        categories = self.data_manager.get_categories()

        category = next((c for c in categories if c["id"] == cat_id), None)
        if not category:
            await callback_query.answer("❌ دسته‌بندی پیدا نشد.")
            return

        # تغییر وضعیت
        category["active"] = not category.get("active", True)
        self.data_manager.save_data("categories", categories)

        # ساخت متن و دکمه جدید
        status_text = "✅ فعال" if category["active"] else "❌ غیرفعال"
        toggle_text = "❌ غیرفعال‌سازی" if category["active"] else "✅ فعال‌سازی"
        toggle_callback = f"toggle_category:{cat_id}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_callback)],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data="manage_categories")]
        ])

        try:
            await callback_query.message.edit_text(
                f"📂 {category['name']}\nوضعیت فعلی: {status_text}",
                reply_markup=keyboard
            )
        except TelegramBadRequest:
            await callback_query.answer("❌ خطا در ویرایش پیام.")

    async def handle_manage_products(self, callback_query: CallbackQuery):
        if callback_query.data != "manage_products":
            return

        categories = self.data_manager.get_categories()
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=cat["name"], callback_data=f"product_category:{cat['id']}")]
                for cat in categories
            ] + [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="view_settings")]]
        )

        await callback_query.message.edit_text("📂 انتخاب دسته‌بندی برای مدیریت محصولات:", reply_markup=keyboard)

    async def handle_product_category(self, callback_query: CallbackQuery):
        if not callback_query.data.startswith("product_category:"):
            return

        cat_id = int(callback_query.data.split(":")[1])
        products = self.data_manager.get_products()
        filtered = [p for p in products if p.get("category_id") == cat_id]

        if not filtered:
            await callback_query.message.edit_text("❌ محصولی در این دسته‌بندی نیست.")
            return

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text=f"{'✅' if p['active'] else '❌'} {p['name']}",
                    callback_data=f"product_status:{p['id']}"
                )] for p in filtered
            ] + [[InlineKeyboardButton(text="🔙 بازگشت", callback_data="manage_products")]]
        )

        await callback_query.message.edit_text("🛍️ محصولات این دسته‌بندی:", reply_markup=keyboard)

    async def handle_product_status(self, callback_query: CallbackQuery):
        if not callback_query.data.startswith("product_status:"):
            return

        product_id = int(callback_query.data.split(":")[1])
        products = self.data_manager.get_products()
        product = next((p for p in products if p["id"] == product_id), None)

        if not product:
            await callback_query.answer("❌ محصول پیدا نشد.")
            return

        status_text = "✅ فعال" if product.get("active", True) else "❌ غیرفعال"
        toggle_text = "❌ غیرفعال‌سازی" if product.get("active", True) else "✅ فعال‌سازی"
        toggle_callback = f"toggle_product:{product_id}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_callback)],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"product_category:{product['category_id']}")]
        ])

        await callback_query.message.edit_text(
            f"🛍️ {product['name']}\nوضعیت فعلی: {status_text}",
            reply_markup=keyboard
        )

    async def handle_toggle_product(self, callback_query: CallbackQuery):
        if not callback_query.data.startswith("toggle_product:"):
            return

        product_id = int(callback_query.data.split(":")[1])
        products = self.data_manager.get_products()
        product = next((p for p in products if p["id"] == product_id), None)

        if not product:
            await callback_query.answer("❌ محصول پیدا نشد.")
            return

        product["active"] = not product.get("active", True)
        self.data_manager.save_data("products", products)

        # نمایش وضعیت جدید
        status_text = "✅ فعال" if product["active"] else "❌ غیرفعال"
        toggle_text = "❌ غیرفعال‌سازی" if product["active"] else "✅ فعال‌سازی"
        toggle_callback = f"toggle_product:{product_id}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=toggle_text, callback_data=toggle_callback)],
            [InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"product_category:{product['category_id']}")]
        ])

        await callback_query.message.edit_text(
            f"🛍️ {product['name']}\nوضعیت فعلی: {status_text}",
            reply_markup=keyboard
        )

    async def handle_back_to_admin_menu(self, callback_query: CallbackQuery):
        if callback_query.data != "back_to_admin_menu":
            return

        await callback_query.message.edit_text(
            "💡 دستورات مدیریت محصولات:",
            reply_markup=self._product_commands_keyboard()
        )

    # ثبت هندلرها
    def register_handlers(self, dp: Dispatcher):
        dp.callback_query.register(self.cmd_add_product, F.data == "add_product")
        dp.callback_query.register(self.cmd_edit_product, F.data == "edit_product")
        dp.callback_query.register(self.cmd_delete_product, F.data == "delete_product")
        dp.callback_query.register(self.cmd_edit_category, F.data == "edit_category")
        dp.callback_query.register(self.cmd_delete_category, F.data == "delete_category")
        dp.callback_query.register(self.cmd_view_settings, F.data == "view_settings")
        dp.callback_query.register(self.handle_manage_categories, F.data == "manage_categories")
        dp.callback_query.register(self.handle_category_status, F.data.startswith("category_status:"))
        dp.callback_query.register(self.handle_toggle_category, F.data.startswith("toggle_category:"))
        dp.callback_query.register(self.handle_manage_products, F.data == "manage_products")
        dp.callback_query.register(self.handle_product_category, F.data.startswith("product_category:"))
        dp.callback_query.register(self.handle_product_status, F.data.startswith("product_status:"))
        dp.callback_query.register(self.handle_toggle_product, F.data.startswith("toggle_product:"))
        dp.callback_query.register(self.handle_back_to_admin_menu, F.data == "back_to_admin_menu")
        dp.callback_query.register(
            self.handle_category_selection,
            F.data.startswith("select_cat_"),
            StateFilter(ProductStates.adding_product_category)
        )
        dp.message.register(self.process_name, ProductStates.waiting_for_name)
        dp.message.register(self.process_price, ProductStates.waiting_for_price)
        dp.message.register(self.process_description, ProductStates.waiting_for_description)
        dp.callback_query.register(self.handle_edit_category, F.data.startswith("edit_cat_"))
        dp.callback_query.register(self.handle_edit_product_selection, F.data.startswith("edit_prod_"))
        dp.callback_query.register(self.handle_edit_name, F.data == "edit_name")
        dp.message.register(self.process_new_name, ProductStates.editing_name)
        dp.callback_query.register(self.handle_confirm_edit, F.data == "confirm_edit")
        dp.callback_query.register(self.handle_cancel_edit, F.data == "cancel_edit")
        # ویرایش قیمت
        dp.callback_query.register(self.handle_edit_price, F.data == "edit_price")
        dp.message.register(self.process_new_price, ProductStates.editing_price)
        dp.callback_query.register(self.handle_confirm_edit_price, F.data == "confirm_edit_price")

        # ویرایش توضیحات
        dp.callback_query.register(self.handle_edit_description, F.data == "edit_description")
        dp.message.register(self.process_new_description, ProductStates.editing_description)
        dp.callback_query.register(self.handle_confirm_edit_description, F.data == "confirm_edit_description")
                # حذف محصول
        dp.callback_query.register(self.cmd_delete_product,                F.data == "delete_product")
        dp.callback_query.register(self.handle_delete_category,            F.data.startswith("delete_cat_"))
        dp.callback_query.register(self.handle_delete_product_selection,   F.data.startswith("delete_prod_"))
        dp.callback_query.register(self.handle_confirm_delete,             F.data == "confirm_delete")
        dp.callback_query.register(self.handle_cancel_delete,              F.data == "cancel_delete")


        # نمایش لیست و شروع ویرایش (بدون فیلتر state خاص)
        dp.callback_query.register(
            self.cmd_edit_category,
            F.data == "edit_category"
)

        # انتخاب دسته (فقط در state=editing_category_select)
        dp.callback_query.register(
            self.handle_category_selected,
            F.data.startswith("select_cat_"),
            StateFilter(ProductStates.editing_category_select)
)

        # دریافت نام جدید (فقط در state=editing_category_name)
        dp.message.register(
            self.process_new_category_name,
            StateFilter(ProductStates.editing_category_name)
)

        # انصراف از ویرایش (بدون فیلتر یا فعال در همه stateها)
        dp.callback_query.register(
            self.handle_cancel_category_edit,
            F.data == "cancel_category_edit"
        # اگر بخواهید این هندلر در همه‌ی stateها فعال باشد، می‌توانید
        # StateFilter()  را نیز اضافه کنید.
)
        # handles hazf category

        dp.callback_query.register(self.cmd_delete_category, F.data == "delete_category")
        dp.callback_query.register(self.handle_delete_category_selected, F.data.startswith("delete_category_"), StateFilter(ProductStates.deleting_category_select))
        dp.callback_query.register(self.handle_confirm_delete_category, F.data == "confirm_delete_category", StateFilter(ProductStates.confirming_category_deletion))
        dp.callback_query.register(self.handle_cancel_delete_category, F.data == "cancel_delete_category")

        dp.callback_query.register(
            self.handle_add_category,
            F.data == "add_category"
        )
        
        dp.message.register(
            self.handle_category_name,
            StateFilter(CategoryStates.waiting_for_name)
        )
