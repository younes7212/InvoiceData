from aiogram import Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from utils.data_manager import DataManager
from utils.user_manager import UserManager
from utils.keyboards import Keyboards
from config import *
from datetime import datetime
import asyncio

class BroadcastStates(StatesGroup):
    waiting_for_message = State()
    waiting_for_target = State()

class MessageManager:
    """مدیریت پیام‌های همگانی برای ادمین"""
    
    def __init__(self, bot: Bot, data_manager: DataManager, user_manager: UserManager):
        self.bot = bot
        self.data_manager = data_manager
        self.user_manager = user_manager
        self.keyboards = Keyboards()
    
    async def show_broadcast_menu(self, message: Message):
        """نمایش منوی ارسال پیام همگانی"""
        users = self.data_manager.get_users()
        active_users = [u for u in users if u.get('is_active', True)]
        customers = [u for u in active_users if u.get('role') == UserState.CUSTOMER]
        admins = [u for u in active_users if u.get('role') == UserState.ADMIN]
        
        text = "📢 ارسال پیام همگانی:\n\n"
        text += f"👥 آمار کاربران:\n"
        text += f"• کل کاربران فعال: {len(active_users)}\n"
        text += f"• مشتریان: {len(customers)}\n"
        text += f"• ادمین‌ها: {len(admins)}\n\n"
        
        text += "🎯 انواع ارسال:\n"
        text += "• پیام همگانی: همه | متن پیام\n"
        text += "• پیام به مشتریان: مشتریان | متن پیام\n"
        text += "• پیام به ادمین‌ها: ادمین‌ها | متن پیام\n"
        text += "• پیام خصوصی: شناسه_کاربر | متن پیام\n\n"
        
        text += "💡 مثال:\n"
        text += "همه | سلام! امروز تخفیف ویژه داریم 🎉\n\n"
        
        text += "⚠️ نکات مهم:\n"
        text += "• پیام‌ها فقط به کاربران فعال ارسال می‌شود\n"
        text += "• از متن‌های مناسب و مفید استفاده کنید\n"
        text += "• ارسال پیام‌های تبلیغاتی زیاد ممنوع است"
        
        await message.answer(text)
    
    async def send_broadcast(self, message: Message, broadcast_data: str):
        """ارسال پیام همگانی"""
        try:
            parts = broadcast_data.split('|', 1)
            if len(parts) != 2:
                await message.answer("❌ فرمت نادرست! استفاده کنید:\nنوع_گیرنده | متن پیام")
                return
            
            target_type = parts[0].strip().lower()
            message_text = parts[1].strip()
            
            if len(message_text) < 5:
                await message.answer("❌ متن پیام باید حداقل 5 کاراکتر باشد.")
                return
            
            # تعیین فهرست گیرندگان
            recipients = self._get_recipients(target_type)
            
            if not recipients:
                await message.answer("❌ هیچ گیرنده‌ای برای این نوع پیام یافت نشد!")
                return
            
            # شروع ارسال
            await self._start_broadcast(message, recipients, message_text, target_type)
            
        except Exception as e:
            await message.answer(f"❌ خطا در ارسال پیام: {str(e)}")
    
    def _get_recipients(self, target_type: str):
        """تعیین فهرست گیرندگان بر اساس نوع"""
        users = self.data_manager.get_users()
        active_users = [u for u in users if u.get('is_active', True)]
        
        if target_type in ['همه', 'all']:
            return active_users
        elif target_type in ['مشتریان', 'customers']:
            return [u for u in active_users if u.get('role') == UserState.CUSTOMER]
        elif target_type in ['ادمین‌ها', 'ادمینها', 'admins']:
            return [u for u in active_users if u.get('role') == UserState.ADMIN]
        elif target_type.isdigit():
            # ارسال به کاربر خاص
            user_id = int(target_type)
            user = self.user_manager.get_user(user_id)
            return [user] if user and user.get('is_active', True) else []
        else:
            return []
    
    async def _start_broadcast(self, admin_message: Message, recipients: list, message_text: str, target_type: str):
        """شروع فرآیند ارسال همگانی"""
        total_users = len(recipients)
        
        # پیام تایید
        confirm_text = f"📤 شروع ارسال پیام به {total_users} کاربر...\n\n"
        confirm_text += f"🎯 گیرندگان: {target_type}\n"
        confirm_text += f"📝 متن پیام:\n{message_text[:100]}{'...' if len(message_text) > 100 else ''}"
        
        status_message = await admin_message.answer(confirm_text)
        
        # ارسال تدریجی
        success_count = 0
        failed_count = 0
        
        for i, user in enumerate(recipients):
            try:
                user_id = user.get('user_id')
                if user_id:
                    # اضافه کردن اطلاعات فرستنده
                    full_message = f"📢 پیام از {SHOP_NAME}:\n\n{message_text}"
                    
                    await self.bot.send_message(user_id, full_message)
                    success_count += 1
                    
                    # تأخیر برای جلوگیری از محدودیت‌های تلگرام
                    if (i + 1) % 20 == 0:
                        await asyncio.sleep(1)
                        
                        # بروزرسانی وضعیت
                        progress = f"📊 ارسال شده: {success_count}/{total_users}"
                        try:
                            await status_message.edit_text(confirm_text + f"\n\n{progress}")
                        except:
                            pass
                
            except Exception as e:
                failed_count += 1
                print(f"خطا در ارسال به {user.get('user_id', 'نامشخص')}: {e}")
        
        # گزارش نهایی
        final_text = f"✅ ارسال پیام همگانی تکمیل شد!\n\n"
        final_text += f"📊 نتیجه:\n"
        final_text += f"• موفق: {success_count} نفر\n"
        final_text += f"• ناموفق: {failed_count} نفر\n"
        final_text += f"• کل: {total_users} نفر\n\n"
        final_text += f"📝 متن ارسالی:\n{message_text}"
        
        try:
            await status_message.edit_text(final_text)
        except:
            await admin_message.answer(final_text)
        
        # ذخیره پیام در تاریخچه
        await self._save_broadcast_history(target_type, message_text, success_count, failed_count)
    
    async def _save_broadcast_history(self, target_type: str, message_text: str, success_count: int, failed_count: int):
        """ذخیره تاریخچه پیام‌های همگانی"""
        try:
            messages = self.data_manager.load_data('messages')
            
            # تولید ID جدید
            max_id = max([msg.get('id', 0) for msg in messages], default=0)
            
            broadcast_record = {
                'id': max_id + 1,
                'type': 'broadcast',
                'target': target_type,
                'message': message_text,
                'success_count': success_count,
                'failed_count': failed_count,
                'total_count': success_count + failed_count,
                'created_at': datetime.now().isoformat(),
                'admin_id': MAIN_ADMIN_ID  # یا ID ادمین فرستنده
            }
            
            messages.append(broadcast_record)
            self.data_manager.save_data('messages', messages)
            
        except Exception as e:
            print(f"خطا در ذخیره تاریخچه: {e}")
    
    async def show_broadcast_history(self, message: Message):
        """نمایش تاریخچه پیام‌های همگانی"""
        messages = self.data_manager.load_data('messages')
        broadcast_messages = [msg for msg in messages if msg.get('type') == 'broadcast']
        
        if not broadcast_messages:
            await message.answer("📋 هیچ پیام همگانی ارسال نشده است.")
            return
        
        # مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
        broadcast_messages.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        text = "📋 تاریخچه پیام‌های همگانی:\n\n"
        
        for i, msg in enumerate(broadcast_messages[:10], 1):  # نمایش 10 پیام آخر
            date_time = msg.get('created_at', '')[:16].replace('T', ' ')
            success_rate = (msg.get('success_count', 0) / max(msg.get('total_count', 1), 1)) * 100
            
            text += f"{i}. 📅 {date_time}\n"
            text += f"   🎯 گیرندگان: {msg.get('target', 'نامشخص')}\n"
            text += f"   📊 نرخ موفقیت: {success_rate:.1f}% ({msg.get('success_count', 0)}/{msg.get('total_count', 0)})\n"
            text += f"   📝 متن: {msg.get('message', '')[:50]}...\n\n"
        
        if len(broadcast_messages) > 10:
            text += f"... و {len(broadcast_messages) - 10} پیام دیگر"
        
        await message.answer(text)
    
    async def send_custom_message(self, message: Message, custom_data: str):
        """ارسال پیام سفارشی به کاربر خاص"""
        try:
            parts = custom_data.split('|', 1)
            if len(parts) != 2:
                await message.answer("❌ فرمت نادرست! استفاده کنید:\nشناسه_کاربر | متن پیام")
                return
            
            user_id = int(parts[0].strip())
            message_text = parts[1].strip()
            
            user = self.user_manager.get_user(user_id)
            if not user:
                await message.answer("❌ کاربر با این شناسه پیدا نشد!")
                return
            
            if not user.get('is_active', True):
                await message.answer("❌ این کاربر غیرفعال است!")
                return
            
            # ارسال پیام
            full_message = f"💬 پیام خصوصی از مدیریت {SHOP_NAME}:\n\n{message_text}"
            
            await self.bot.send_message(user_id, full_message)
            
            await message.answer(
                f"✅ پیام به {user.get('name', 'نامشخص')} ارسال شد!\n\n"
                f"📝 متن ارسالی:\n{message_text}"
            )
            
        except ValueError:
            await message.answer("❌ شناسه کاربر نامعتبر است!")
        except Exception as e:
            await message.answer(f"❌ خطا در ارسال پیام: {str(e)}")
    
    async def create_announcement(self, message: Message, announcement_text: str):
        """ایجاد اعلان مهم"""
        try:
            if len(announcement_text.strip()) < 10:
                await message.answer("❌ متن اعلان باید حداقل 10 کاراکتر باشد.")
                return
            
            # تولید اعلان با فرمت ویژه
            formatted_announcement = f"""
🔔 <b>اعلان مهم از {SHOP_NAME}</b>

{announcement_text.strip()}

📅 تاریخ: {datetime.now().strftime('%Y/%m/%d - %H:%M')}
            """
            
            # ارسال به همه کاربران فعال
            users = self.data_manager.get_users()
            active_users = [u for u in users if u.get('is_active', True)]
            
            await self._start_broadcast(message, active_users, formatted_announcement, "اعلان مهم")
            
        except Exception as e:
            await message.answer(f"❌ خطا در ایجاد اعلان: {str(e)}")
    
    async def get_message_statistics(self, message: Message):
        """نمایش آمار پیام‌ها"""
        messages = self.data_manager.load_data('messages')
        broadcast_messages = [msg for msg in messages if msg.get('type') == 'broadcast']
        
        if not broadcast_messages:
            await message.answer("📊 هیچ آماری از پیام‌ها موجود نیست.")
            return
        
        total_broadcasts = len(broadcast_messages)
        total_sent = sum(msg.get('success_count', 0) for msg in broadcast_messages)
        total_failed = sum(msg.get('failed_count', 0) for msg in broadcast_messages)
        
        text = "📊 آمار پیام‌های همگانی:\n\n"
        text += f"📢 تعداد پیام‌های ارسالی: {total_broadcasts}\n"
        text += f"✅ موفق: {total_sent:,} پیام\n"
        text += f"❌ ناموفق: {total_failed:,} پیام\n"
        
        if total_sent + total_failed > 0:
            success_rate = (total_sent / (total_sent + total_failed)) * 100
            text += f"📈 نرخ موفقیت کلی: {success_rate:.1f}%\n"
        
        # آمار امروز
        today = datetime.now().strftime('%Y-%m-%d')
        today_messages = [msg for msg in broadcast_messages if msg.get('created_at', '').startswith(today)]
        
        if today_messages:
            today_sent = sum(msg.get('success_count', 0) for msg in today_messages)
            text += f"\n📅 آمار امروز:\n"
            text += f"📢 پیام‌های ارسالی: {len(today_messages)}\n"
            text += f"✅ تعداد دریافت‌کنندگان: {today_sent}\n"
        
        await message.answer(text)
