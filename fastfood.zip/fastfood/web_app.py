# web_app.py - اپلیکیشن فلاسک
from flask import Flask, render_template, request, jsonify, redirect, url_for
from utils.data_manager import DataManager
from utils.user_manager import UserManager
from config import SHOP_NAME, SHOP_PHONE, SHOP_ADDRESS
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# ایجاد نمونه‌های مدیریت داده
data_manager = DataManager()
user_manager = UserManager()

@app.route('/')
def index():
    """صفحه اصلی"""
    stats = {
        'users_count': len(data_manager.get_users()),
        'orders_count': len(data_manager.get_orders()),
        'products_count': len(data_manager.get_active_products()),
        'total_revenue': sum(order.get('total', 0) for order in data_manager.get_orders())
    }
    return render_template('index.html', stats=stats, shop_name=SHOP_NAME)

@app.route('/orders')
def orders():
    """صفحه سفارشات"""
    all_orders = data_manager.get_orders()
    # مرتب‌سازی بر اساس تاریخ
    sorted_orders = sorted(all_orders, key=lambda x: x.get('id', 0), reverse=True)
    return render_template('orders.html', orders=sorted_orders)

@app.route('/products')
def products():
    """صفحه محصولات"""
    all_products = data_manager.get_active_products()
    categories = data_manager.get_active_categories()
    return render_template('products.html', products=all_products, categories=categories)

@app.route('/users')
def users():
    """صفحه کاربران"""
    all_users = data_manager.get_users()
    return render_template('users.html', users=all_users)

@app.route('/api/orders/<int:order_id>/status', methods=['POST'])
def update_order_status(order_id):
    """بروزرسانی وضعیت سفارش"""
    new_status = request.json.get('status')
    if data_manager.update_order_status(order_id, new_status):
        return jsonify({'success': True})
    return jsonify({'success': False}), 400

@app.route('/api/products', methods=['POST'])
def add_product():
    """افزودن محصول جدید"""
    product_data = {
        'name': request.json.get('name'),
        'price': int(request.json.get('price')),
        'description': request.json.get('description'),
        'category_id': int(request.json.get('category_id')),
        'is_active': True
    }
    
    if data_manager.add_product(product_data):
        return jsonify({'success': True})
    return jsonify({'success': False}), 400

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    """حذف محصول"""
    if data_manager.delete_product(product_id):
        return jsonify({'success': True})
    return jsonify({'success': False}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
