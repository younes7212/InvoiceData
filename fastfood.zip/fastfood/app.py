# app.py
from flask import Flask, render_template, jsonify, request
import json
import os
from datetime import datetime, timedelta
from utils.data_manager import DataManager
from config import *

app = Flask(__name__)
app.secret_key = 'vizhe_amir_food_bot_secret_key'

# تنظیم مسیر templates
app.template_folder = 'templates'
app.static_folder = 'static'

# ایجاد instance از DataManager
data_manager = DataManager()

@app.route('/')
def dashboard():
    """داشبورد اصلی"""
    # دریافت آمار
    users = data_manager.get_users()
    orders = data_manager.get_orders()
    products = data_manager.get_products()
    categories = data_manager.get_categories()
    
    # آمار کلی
    stats = {
        'total_users': len(users),
        'total_orders': len(orders),
        'total_products': len(products),
        'total_categories': len(categories),
        'active_products': len([p for p in products if p.get('active', True)]),
        'pending_orders': len([o for o in orders if o['status'] == OrderStatus.PENDING]),
        'total_revenue': sum(o['total_price'] for o in orders if o['status'] == OrderStatus.DELIVERED)
    }
    
    # سفارشات امروز
    today = datetime.now().strftime('%Y-%m-%d')
    today_orders = [o for o in orders if o.get('created_at', '').startswith(today)]
    stats['today_orders'] = len(today_orders)
    stats['today_revenue'] = sum(o['total_price'] for o in today_orders if o['status'] == OrderStatus.DELIVERED)
    
    return render_template('dashboard.html', stats=stats, shop_name=SHOP_NAME)

@app.route('/orders')
def orders():
    """صفحه مدیریت سفارشات"""
    orders_data = data_manager.get_orders()
    # مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
    orders_data.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    return render_template('orders.html', orders=orders_data, shop_name=SHOP_NAME)

@app.route('/products')
def products():
    """صفحه مدیریت محصولات"""
    products_data = data_manager.get_products()
    categories_data = data_manager.get_categories()
    return render_template('products.html', products=products_data, categories=categories_data, shop_name=SHOP_NAME)

@app.route('/users')
def users():
    """صفحه مدیریت کاربران"""
    users_data = data_manager.get_users()
    return render_template('users.html', users=users_data, shop_name=SHOP_NAME)

@app.route('/settings')
def settings():
    """صفحه تنظیمات"""
    config_data = {
        'shop_name': SHOP_NAME,
        'shop_phone': SHOP_PHONE,
        'shop_address': SHOP_ADDRESS,
        'bot_username': BOT_USERNAME,
        'bot_name': BOT_NAME,
        'admin_username': MAIN_ADMIN_USERNAME
    }
    return render_template('settings.html', config=config_data, shop_name=SHOP_NAME)

# API endpoints
@app.route('/api/stats')
def api_stats():
    """API برای دریافت آمار"""
    users = data_manager.get_users()
    orders = data_manager.get_orders()
    
    # آمار هفته گذشته
    weekly_stats = []
    for i in range(7):
        date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
        day_orders = [o for o in orders if o.get('created_at', '').startswith(date)]
        weekly_stats.append({
            'date': date,
            'orders': len(day_orders),
            'revenue': sum(o['total_price'] for o in day_orders if o['status'] == OrderStatus.DELIVERED)
        })
    
    return jsonify({
        'weekly_stats': weekly_stats,
        'order_status_stats': {
            'pending': len([o for o in orders if o['status'] == OrderStatus.PENDING]),
            'confirmed': len([o for o in orders if o['status'] == OrderStatus.CONFIRMED]),
            'preparing': len([o for o in orders if o['status'] == OrderStatus.PREPARING]),
            'ready': len([o for o in orders if o['status'] == OrderStatus.READY]),
            'delivered': len([o for o in orders if o['status'] == OrderStatus.DELIVERED]),
            'cancelled': len([o for o in orders if o['status'] == OrderStatus.CANCELLED])
        }
    })

@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    """API برای تغییر وضعیت سفارش"""
    new_status = request.json.get('status')
    if data_manager.update_order_status(order_id, new_status):
        return jsonify({'success': True})
    return jsonify({'success': False}), 400

@app.route('/api/products', methods=['POST'])
def add_product():
    """API برای افزودن محصول جدید"""
    product_data = request.json
    if data_manager.add_product(product_data):
        return jsonify({'success': True})
    return jsonify({'success': False}), 400

if __name__ == '__main__':
    # ایجاد پوشه‌های مورد نیاز
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    
    # راه‌اندازی Flask
    app.run(host='0.0.0.0', port=FLASK_PORT, debug=FLASK_DEBUG)
