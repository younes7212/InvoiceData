# utils/user_manager.py - تصحیح شده
from typing import Dict, Optional, Any
from .data_manager import DataManager
from config import UserRole, MAIN_ADMIN_ID
from datetime import datetime
from typing import List
import jdatetime

class UserManager:
    """کلاس مدیریت کاربران"""
    
    def __init__(self):
        self.data_manager = DataManager()

    def get_user_role(self, user_id: int) -> str:
        """تشخیص نقش کاربر"""
        if user_id == MAIN_ADMIN_ID:
            return UserRole.ADMIN

        user = self.data_manager.get_user_by_id(user_id)
        if user:
            return user.get("role", UserRole.CUSTOMER).lower()
        else:
            return UserRole.GUEST
    
    def is_registered(self, user_id: int) -> bool:
        """چک کردن ثبت‌نام کاربر"""
        return self.data_manager.get_user_by_id(user_id) is not None
    
    def is_admin(self, user_id: int) -> bool:
        """چک کردن ادمین بودن"""
        return user_id == MAIN_ADMIN_ID
    
    def register_user(self, user_data: Dict[str, Any]) -> bool:
        """ثبت‌نام کاربر جدید"""
        if self.is_registered(user_data.get('user_id', 0)):
            return False
        return self.data_manager.add_user(user_data)
    
    def get_user_cart(self, user_id: int) -> dict:
        """دریافت سبد خرید کامل کاربر به‌صورت تفکیک‌شده"""
        user = self.data_manager.get_user_by_id(user_id)
        cart_raw = user.get("cart", []) if user else []

        cart = {
            "products": [],
            "location": None,
            "note": None
        }

        for item in cart_raw:
            item_type = item.get("type")
            if item_type == "product":
                cart["products"].append(item)
            elif item_type == "location":
                cart["location"] = item
            elif item_type == "note":
                cart["note"] = item.get("text")

        return cart

    def update_user_cart(self, user_id: int, cart: list) -> bool:
        users = self.data_manager.load_data("users")
        for i, user in enumerate(users):
            if user.get("user_id") == user_id:
                users[i]["cart"] = cart
                users[i]["updated_at"] = jdatetime.datetime.now().isoformat()
                return self.data_manager.save_data("users", users)
        return False
    
    def clear_user_cart(self, user_id: int) -> bool:
        """خالی کردن سبد خرید"""
        return self.update_user_cart(user_id, [])

    def set_user_total_message_id(self, user_id: int, message_id: int) -> bool:
        """ذخیره message_id مجموع مبلغ برای کاربر"""
        updated_data = {
            'total_message_id': message_id,
            'updated_at': jdatetime.datetime.now().isoformat()
        }
        return self.data_manager.update_user(user_id, updated_data)

    def get_user_total_message_id(self, user_id: int) -> Optional[int]:
        """دریافت message_id مجموع مبلغ برای کاربر"""
        user = self.data_manager.get_user_by_id(user_id)
        if user:
            return user.get('total_message_id')
        return None
    def set_user_cart_message_ids(self, user_id: int, message_ids: List[int]) -> bool:
        updated_data = {
            'cart_message_ids': message_ids,
            'updated_at': datetime.now().isoformat()
        }
        return self.data_manager.update_user(user_id, updated_data)

    def get_user_cart_message_ids(self, user_id: int) -> List[int]:
        user = self.data_manager.get_user_by_id(user_id)
        return user.get('cart_message_ids', []) if user else []
