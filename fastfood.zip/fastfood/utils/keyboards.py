# utils/keyboards.py - تصحیح شده
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Dict, Any
from aiogram.utils.keyboard import InlineKeyboardBuilder

def cart_inline():
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ تایید سفارش", callback_data="confirm_order")
    builder.button(text="🗑 خالی کردن سبد", callback_data="clear_cart")
    builder.button(text="🔙 بازگشت", callback_data="go_back")
    builder.adjust(1)
    return builder.as_markup()

class Keyboards:
    """کلاس تولید کیبوردها"""
    
    @staticmethod
    def guest_menu() -> ReplyKeyboardMarkup:
        """منوی مهمان"""
        keyboard = [
            [KeyboardButton(text="📝 ثبت‌نام")],
            [KeyboardButton(text="📋 مشاهده منو"), KeyboardButton(text="📞 تماس با ما")]
        ]
        return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
    
    @staticmethod
    def customer_menu() -> ReplyKeyboardMarkup:
        """منوی مشتری"""
        keyboard = [
            [KeyboardButton(text="🛒 سفارش"), KeyboardButton(text="🛍 سبد خرید")],
            [KeyboardButton(text="📋 سفارشات من"), KeyboardButton(text="👤 پروفایل")]
        ]
        return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
    
    @staticmethod
    def admin_menu() -> ReplyKeyboardMarkup:
        """منوی ادمین"""
        keyboard = [
            [KeyboardButton(text="📦 مدیریت محصولات"), KeyboardButton(text="🛍 مدیریت سفارشات")],
            [KeyboardButton(text="👥 مدیریت کاربران"), KeyboardButton(text="📊 آمار و گزارشات")],
            [KeyboardButton(text="💬 ارسال پیام"), KeyboardButton(text="⚙️ تنظیمات")],
            [KeyboardButton(text="🔙 بازگشت به منوی عادی")]
        ]
        return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
    
    @staticmethod
    def products_inline(products: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
        """کیبورد محصولات"""
        buttons = []
        for product in products:
            buttons.append([InlineKeyboardButton(
                text=f"{product['name']} - {product['price']:,} تومان",
                callback_data=f"product_{product['id']}"
            )])
        buttons.append([InlineKeyboardButton(text="🔙 برگشت", callback_data="back_to_menu")])
        return InlineKeyboardMarkup(inline_keyboard=buttons)
    
    @staticmethod
    def categories_inline(categories: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
        """کیبورد دسته‌بندی‌ها"""
        buttons = []
        for category in categories:
            buttons.append([InlineKeyboardButton(
                text=category['name'],
                callback_data=f"category_{category['id']}"
            )])
        buttons.append([InlineKeyboardButton(text="🔙 برگشت", callback_data="back_to_menu")])
        return InlineKeyboardMarkup(inline_keyboard=buttons)
    
    @staticmethod
    def cart_inline() -> InlineKeyboardMarkup:
        """کیبورد سبد خرید"""
        buttons = [
            [InlineKeyboardButton(text="✅ تایید سفارش", callback_data="confirm_order")],
            [InlineKeyboardButton(text="🗑 خالی کردن سبد", callback_data="clear_cart")],
            [InlineKeyboardButton(text="🔙 برگشت", callback_data="back_to_menu")]
        ]
        return InlineKeyboardMarkup(inline_keyboard=buttons)
    
    @staticmethod
    def quantity_inline(product_id: int) -> InlineKeyboardMarkup:
        """کیبورد انتخاب تعداد"""
        buttons = [
            [
                InlineKeyboardButton(text="1", callback_data=f"add_cart_{product_id}_1"),
                InlineKeyboardButton(text="2", callback_data=f"add_cart_{product_id}_2"),
                InlineKeyboardButton(text="3", callback_data=f"add_cart_{product_id}_3")
            ],
            [InlineKeyboardButton(text="🔙 برگشت", callback_data="back_to_products")]
        ]
        return InlineKeyboardMarkup(inline_keyboard=buttons)
    
    @staticmethod
    def order_management_inline(order_id: int) -> InlineKeyboardMarkup:
        """کیبورد مدیریت سفارش"""
        buttons = [
            [InlineKeyboardButton(text="✅ تایید", callback_data=f"order_confirm_{order_id}")],
            [InlineKeyboardButton(text="🍳 در حال آماده‌سازی", callback_data=f"order_preparing_{order_id}")],
            [InlineKeyboardButton(text="✅ آماده", callback_data=f"order_ready_{order_id}")],
            [InlineKeyboardButton(text="🚚 تحویل داده شده", callback_data=f"order_delivered_{order_id}")],
            [InlineKeyboardButton(text="❌ لغو", callback_data=f"order_cancel_{order_id}")]
        ]
        return InlineKeyboardMarkup(inline_keyboard=buttons)
