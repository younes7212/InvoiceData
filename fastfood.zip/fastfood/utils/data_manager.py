# utils/data_manager.py - تصحیح کامل
import json
import os
from datetime import datetime
from config import *
import jdatetime
from difflib import SequenceMatcher
from geopy.distance import geodesic
from typing import Union, Dict, List, Any, Tuple, Optional

class DataManager:
    """کلاس مدیریت داده‌ها"""
    
    def __init__(self):
        self.data_files = {
            'users': USERS_FILE,
            'products': PRODUCTS_FILE,
            'categories': CATEGORIES_FILE,
            'orders': ORDERS_FILE,
            'messages': MESSAGES_FILE,
            'locate': LOCATE_FILE,
            'points': POINTS_FILE
        }
        self.initialize_data_files()
        self._temp = {}
        self.min_order_amount = 50000

    def set(self, key, value):
        self._temp[key] = value

    def get(self, key):
        return self._temp.get(key)

    def delete(self, key):
        if key in self._temp:
            del self._temp[key]


    def initialize_data_files(self) -> None:
        """ایجاد فایل‌های JSON اولیه"""
        default_data = {
            'users': [],
            'locate': [],
            'points': [],
            'products': [
                {
                    "id": 1,
                    "name": "🍔 چیزبرگر ویژه",
                    "description": "برگر با گوشت تازه و پنیر",
                    "price": 45000,
                    "category_id": 1,
                    "image": None,
                    "active": True,
                    "created_at": datetime.now().isoformat()
                },
                {
                    "id": 2,
                    "name": "🍕 پیتزا پپرونی",
                    "description": "پیتزا با پپرونی و پنیر",
                    "price": 65000,
                    "category_id": 2,
                    "image": None,
                    "active": True,
                    "created_at": datetime.now().isoformat()
                },
                {
                    "id": 3,
                    "name": "🥤 نوشابه",
                    "description": "نوشابه سرد",
                    "price": 8000,
                    "category_id": 3,
                    "image": None,
                    "active": True,
                    "created_at": datetime.now().isoformat()
                }
            ],
            'categories': [
                {
                    "id": 1,
                    "name": "🍔 برگر",
                    "description": "انواع برگرهای خوشمزه",
                    "active": True,
                    "created_at": datetime.now().isoformat()
                },
                {
                    "id": 2,
                    "name": "🍕 پیتزا",
                    "description": "پیتزاهای تازه و داغ",
                    "active": True,
                    "created_at": datetime.now().isoformat()
                },
                {
                    "id": 3,
                    "name": "🥤 نوشیدنی",
                    "description": "نوشیدنی های سرد و گرم",
                    "active": True,
                    "created_at": datetime.now().isoformat()
                }
            ],
            'orders': [],
            'messages': []
        }
        
        for key, file_path in self.data_files.items():
            if not os.path.exists(file_path):
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                self.save_data(key, default_data[key])
    
    def load_data(self, data_type: str) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """بارگذاری داده‌ها از فایل، پشتیبانی کامل از dict و list"""
        try:
            file_path = self.data_files.get(data_type)
            if not file_path or not os.path.exists(file_path):
                return []

            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
                elif isinstance(data, list):
                    return data
                else:
                    print(f"⚠️ ساختار فایل '{data_type}' نامعتبر است")
                    return []
        except Exception as e:
            print(f"خطا در بارگذاری {data_type}: {e}")
            return []

    def save_data(self, data_type: str, data: Union[Dict[str, Any], List[Dict[str, Any]]]) -> bool:
        """ذخیره داده‌ها در فایل — پشتیبانی از dict و list"""
        try:
            file_path = self.data_files.get(data_type)
            if not file_path:
                return False

            os.makedirs(os.path.dirname(file_path), exist_ok=True)

            # بررسی نوع داده و ذخیره‌سازی مناسب
            if isinstance(data, dict) or isinstance(data, list):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                return True
            else:
                print(f"⚠️ ساختار داده نامعتبر برای ذخیره {data_type}")
                return False
        except Exception as e:
            print(f"خطا در ذخیره {data_type}: {e}")
            return False
    
    def update_data(self, data_type: str, new_data: Dict[str, Any]) -> bool:
        try:
            file_path = self.data_files.get(data_type)
            if not file_path:
                return False

            # خواندن داده‌های قبلی
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    current_data = json.load(f)
            else:
                current_data = {}

            if isinstance(current_data, list):
                current_data = {"items": current_data}
            elif not isinstance(current_data, dict):
                current_data = {}

            # ادغام داده‌های جدید
            current_data.update(new_data)

            # ذخیره نهایی
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(current_data, f, ensure_ascii=False, indent=2)

            return True
        except Exception as e:
            print(f"خطا در آپدیت {data_type}: {e}")
            return False

    # متدهای کاربران
    def get_users(self) -> List[Dict[str, Any]]:
        """دریافت تمام کاربران"""
        return self.load_data('users')
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        users = self.load_data("users")
        if not isinstance(users, list):
            print("⚠️ فایل users باید لیست باشد.")
            return None
    
        for user in users:
            if isinstance(user, dict) and str(user.get("user_id")) == str(user_id):
                return user

        print(f"❌ کاربر با user_id {user_id} یافت نشد.")
        return None

    def add_user(self, user_data: Dict[str, Any]) -> bool:
        """اضافه کردن کاربر جدید"""
        users = self.get_users()
        user_data['created_at'] = jdatetime.datetime.now().isoformat()
        users.append(user_data)
        return self.save_data('users', users)
    
    def delete_user(self, user_id: int) -> bool:
        users = self.data_manager.get_users()
        users = [u for u in users if u.get("user_id") != user_id]
        return self.data_manager.save_data("users", users)

    def update_user(self, user_id: int, updated_data: Dict[str, Any]) -> bool:
        """بروزرسانی اطلاعات کاربر"""
        users = self.get_users()
        for i, user in enumerate(users):
            if str(user.get('user_id')) == str(user_id):
                users[i].update(updated_data)
                users[i]['updated_at'] = jdatetime.datetime.now().isoformat()
                return self.save_data('users', users)
        return False
    
    # متدهای محصولات
    def get_products(self) -> List[Dict[str, Any]]:
        """دریافت تمام محصولات"""
        return self.load_data('products')
    
    def get_product_by_id(self, product_id: int) -> Optional[Dict[str, Any]]:
        """دریافت محصول با ID"""
        products = self.get_products()
        for product in products:
            if product.get('id') == product_id:
                return product
        return None

    def get_products_by_category(self, category_id: int) -> List[Dict[str, Any]]:
        """دریافت محصولات یک دسته‌بندی خاص"""
        products = self.get_products()   # متد load_data('products') را صدا می‌زند
        return [
            p for p in products
            if p.get("category_id") == category_id
        ]

    # ← این متدها را اضافه کنید
    def update_product_name(self, product_id: int, new_name: str) -> bool:
        products = self.get_products()
        for p in products:
            if p.get('id') == product_id:
                p['name'] = new_name
                return self.save_data('products', products)
        return False

    def update_product_price(self, product_id: int, new_price: float) -> bool:
        products = self.get_products()
        for p in products:
            if p.get('id') == product_id:
                p['price'] = new_price
                return self.save_data('products', products)
        return False

    def update_product_description(self, product_id: int, new_description: str) -> bool:
        products = self.get_products()
        for p in products:
            if p.get('id') == product_id:
                p['description'] = new_description
                return self.save_data('products', products)
        return False


    def add_product(self, product_data: Dict[str, Any]) -> bool:
        """اضافه کردن محصول جدید"""
        products = self.get_products()
        max_id = max([p.get('id', 0) for p in products], default=0)
        product_data['id'] = max_id + 1
        product_data['created_at'] = datetime.now().isoformat()
        products.append(product_data)
        return self.save_data('products', products)


    def delete_product(self, product_id: int) -> bool:
        products = self.get_products()
        filtered = [p for p in products if p.get("id") != product_id]
        return self.save_data('products', filtered)

    # متدهای دسته‌بندی
    def get_categories(self) -> List[Dict[str, Any]]:
        """دریافت تمام دسته‌بندی‌ها"""
        return self.load_data('categories')
    
    def get_active_categories(self) -> List[Dict[str, Any]]:
        """دریافت دسته‌بندی‌های فعال"""
        categories = self.get_categories()
        return [c for c in categories if c.get('active', True)]
    
    def get_active_products(self) -> List[Dict[str, Any]]:
        """دریافت محصولات فعال"""
        products = self.get_products()
        return [p for p in products if p.get('active', True)]
    
    def get_category_by_id(self, category_id: int) -> Optional[Dict[str, Any]]:
        """دریافت دسته‌بندی با ID"""
        categories = self.get_categories()
        for category in categories:
            if category.get('id') == category_id:
                return category
        return None

    def delete_category(self, category_id: int) -> bool:
        categories = self.get_categories()
        filtered = [c for c in categories if c.get("id") != category_id]
        return self.save_data("categories", filtered)

    def add_category(self, name: str):
        categories = self.get_categories()
        new_id = max([c["id"] for c in categories], default=0) + 1
        categories.append({"id": new_id, "name": name})
        self.save_data("categories", categories)


    # ... سایر متدها ...

    def update_category_name(self, category_id: int, new_name: str) -> bool:
        categories = self.get_categories()
        for cat in categories:
            if cat.get("id") == category_id:
                cat["name"] = new_name
                return self.save_data("categories", categories)
        return False

    # متدها
    def get_order_by_id(self, order_id: int) -> Optional[Dict[str, Any]]:
        """دریافت سفارش کامل بر اساس شناسه"""
        orders = self.load_data("orders")
        for order in orders:
            if order.get("id") == order_id:
                return order
        return None

    def get_orders(self) -> List[Dict[str, Any]]:
        raw_orders = self.load_data('orders')
        orders: List[Dict[str, Any]] = []

        for o in raw_orders:
            created_at = o.get('created_at')
            try:
                # تبدیل تاریخ شمسی به میلادی
                if created_at and created_at.startswith("140"):
                    date_part, time_part = created_at.split("T")
                    year, month, day = map(int, date_part.split("-"))
                    jalali_dt = jdatetime.datetime(year, month, day)
                    gregorian_dt = jalali_dt.togregorian()
                    dt = datetime.combine(gregorian_dt.date(), datetime.strptime(time_part, "%H:%M:%S.%f").time())
                else:
                    dt = datetime.fromisoformat(created_at) if created_at else datetime.min
            except Exception:
                dt = datetime.min

            user_obj = self.get_user_by_id(o.get('user_id'))
            user_label = user_obj.get('name') if user_obj else f"کاربر #{o.get('user_id')}"

            jalali_display = jdatetime.datetime.fromgregorian(datetime=dt)

            orders.append({
                'id':         o.get('id'),
                'user':       user_label,
                'amount':     o.get('total', 0),
                'status':     o.get('status', 'نامشخص'),
                'created_at': jalali_display.strftime('%Y/%m/%d %H:%M'),
                'date':       jalali_display.strftime('%Y/%m/%d'),
            })

        orders.sort(key=lambda x: x['created_at'], reverse=True)
        return orders

    def get_full_user_orders(self, user_id: int) -> List[Dict[str, Any]]:
        orders = self.load_data("orders")
        return [o for o in orders if o.get("user_id") == user_id]


    def get_user_orders(self, user_id: int) -> List[Dict[str, Any]]:
        """دریافت سفارشات کاربر"""
        orders = self.get_orders()
        return [o for o in orders if o.get('user_id') == user_id]
    
    def add_order(self, order_data: Dict[str, Any]) -> bool:
        """ذخیره مستقیم سفارش بدون تغییر در داده‌ها"""
        orders = self.load_data('orders')  # یا get_raw_orders اگر داری
        orders.append(order_data)
        return self.save_data('orders', orders)
    
    def update_order_status(self, order_id: int, status: str) -> bool:
        from config import OrderStatus

        if status not in OrderStatus.__dict__.values():
            print(f"❌ وضعیت نامعتبر: {status}")
            return False

        orders = self.load_data("orders")
        for i, order in enumerate(orders):
            if order.get('id') == order_id:
                orders[i].update({
                    "status": status,
                    "updated_at": jdatetime.datetime.now().isoformat()
                })
                return self.save_data('orders', orders)

        print(f"❌ سفارش با شناسه {order_id} پیدا نشد.")
        return False

    def update_orders(self, order_id: int, new_data: Dict[str, Any]) -> bool:
        """به‌روزرسانی سفارش با شناسه مشخص"""
        orders = self.load_data('orders')
        updated = False

        for i, order in enumerate(orders):
            if order.get('id') == order_id:
                orders[i].update(new_data)
                updated = True
                break

        if updated:
            return self.save_data('orders', orders)
        return False

    def delete_order(self, order_id: int) -> bool:
        """حذف سفارش با شناسه مشخص"""
        orders = self.load_data("orders")
        new_orders = [o for o in orders if o.get("id") != order_id]

        if len(new_orders) == len(orders):
            # یعنی سفارشی با این شناسه پیدا نشده
            return False

        return self.save_data("orders", new_orders)

    def get_latest_order_for_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        orders = self.load_data("orders")

        user_orders = [
            o for o in orders
            if o.get("user_id") == user_id and o.get("status", "").strip() == OrderStatus.PENDING
        ]

        if not user_orders:
            return None
    
        return sorted(user_orders, key=lambda o: o.get("created_at", ""), reverse=True)[0]

    def add_to_cart(self, user_id: int, product_id: int) -> bool:
        user_id = str(user_id)
        users = self.load_data('users')

        for i, user in enumerate(users):
            if str(user.get('user_id')) == user_id:
                cart_raw = user.get('cart', [])
                if not isinstance(cart_raw, list):
                    cart_raw = []

                product_id = int(product_id)
                found = False

                for item in cart_raw:
                    if not isinstance(item, dict):
                        continue
                    if item.get("type") != "product":
                        continue
                    if item.get("id") == product_id:
                        item["quantity"] += 1
                        found = True
                        break

                if not found:
                    cart_raw.append({
                        "type": "product",
                        "id": product_id,
                        "quantity": 1
                    })

                users[i]["cart"] = cart_raw
                users[i]["updated_at"] = jdatetime.datetime.now().isoformat()
                return self.save_data("users", users)

        print(f"⚠️ کاربر {user_id} در users.json پیدا نشد. افزودن به سبد انجام نشد.")
        return False

    def remove_from_cart(self, user_id: int, product_id: int) -> bool:
        user = self.get_user_by_id(user_id)
        if not user:
            return False

        cart = user.get('cart', [])
        if not isinstance(cart, list):
            cart = []

        product_id = int(product_id)
        for item in cart:
            if not isinstance(item, dict):
                continue
            if item.get("type") != "product":
                continue
            if int(item.get("id", -1)) == product_id:
                item["quantity"] -= 1
                if item["quantity"] <= 0:
                    # حذف کامل آیتم اگر صفر شد
                    cart = [i for i in cart if not (
                        isinstance(i, dict) and
                        i.get("type") == "product" and
                        int(i.get("id", -1)) == product_id
                    )]
                break

        return self.update_user(user_id, {'cart': cart})


    def get_payment_cards(self) -> list[dict]:
        items = self.load_data("messages")
        if not isinstance(items, list):
            return []

        return [item for item in items if item.get("type") == "card"]

    def add_payment_card(self, number: str, owner: str) -> bool:
        if not number.isdigit() or len(number) != 16:
            return False

        cards = self.load_data("messages")
        if not isinstance(cards, list):
            cards = []

        cards.append({
            "type": "card",
            "number": number,
            "owner": owner
        })

        return self.save_data("messages", cards)

    def edit_payment_card(self, index: int, new_number: str) -> bool:
        if not new_number.isdigit() or len(new_number) != 16:
            return False

        items = self.load_data("messages")
        if not isinstance(items, list):
            return False

        # فیلتر کارت‌ها
        card_indices = [i for i, item in enumerate(items) if item.get("type") == "card"]

        if 0 <= index < len(card_indices):
            target_idx = card_indices[index]
            items[target_idx]["number"] = new_number
            return self.save_data("messages", items)

        return False

    def delete_payment_card(self, index: int) -> bool:
        items = self.load_data("messages")
        if not isinstance(items, list):
            return False

        # پیدا کردن ایندکس واقعی کارت‌ها
        card_indices = [i for i, item in enumerate(items) if item.get("type") == "card"]

        if 0 <= index < len(card_indices):
            target_idx = card_indices[index]
            items.pop(target_idx)
            return self.save_data("messages", items)

        return False

    def set_min_order_amount(self, amount: int) -> bool:
        items = self.load_data("messages")
        if not isinstance(items, list):
            items = []

        # حذف قبلی‌ها از نوع min_order
        items = [item for item in items if item.get("type") != "min_order"]

        # افزودن جدید
        items.append({
            "type": "min_order",
            "amount": amount
        })

        self.min_order_amount = amount
        return self.save_data("messages", items)

    def get_min_order_amount(self) -> int:
        items = self.load_data("messages")
        if not isinstance(items, list):
            return self.min_order_amount

        for item in items:
            if item.get("type") == "min_order":
                return item.get("amount", self.min_order_amount)

        return self.min_order_amount

    def get_delivery_area(self) -> Dict[str, Any]:
        data = self.load_data("locate")
        if isinstance(data, list) and data:
            return data[0].get("delivery_area", {})
        elif isinstance(data, dict):
            return data.get("delivery_area", {})
        return {}

    def update_delivery_area(self, new_data: Dict[str, Any]) -> bool:
        locate_data = self.load_data("locate")
        if not isinstance(locate_data, dict):
            locate_data = {}

        delivery_area = locate_data.get("delivery_area", {})
        if not isinstance(delivery_area, dict):
            delivery_area = {}

        delivery_area.update(new_data)
        locate_data["delivery_area"] = delivery_area

        return self.save_data("locate", locate_data)

    def check_delivery_access(self, user_id: int) -> Tuple[bool, str]:
        """بررسی اعتبار موقعیت مکانی یا شهر مشتری بر اساس تنظیمات ارسال"""

        user = self.get_user_by_id(user_id)
        if not user:
            return False, "❌ کاربر یافت نشد"

        delivery_area = self.get_delivery_area()
        if not delivery_area:
            return False, "❌ تنظیمات ارسال یافت نشد"

        # اگر محدودیت غیرفعاله → تأیید کن
        if not delivery_area.get("active", False):
            return True, "✅ ارسال بدون محدودیت فعال است"

        area_type = delivery_area.get("type")

        # بررسی بر اساس شهر
        if area_type == "city":
            user_city = user.get("city", "").strip()
            allowed_cities = delivery_area.get("cities", [])

            for city in allowed_cities:
                similarity = SequenceMatcher(None, user_city.lower(), city.lower()).ratio()
                if similarity >= 0.8:
                    return True, f"✅ شهر '{user_city}' مجاز است"

            return False, f"❌ شهر '{user_city}' خارج از محدوده مجاز است"

        # بررسی بر اساس شعاع
        elif area_type == "radius":
            store_location = delivery_area.get("store_location")
            radius_km = delivery_area.get("radius", 5)

            cart = user.get("cart", [])
            location_items = [item for item in cart if item.get("type") == "location"]

            if not location_items:
                return False, "❌ موقعیت مکانی مشتری یافت نشد"

            user_location = (location_items[-1]["lat"], location_items[-1]["lon"])
            store_coords = (store_location["lat"], store_location["lon"])

            distance = geodesic(user_location, store_coords).km
            if distance <= radius_km:
                return True, f"✅ موقعیت داخل شعاع {radius_km} کیلومتر است"
            else:
                return False, f"❌ خارج از محدوده ({round(distance, 2)} km > {radius_km} km)"

        return False, "❌ نوع محدودیت ارسال نامعتبر است"

    def enable_points_system(self):
        try:
            with open(self.data_files["points"], "r", encoding="utf-8") as f:
                data = json.load(f)
            data.setdefault("settings", {})["enabled"] = True
            with open(self.data_files["points"], "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطا در فعال‌سازی امتیازدهی: {e}")

    def disable_points_system(self):
        try:
            with open(self.data_files["points"], "r", encoding="utf-8") as f:
                data = json.load(f)
            data.setdefault("settings", {})["enabled"] = False
            with open(self.data_files["points"], "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطا در غیرفعال‌سازی امتیازدهی: {e}")
