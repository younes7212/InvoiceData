# reset.py
import os
from utils.data_manager import DataManager

def reset_data():
    """ریست کردن تمام داده‌ها"""
    print("🔄 ریست کردن داده‌ها...")
    
    # حذف فایل‌های موجود
    data_files = [
        'data/orders.json'
    ]
    
    for file_path in data_files:
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"✅ {file_path} حذف شد")
    
    # ایجاد مجدد
    data_manager = DataManager()
    data_manager.initialize_data_files()
    
    print("✅ داده‌ها با موفقیت ریست شدند!")

if __name__ == "__main__":
    reset_data()
