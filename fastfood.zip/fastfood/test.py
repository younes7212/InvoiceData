import asyncio
import logging
import requests
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from pyngrok import conf, ngrok

# توکن ربات تلگرام
TOKEN = "8256490628:AAFovwt2IdV6v7GLUikJ_Wgrqzr7bk_NRx4"

# ثبت توکن Ngrok
conf.get_default().auth_token = "32kKA8Cni2sDi04IiCH7yGG5uUn_6x3TtuLariAkPdFFtUmJP"

# ساخت تونل روی پورت 8000
public_url = ngrok.connect(8000)
print("📡 لینک عمومی:", public_url)

# معرفی لینک به تلگرام
requests.get(f"https://api.telegram.org/bot{TOKEN}/setWebhook?url={public_url}")

# ساخت ربات
bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())

@dp.message()
async def echo(msg: types.Message):
    await msg.answer(f"سلام {msg.text}")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
