# run.py
import asyncio
import threading
import time
import sys
import os

# اضافه کردن مسیر پروژه به Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import main as run_bot_main
from app import app

def run_flask():
    """اجرای Flask در thread جداگانه"""
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

def run_telegram_bot():
    """اجرای ربات تلگرام"""
    try:
        asyncio.run(run_bot_main())
    except Exception as e:
        print(f"خطا در اجرای ربات: {e}")

if __name__ == "__main__":
    print("🚀 شروع ربات فست فود ویژه امیر...")
    
    # اجرای Flask در thread جداگانه
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    
    print("🌐 Flask web server started on http://localhost:5000")
    
    # کمی تأخیر برای اطمینان از شروع Flask
    time.sleep(2)
    
    # اجرای ربات تلگرام در main thread
    print("🤖 Starting Telegram bot...")
    run_telegram_bot()
